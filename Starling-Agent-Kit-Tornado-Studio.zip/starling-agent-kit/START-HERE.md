# Starter prompt for the next agent

Attach the **Starling Agent Kit ZIP** (or give the agent the kit repo/folder) and paste:

> Use the attached Starling Agent Kit as project context. Read `AGENTS.md`, `HANDOFF.md`, and `TARGETS.json` first. Build for the pinned Starling v0.8.0 / Java 26.3 / Android ARM64 target. Choose a code-only `.hnmod` for Plus Fix, a content-only `.hmod`, a resource-pack ZIP, or separate files if needed. Follow the relevant example and install route. Return the source, ready-to-import file(s) if your tools can make them, exact checks you ran, and an updated `HANDOFF.md` or an entry I can merge. Don't claim a build or phone test you didn't perform. Don't change my workflow or ask for credentials.
>
> My task: **[describe the feature and how I should test it]**

If the chat cannot read a ZIP, attach `AGENTS.md`, `HANDOFF.md`, `TARGETS.json`, `docs/FORMATS.md`, `docs/VALIDATE.md`, and `docs/INSTALL.md` directly, plus the matching example's source files. An agent without file-generation or build tools can return complete source files and a packaging recipe, but it must label those as **not packaged / not run**. Bring its output back to the master.
