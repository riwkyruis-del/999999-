# Pocket Wrench · 0.1.1 kit reference

[Download the `.hnmod`](../releases/Pocket-Wrench-0.1.1-starling-0.8.0.hnmod) · [Bundle readme](bundle/mixins/pocket_wrench/README.md) · [Checks and SHA-256](../VERIFICATION.md)

A code-only example that turns compatible blocks when a player uses a stick on them in a locally hosted world. Sneak dismantling is **off by default**. It illustrates a `Game::use_item` hook and priority, settings, and native mod listing. This one **can change blocks** by design; use a new test world.

The kit's `pocket_wrench` normalizes the previously delivered `pocket-wrench` 0.1.0 ID/version and adds the explicit matching Starling revision in TOML. **Do not combine it with its older variant or the upstream Wrench**; the engine module names overlap. [Install via Plus Fix](../../docs/INSTALL.md#a-code-only-hnmod--plus-fix).

```sh
python3 tools/kit.py pack native examples/pocket-wrench/bundle work/Pocket-Wrench-0.1.1-starling-0.8.0.hnmod
```

**Smoke test (not yet run):** In a disposable local world, aim at the side of a placed log while holding a stick and tap Use/Place (not Attack). The log should rotate. Check Options → Mods for Wrench settings. Sneaking with default settings should not dismantle the block. Test it on its own before adding other mods with use-item hooks.
