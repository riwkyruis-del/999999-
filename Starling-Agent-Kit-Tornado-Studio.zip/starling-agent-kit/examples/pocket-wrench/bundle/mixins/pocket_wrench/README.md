# Pocket Wrench 0.1.1

A code-only native mod for Starling v0.8.0 (Minecraft Java 26.3).

In a local Survival or Creative world, hold a stick, aim at the side of a log,
and use the game's Use/Place control (not Attack). The stick turns compatible
blocks such as logs and some stairs or redstone components. Dismantling by
sneaking is off on a fresh profile. For optional dismantling or a different
wrench item, use Pocket Wrench's settings under Options > Mods. The mod
applies to worlds this game hosts, not another server's world.

Based on the MIT-licensed Wrench example from Starling v0.8.0. This variant
changes the display name and mod ID and makes sneak dismantling opt-in. It
still uses Wrench's engine hook and module names; don't compile both mods
into the same build. No Minecraft assets or code are included.

Source: https://github.com/starling-client/starling/tree/v0.8.0/native-mods/wrench
See LICENSE.txt for upstream copyright and license.
