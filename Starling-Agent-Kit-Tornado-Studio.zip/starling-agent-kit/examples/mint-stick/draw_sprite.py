#!/usr/bin/env python3
"""Generate an original 16×16 transparent mint-and-brass stick sprite."""
from pathlib import Path
import struct
import zlib

SIZE = 16
COLORS = {
    " ": (0, 0, 0, 0),
    "o": (21, 49, 48, 255),
    "m": (68, 188, 153, 255),
    "h": (157, 238, 188, 255),
    "b": (185, 121, 56, 255),
    "g": (247, 218, 131, 255),
}
art = [[" "] * SIZE for _ in range(SIZE)]
for x in range(2, 14):
    y = 15 - x
    for dy, color in [(-1, "o"), (0, "m"), (1, "o")]:
        art[y + dy][x] = color
    art[y - 1][x] = "h" if 3 <= x <= 12 else "o"
    if x in (4, 5, 10, 11):
        art[y][x] = "g"
        art[y + 1][x] = "b"
art[14][1], art[13][1] = "o", "o"
art[1][14], art[2][14] = "o", "o"


def chunk(kind, data):
    return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind + data))


raw = b''.join(b'\x00' + bytes(c for pixel in row for c in COLORS[pixel]) for row in art)
png = (b'\x89PNG\r\n\x1a\n'
       + chunk(b'IHDR', struct.pack('>IIBBBBB', SIZE, SIZE, 8, 6, 0, 0, 0))
       + chunk(b'IDAT', zlib.compress(raw, 9)) + chunk(b'IEND', b''))
path = Path(__file__).resolve().parent / 'pack/assets/minecraft/textures/item/stick.png'
path.parent.mkdir(parents=True, exist_ok=True)
path.write_bytes(png)
print(path)
