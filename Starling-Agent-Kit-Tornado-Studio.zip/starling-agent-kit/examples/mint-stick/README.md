# Mint Stick · resource pack 1.0.0

[Download the resource ZIP](../releases/Mint-Stick-1.0.0-java-26.3.zip) · [Package source](pack/) · [Checks and SHA-256](../VERIFICATION.md)

One original 16×16 RGBA sprite overrides `assets/minecraft/textures/item/stick.png`, so existing sticks should look mint green with brass bands. No code, new items or crafting changes. `pack.mcmeta` declares exact resource format **97.1**. Python 3.11+ can regenerate the sprite and ZIP without any third-party package:

```sh
python3 examples/mint-stick/draw_sprite.py
python3 tools/kit.py pack resource examples/mint-stick/pack work/Mint-Stick-1.0.0-java-26.3.zip
```

**Smoke test (not yet run):** [Enable the ZIP in the game](../../docs/INSTALL.md#c-textureresource-zip--starling-game), then inspect a normal stick in your inventory and hand. Test on its own if another pack overrides it. Disable the pack and confirm the standard sprite returns.
