# Kit Marker · content mod 0.1.0

[Download the `.hmod`](../releases/Kit-Marker-0.1.0.hmod) · [Package source](pack/) · [Checks and SHA-256](../VERIFICATION.md)

A decorative, light-emitting marker tile with a block model, item model, recipe, loot and pickaxe tag. It demonstrates **one owned registry ID** `kit_marker:marker_tile` and uses a stock prismarine texture by name. There is no copied game art, code, `.hnmod`, or second resource pack. API 0.2, `side = "both"`.

Build with the [`cargo-horizon-mod` pinned to Starling](../../docs/VALIDATE.md#1-get-the-exact-source-and-tools) (set `$PACK` there first):

```sh
mkdir -p work/kit_marker
cp -R examples/kit_marker/pack/. work/kit_marker/
(cd work/kit_marker && "$PACK" build)
"$PACK" check work/kit_marker/target/horizon-mod/kit_marker.hmod
```

**Smoke test (not yet run):** [Import into the game](../../docs/INSTALL.md#b-content-only-hmod--starling-game), enable/restart and create a disposable world with the mod. Combine prismarine and glowstone dust in a crafting grid, place the Marker Tile, and check its name, texture and light. Mine it with a suitable pickaxe; it should drop itself. Do not remove a registry mod from an important save without a backup and plan.
