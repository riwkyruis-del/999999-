fn register_tornado(game: &crate::game::Game<'_>, commands: &mut Vec<&'static str>) {
    use crate::game::starling_tornado as tornado;
    if tornado::available(game) && !commands.contains(&tornado::COMMAND) {
        commands.push(tornado::COMMAND);
    }
}
