// Pure command, simulation and funnel geometry. No game or I/O dependencies.
use std::f64::consts::TAU;
use std::fmt;

pub const COMMAND: &str = "tornado";
pub const DEFAULT_SECONDS: u16 = 45;
pub const MIN_SECONDS: u16 = 5;
pub const MAX_SECONDS: u16 = 120;
pub const TICKS_PER_SECOND: u32 = 20;
pub const MAX_PUFFS: usize = 144;
pub const MAX_DRAW_DISTANCE: f64 = 72.0;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Ef(u8);

impl Ef {
    pub const DEFAULT: Self = Self(2);

    pub fn parse(word: &str) -> Option<Self> {
        let digit = match word.as_bytes() {
            [digit] | [b'e' | b'E', b'f' | b'F', digit] => *digit,
            _ => return None,
        };
        (b'0'..=b'5').contains(&digit).then(|| Self(digit - b'0'))
    }

    pub fn profile(self) -> Profile {
        PROFILES[usize::from(self.0)]
    }
}

impl fmt::Display for Ef {
    fn fmt(&self, out: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(out, "EF{}", self.0)
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Command {
    Default,
    Ef(Ef),
    Spawn(Ef, u16),
    Set(Ef),
    Status,
    Stop,
    Help,
}

pub fn parse(line: &str) -> Option<Result<Command, &'static str>> {
    let mut words = line.split_ascii_whitespace();
    if words.next()? != COMMAND {
        return None;
    }
    let Some(action) = words.next() else {
        return Some(Ok(Command::Default));
    };
    Some(parse_args(action, words))
}

fn parse_args(
    action: &str,
    mut words: std::str::SplitAsciiWhitespace<'_>,
) -> Result<Command, &'static str> {
    const USAGE: &str = "Unrecognized tornado syntax. Try /tornado help.";
    const EF: &str = "Choose EF0 to EF5 (or 0 to 5).";
    let command = if action.eq_ignore_ascii_case("spawn") {
        let ef = words
            .next()
            .map_or(Ok(Ef::DEFAULT), |w| Ef::parse(w).ok_or(EF))?;
        let duration = match words.next() {
            None => DEFAULT_SECONDS,
            Some(w) => w
                .parse::<u16>()
                .ok()
                .filter(|v| (MIN_SECONDS..=MAX_SECONDS).contains(v))
                .ok_or("Duration must be from 5 to 120 seconds.")?,
        };
        Command::Spawn(ef, duration)
    } else if action.eq_ignore_ascii_case("set") || action.eq_ignore_ascii_case("ef") {
        Command::Set(words.next().and_then(Ef::parse).ok_or(EF)?)
    } else if action.eq_ignore_ascii_case("status") {
        Command::Status
    } else if action.eq_ignore_ascii_case("stop") {
        Command::Stop
    } else if action.eq_ignore_ascii_case("help") || action == "?" {
        Command::Help
    } else if let Some(ef) = Ef::parse(action) {
        Command::Ef(ef)
    } else if action
        .get(..2)
        .is_some_and(|s| s.eq_ignore_ascii_case("ef"))
        || action
            .as_bytes()
            .first()
            .is_some_and(|c| c.is_ascii_digit() || *c == b'-')
    {
        return Err(EF);
    } else {
        return Err(USAGE);
    };
    if words.next().is_some() {
        return Err(USAGE);
    }
    Ok(command)
}

#[derive(Clone, Copy, Debug)]
pub struct Profile {
    pub height: f64,
    pub foot_radius: f64,
    pub crown_radius: f64,
    pub skirt_radius: f64,
    /// Turns per second, in the effect rather than physical wind speed.
    pub spin: f64,
    pub funnel: f64,
    pub skirt: f64,
}

const fn profile(
    height: f64,
    foot_radius: f64,
    crown_radius: f64,
    skirt_radius: f64,
    spin: f64,
    funnel: f64,
    skirt: f64,
) -> Profile {
    Profile {
        height,
        foot_radius,
        crown_radius,
        skirt_radius,
        spin,
        funnel,
        skirt,
    }
}

const PROFILES: [Profile; 6] = [
    profile(8.0, 0.43, 1.80, 1.75, 0.23, 34.0, 10.0),
    profile(11.0, 0.54, 2.39, 2.20, 0.28, 44.0, 12.0),
    profile(14.0, 0.66, 3.10, 2.75, 0.34, 59.0, 14.0),
    profile(17.0, 0.81, 3.87, 3.40, 0.41, 76.0, 17.0),
    profile(21.0, 0.98, 4.70, 4.15, 0.50, 94.0, 21.0),
    profile(26.0, 1.16, 5.65, 5.00, 0.60, 118.0, 26.0),
];

fn lerp(a: f64, b: f64, t: f64) -> f64 {
    a + (b - a) * t
}

pub fn smooth(from: f64, to: f64, value: f64) -> f64 {
    let t = ((value - from) / (to - from)).clamp(0.0, 1.0);
    t * t * (3.0 - 2.0 * t)
}

impl Profile {
    fn at(level: f64) -> Self {
        let low = level as usize;
        let a = PROFILES[low];
        let b = PROFILES[(low + 1).min(5)];
        let t = level.fract();
        let blend = |x, y| lerp(x, y, t);
        profile(
            blend(a.height, b.height),
            blend(a.foot_radius, b.foot_radius),
            blend(a.crown_radius, b.crown_radius),
            blend(a.skirt_radius, b.skirt_radius),
            blend(a.spin, b.spin),
            blend(a.funnel, b.funnel),
            blend(a.skirt, b.skirt),
        )
    }
}

#[derive(Clone, Debug)]
pub struct Storm {
    base: [f64; 3],
    target: Ef,
    level: f64,
    previous_level: f64,
    age: u32,
    duration: u32,
    phase: f64,
    phase_step: f64,
    rise: f64,
    rise_step: f64,
    seed: u32,
}

impl Storm {
    pub fn new(base: [f64; 3], ef: Ef, seconds: u16, seed: u32) -> Option<Self> {
        if !base.into_iter().all(f64::is_finite) || base.iter().any(|p| p.abs() > 30_000_000.0) {
            return None;
        }
        let level = f64::from(ef.0);
        Some(Self {
            base,
            target: ef,
            level,
            previous_level: level,
            age: 0,
            duration: u32::from(seconds.clamp(MIN_SECONDS, MAX_SECONDS)) * TICKS_PER_SECOND,
            phase: noise(seed) * TAU,
            phase_step: 0.0,
            rise: 0.0,
            rise_step: 0.0,
            seed,
        })
    }

    pub fn base(&self) -> [f64; 3] {
        self.base
    }
    pub fn ef(&self) -> Ef {
        self.target
    }
    pub fn set_ef(&mut self, ef: Ef) {
        self.target = ef;
    }
    pub fn seconds_left(&self) -> u32 {
        self.duration
            .saturating_sub(self.age)
            .div_ceil(TICKS_PER_SECOND)
    }

    /// True while the storm should remain. Ease a full EF0-to-EF5 change over at most 16 ticks.
    pub fn advance(&mut self) -> bool {
        self.age = self.age.saturating_add(1);
        if self.age >= self.duration {
            return false;
        }
        self.previous_level = self.level;
        self.level += (f64::from(self.target.0) - self.level).clamp(-0.32, 0.32);
        self.phase_step = Profile::at(self.level).spin * TAU / f64::from(TICKS_PER_SECOND);
        self.phase += self.phase_step;
        self.rise_step = 0.0091 + self.level * 0.0006;
        self.rise += self.rise_step;
        true
    }

    pub fn frame(&self, partial: f32, particles: u8) -> Frame {
        let fraction = if partial.is_finite() {
            f64::from(partial.clamp(0.0, 1.0))
        } else {
            0.0
        };
        let t = if self.age == 0 {
            0.0
        } else {
            f64::from(self.age - 1) + fraction
        };
        let level = lerp(self.previous_level, self.level, fraction);
        let profile = Profile::at(level);
        let density = match particles {
            0 => 1.0,
            1 => 0.70,
            _ => 0.42,
        };
        Frame {
            profile,
            level,
            base: self.base,
            time: t,
            phase: self.phase - (1.0 - fraction) * self.phase_step,
            rise: self.rise - (1.0 - fraction) * self.rise_step,
            growth: 0.68 + 0.32 * smooth(0.0, 14.0, t),
            opacity: (0.38 + 0.62 * smooth(0.0, 12.0, t))
                * smooth(0.0, 19.0, f64::from(self.duration) - t),
            funnel: profile.funnel * density,
            skirt: profile.skirt * density,
            seed: self.seed,
        }
    }
}

fn noise(mut x: u32) -> f64 {
    x ^= x >> 16;
    x = x.wrapping_mul(0x7feb_352d);
    x ^= x >> 15;
    x = x.wrapping_mul(0x846c_a68b);
    x ^= x >> 16;
    f64::from(x) / 4_294_967_296.0
}

#[derive(Clone, Copy, Debug)]
pub struct Puff {
    pub position: [f64; 3],
    pub radius: f32,
    pub rgba: [f32; 4],
    pub sprite: u32,
    pub dust: bool,
}

pub struct Frame {
    profile: Profile,
    level: f64,
    base: [f64; 3],
    time: f64,
    phase: f64,
    rise: f64,
    growth: f64,
    opacity: f64,
    funnel: f64,
    skirt: f64,
    seed: u32,
}

impl Frame {
    pub fn puffs(&self) -> impl Iterator<Item = Puff> + '_ {
        let funnel = self.funnel.ceil() as u32;
        let skirt = self.skirt.ceil() as u32;
        (0..funnel)
            .map(|k| self.puff(k, false))
            .chain((0..skirt).map(|k| self.puff(k, true)))
            .take(MAX_PUFFS)
    }

    fn puff(&self, k: u32, dust: bool) -> Puff {
        let key = self.seed ^ (k + if dust { 233 } else { 1 }).wrapping_mul(0x9e37_79b9);
        let jitter = noise(key);
        let seed_height = (f64::from(k) * 0.618_033_988_749_894_8 + 0.017 * jitter).fract();
        let turn = noise(key ^ 0x792d_053b);
        let profile = self.profile;
        let band_alpha =
            ((if dust { self.skirt } else { self.funnel }) - f64::from(k)).clamp(0.0, 1.0);
        let (position, radius, rgba) = if dust {
            // A turbulent, warm-coloured dust skirt is distinct from the funnel above it.
            let (s, c) = (self.phase * 1.39 + seed_height * TAU).sin_cos();
            let rad = profile.skirt_radius * self.growth * (0.32 + 0.65 * jitter);
            let lift = 0.16 + 0.78 * (turn + self.time * 0.028).fract();
            let gray = (0.60 + 0.13 * jitter) as f32;
            (
                [
                    self.base[0] + rad * c,
                    self.base[1] + lift,
                    self.base[2] + rad * s,
                ],
                (0.37 + 0.45 * jitter + 0.042 * profile.skirt_radius) as f32,
                [gray, gray * 0.89, gray * 0.74, 0.58],
            )
        } else {
            // Three helical bands. Puffs rise along them and fade where they wrap.
            let h = (seed_height + self.rise).rem_euclid(1.0);
            let theta =
                self.phase + (h * 1.66 + f64::from(k % 3) / 3.0) * TAU + (turn - 0.5) * 0.90;
            let (s, c) = theta.sin_cos();
            let rad = lerp(
                profile.foot_radius,
                profile.crown_radius,
                h * (0.36 + 0.64 * h),
            ) * self.growth
                * (0.66 + 0.49 * jitter);
            let sway = h * h * profile.crown_radius * 0.38;
            // The lean changes much more slowly than the spinning bands.
            let (bend_z, bend_x) = (self.time * 0.023 + 2.0).sin_cos();
            let pos = [
                self.base[0] + rad * c + bend_x * sway,
                self.base[1] + 0.22 + h * profile.height * self.growth,
                self.base[2] + rad * s + bend_z * sway,
            ];
            let size = 0.34 + rad * (0.26 + 0.10 * jitter) + 0.56 * jitter;
            let shade = (0.80 - 0.046 * self.level + 0.13 * jitter + 0.045 * c) as f32;
            let fade = smooth(0.0, 0.066, h) * (1.0 - smooth(0.90, 1.0, h));
            (
                pos,
                size as f32,
                [
                    shade * 0.94,
                    shade * 0.98,
                    shade,
                    (fade * (0.57 + 0.22 * turn)) as f32,
                ],
            )
        };
        Puff {
            position,
            radius: radius * self.growth as f32,
            rgba: [
                rgba[0],
                rgba[1],
                rgba[2],
                rgba[3] * (self.opacity * band_alpha) as f32,
            ],
            sprite: key,
            dust,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn parsed(s: &str) -> Command {
        parse(s).unwrap().unwrap()
    }

    #[test]
    fn parses_all_rating_forms_and_commands() {
        for n in 0..=5 {
            for form in [
                format!("EF{n}"),
                format!("ef{n}"),
                format!("eF{n}"),
                n.to_string(),
            ] {
                assert_eq!(parsed(&format!("tornado {form}")), Command::Ef(Ef(n)));
                assert_eq!(parsed(&format!("tornado set {form}")), Command::Set(Ef(n)));
                assert_eq!(
                    parsed(&format!("tornado spawn {form} 10")),
                    Command::Spawn(Ef(n), 10)
                );
            }
        }
        assert_eq!(parsed("tornado"), Command::Default);
        assert_eq!(
            parsed("tornado SPAWN"),
            Command::Spawn(Ef::DEFAULT, DEFAULT_SECONDS)
        );
        assert_eq!(parsed("tornado\t ef   EF5"), Command::Set(Ef(5)));
        assert_eq!(parsed("tornado status"), Command::Status);
        assert_eq!(parsed("tornado stop"), Command::Stop);
        assert_eq!(parsed("tornado help"), Command::Help);
    }

    #[test]
    fn rejects_bad_or_extra_arguments_without_claiming_other_commands() {
        for line in [
            "",
            "weather clear",
            "tornadoe 2",
            "tornado:other",
            "summon tornado",
        ] {
            assert_eq!(parse(line), None, "{line}");
        }
        for line in [
            "tornado -1",
            "tornado 6",
            "tornado Ef6",
            "tornado EF00",
            "tornado ef",
            "tornado 5x",
            "tornado set",
            "tornado set ❄",
            "tornado stop 1",
            "tornado spawn 5 4",
            "tornado spawn 5 121",
            "tornado spawn 5 NaN",
            "tornado spawn 5 25 extra",
        ] {
            assert!(parse(line).is_some_and(|r| r.is_err()), "{line}");
        }
        assert_eq!(
            parsed("tornado spawn 5 5"),
            Command::Spawn(Ef(5), MIN_SECONDS)
        );
        assert_eq!(
            parsed("tornado spawn 5 120"),
            Command::Spawn(Ef(5), MAX_SECONDS)
        );
    }

    #[test]
    fn intensities_increase_height_width_spin_and_density() {
        for pair in PROFILES.windows(2) {
            let (a, b) = (pair[0], pair[1]);
            assert!(a.height < b.height && a.foot_radius < b.foot_radius);
            assert!(a.crown_radius < b.crown_radius && a.skirt_radius < b.skirt_radius);
            assert!(a.spin < b.spin && a.funnel < b.funnel && a.skirt < b.skirt);
        }
    }

    #[test]
    fn retuning_is_smooth_and_does_not_reset_position_or_timer() {
        let mut storm = Storm::new([16.0, 65.0, -4.0], Ef(0), 30, 1).unwrap();
        storm.advance();
        storm.set_ef(Ef(5));
        assert_eq!(storm.ef(), Ef(5));
        assert_eq!(storm.frame(0.0, 0).profile.height, 8.0);
        storm.advance();
        assert!(storm.frame(1.0, 0).profile.height > 8.0);
        assert!(storm.frame(1.0, 0).profile.height < 26.0);
        for _ in 0..16 {
            assert!(storm.advance());
        }
        assert_eq!(storm.frame(1.0, 0).profile.height, 26.0);
        storm.set_ef(Ef(0));
        for _ in 0..20 {
            assert!(storm.advance());
        }
        assert_eq!(storm.frame(1.0, 0).profile.height, 8.0);
        assert_eq!(storm.base(), [16.0, 65.0, -4.0]);
        assert_eq!(storm.age, 38);
        assert_eq!(storm.seconds_left(), 29);
    }

    #[test]
    fn spawn_validation_and_tick_exact_expiry() {
        assert!(Storm::new([f64::NAN, 0.0, 0.0], Ef(0), 5, 0).is_none());
        assert!(Storm::new([30_000_001.0, 0.0, 0.0], Ef(0), 5, 0).is_none());
        let mut storm = Storm::new([0.0, -61.0, 0.0], Ef(5), 1, 0).unwrap();
        assert_eq!(storm.seconds_left(), 5);
        for _ in 1..100 {
            assert!(storm.advance());
        }
        assert!(storm.frame(1.0, 0).opacity < 0.01);
        assert_eq!(storm.seconds_left(), 1);
        assert!(!storm.advance());
        assert_eq!(storm.seconds_left(), 0);
        let storm = Storm::new([0.0; 3], Ef(5), u16::MAX, 0).unwrap();
        assert_eq!(storm.seconds_left(), 120);
    }

    #[test]
    fn funnel_stays_finite_bounded_and_denser_on_higher_settings() {
        for rating in 0..=5 {
            let mut storm = Storm::new([13.0, 62.0, -999.0], Ef(rating), 30, 999).unwrap();
            for t in 1..=200 {
                assert!(storm.advance());
                if t % 7 != 0 {
                    continue;
                }
                let mut limit = MAX_PUFFS + 1;
                for particles in 0..3 {
                    let puffs: Vec<_> = storm.frame(0.5, particles).puffs().collect();
                    assert!(puffs.len() < limit && puffs.len() >= 15);
                    limit = puffs.len();
                    for puff in puffs {
                        assert!(puff.position.into_iter().all(f64::is_finite));
                        assert!(puff.rgba.into_iter().all(|x| (0.0..=1.0).contains(&x)));
                        assert!((0.15..=4.0).contains(&puff.radius));
                        assert!((0.0..=27.0).contains(&(puff.position[1] - 62.0)));
                        assert!((puff.position[0] - 13.0).hypot(puff.position[2] + 999.0) < 9.25);
                    }
                }
            }
        }
    }

    #[test]
    fn retuning_keeps_visual_motion_continuous_between_ticks() {
        let mut storm = Storm::new([0.0; 3], Ef(5), 45, 3).unwrap();
        for tick in 0..200 {
            if tick == 65 {
                storm.set_ef(Ef(0));
            }
            if tick == 135 {
                storm.set_ef(Ef(5));
            }
            let a: Vec<_> = storm.frame(1.0, 0).puffs().map(|p| p.position).collect();
            storm.advance();
            let b: Vec<_> = storm.frame(0.0, 0).puffs().map(|p| p.position).collect();
            assert_eq!(a.len(), b.len());
            for (pa, pb) in a.into_iter().zip(b) {
                assert!(pa.into_iter().zip(pb).all(|(x, y)| (x - y).abs() < 1.0e-9));
            }
        }
    }
}
