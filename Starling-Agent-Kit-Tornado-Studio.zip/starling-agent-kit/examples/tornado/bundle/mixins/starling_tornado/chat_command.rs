fn run_tornado(game: &mut crate::game::Game<'_>, command: &str, ran: &mut bool) {
    if !*ran && crate::game::starling_tornado::available(game) {
        *ran = crate::game::starling_tornado::command(game, command);
    }
}
