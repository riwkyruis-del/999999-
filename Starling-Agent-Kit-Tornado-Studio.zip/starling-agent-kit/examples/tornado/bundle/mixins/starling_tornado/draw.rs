fn draw_tornado(
    engine: &crate::particles::ParticleEngine,
    camera: glam::DVec3,
    yaw: f32,
    pitch: f32,
    partial: f32,
    light_at: &dyn Fn([i32; 3]) -> u8,
    out: &mut Vec<crate::mesher::Vertex>,
) {
    crate::particles::starling_tornado_visuals::render(
        engine, camera, yaw, pitch, partial, light_at, out,
    );
}
