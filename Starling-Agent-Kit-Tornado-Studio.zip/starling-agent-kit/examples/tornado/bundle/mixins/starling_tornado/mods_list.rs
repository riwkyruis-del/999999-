fn list_tornado(mods: &mut Vec<crate::game::native_hooks::NativeMod>) {
    mods.push(crate::game::native_hooks::NativeMod {
        id: "starling_tornado".into(),
        title: "Starling Tornado 1.0.1".into(),
        description:
            "A rotating, non-destructive funnel for single-player. Type /tornado help in chat."
                .into(),
        keys: Vec::new(),
    });
}
