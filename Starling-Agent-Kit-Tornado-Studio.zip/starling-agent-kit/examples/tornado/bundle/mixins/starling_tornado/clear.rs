fn clear_tornado(engine: &mut crate::particles::ParticleEngine) {
    engine.starling_tornado_stop();
}
