// Chat and read-only placement in the client's copy of the world.
use super::Game;
use horizon_client::blocks::Fluid;
use horizon_client::particles::starling_tornado_model::{
    self as model, Command, DEFAULT_SECONDS, Ef, Storm,
};

pub(super) use model::COMMAND;

pub(super) fn available(game: &Game<'_>) -> bool {
    // An external server (a LAN guest included) still owns its /tornado.
    game.native_window() && game.has_singleplayer_server()
}

pub(super) fn command(game: &mut Game<'_>, line: &str) -> bool {
    let Some(action) = model::parse(line) else {
        return false;
    };
    let message = match action {
        Err(error) => error.to_owned(),
        Ok(Command::Help) => {
            game.native_chat(
                "[Tornado] /tornado starts EF2; /tornado EF0-EF5 starts or retunes it.",
            );
            game.native_chat("[Tornado] /tornado spawn EF3 60 replaces it ahead of you. Duration: 5–120 seconds.");
            game.native_chat(
                "[Tornado] /tornado set EF5 retunes in place. /tornado status; /tornado stop.",
            );
            return true;
        }
        Ok(Command::Status) => status(game),
        Ok(Command::Stop) => {
            if game.particles.starling_tornado_stop() {
                "Stopped the tornado.".into()
            } else {
                "No active tornado.".into()
            }
        }
        Ok(Command::Default) if game.particles.starling_tornado().is_some() => status(game),
        Ok(Command::Default) => spawn(game, Ef::DEFAULT, DEFAULT_SECONDS),
        Ok(Command::Spawn(ef, seconds)) => spawn(game, ef, seconds),
        Ok(Command::Ef(ef)) if game.particles.starling_tornado().is_none() => {
            spawn(game, ef, DEFAULT_SECONDS)
        }
        Ok(Command::Set(ef) | Command::Ef(ef)) => {
            if let Some(storm) = game.particles.starling_tornado_mut() {
                storm.set_ef(ef);
                format!(
                    "Changing to {ef} in place ({}s remaining).",
                    storm.seconds_left()
                )
            } else {
                "No active tornado. Start one with /tornado or /tornado EF2.".into()
            }
        }
    };
    game.native_chat(&format!("[Tornado] {message}"));
    true
}

fn status(game: &Game<'_>) -> String {
    let Some(storm) = game.particles.starling_tornado() else {
        return "No active tornado. Use /tornado to start one.".into();
    };
    let [x, y, z] = storm.base();
    let ef = storm.ef();
    let profile = ef.profile();
    format!(
        "{ef} at ({x:.0}, {y:.0}, {z:.0}) · {:.0} blocks tall · {}s remaining. Visual only.",
        profile.height,
        storm.seconds_left()
    )
}

fn spawn(game: &mut Game<'_>, ef: Ef, seconds: u16) -> String {
    let Some(player) = game.native_player() else {
        return "Open your own world first.".into();
    };
    let Some(at) = placement(game, [player.x, player.y, player.z], player.yaw) else {
        return "No clear ground ahead. Face an open area nearby and try again.".into();
    };
    if !game.particles.starling_tornado_has_sprite() {
        return "No usable cloud particle texture was loaded. Try with the default resource pack."
            .into();
    }
    // Deterministic local variation without touching either game's random stream.
    let seed = (game.ticks as u32).wrapping_mul(0x85eb_ca6b)
        ^ (at[0].floor() as i32 as u32).wrapping_mul(0x9e37_79b9)
        ^ (at[2].floor() as i32 as u32).rotate_left(13);
    let Some(storm) = Storm::new(at, ef, seconds, seed) else {
        return "The target is outside the supported world bounds.".into();
    };
    game.particles.starling_tornado_start(storm);
    let [x, y, z] = at;
    format!("Spawned {ef} for {seconds}s at ({x:.0}, {y:.0}, {z:.0}). /tornado stop to remove it.")
}

fn placement(game: &Game<'_>, player: [f64; 3], yaw: f32) -> Option<[f64; 3]> {
    if !yaw.is_finite()
        || !player
            .into_iter()
            .all(|v| v.is_finite() && v.abs() <= 30_000_000.0)
    {
        return None;
    }
    let world = &game.world;
    let facts = game.res.facts();
    let loaded = |x: i32, z: i32| world.chunks.contains_key(&(x >> 4, z >> 4));
    let open_above = |x: i32, y: i32, z: i32| {
        (1..=4).all(|dy| {
            let b = facts.get(world.block(x, y + dy, z));
            !b.full_collision && !b.legacy_solid && b.fluid == Fluid::None
        })
    };
    let min_y = world.bottom_y();
    let max_y = world.top_y();

    // Respect a clearly aimed ground surface, but never spawn right in the viewer's face.
    if let Some(hit) = game
        .aim()
        .and_then(|(at, dir)| game.clip_ray(at, dir, 26.0))
    {
        let [x, y, z] = hit.pos;
        let [hx, hy, hz] = hit.point;
        let distance = (hx - player[0]).hypot(hz - player[2]);
        if hit.face == [0, 1, 0]
            && y >= min_y
            && y < max_y
            && (8.0..=26.0).contains(&distance)
            && loaded(x, z)
            && open_above(x, y, z)
        {
            return Some([hx, hy + 0.06, hz]);
        }
    }

    // Horizontal view fallback. Inspect at most three loaded columns; no chunk tickets.
    let (s, c) = f64::from(yaw).to_radians().sin_cos();
    let feet = player[1].floor() as i32;
    let top = (feet + 7).min(max_y - 1);
    let bottom = (feet - 24).max(min_y);
    for distance in [14.0, 10.0, 18.0] {
        let x = (player[0] - s * distance).floor() as i32;
        let z = (player[2] + c * distance).floor() as i32;
        if !loaded(x, z) {
            continue;
        }
        for y in (bottom..=top).rev() {
            let state = world.block(x, y, z);
            let b = facts.get(state);
            if facts.is_air(state)
                || !(b.full_collision || b.legacy_solid || b.fluid != Fluid::None)
            {
                continue;
            }
            if open_above(x, y, z) {
                let height = if b.full_collision || b.fluid != Fluid::None {
                    1.0
                } else {
                    b.outline
                        .iter()
                        .map(|bb| bb[4])
                        .fold(0.0, f64::max)
                        .clamp(0.0, 1.0)
                };
                return Some([
                    f64::from(x) + 0.5,
                    f64::from(y) + height + 0.06,
                    f64::from(z) + 0.5,
                ]);
            }
        }
    }
    None
}
