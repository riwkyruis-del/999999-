# Starling Tornado 1.0.1

A local, visual tornado for **Starling v0.8.0**, Minecraft Java **26.3**, built for Android **ARM64** (`arm64-v8a`). It uses the game's own smoke/cloud textures and needs no separate pack. Only you see it. It does not pull or hurt entities, break blocks, or change world weather. It requires no cheats in your own single-player world.

## Start and control

Load your own world, face open ground, then open chat and send one of these commands:

| Command | Effect |
| --- | --- |
| `/tornado` | Start EF2 for 45 seconds, or show status if one is already active. |
| `/tornado EF3` | Start EF3 if none exists; otherwise change the active tornado to EF3 in place. |
| `/tornado set 5` | Change the active tornado to EF5 without moving it or restarting its timer. |
| `/tornado spawn EF0 20` | Place a fresh EF0 tornado in front of you for 20 seconds, replacing any active one. Enter 5–120 seconds; omit duration for 45. |
| `/tornado status` | Show intensity, location, height and remaining time. |
| `/tornado stop` | Remove it immediately. |
| `/tornado help` | Show command help in chat. |

The levels are game presets, not real-world wind speeds. You can use `0`–`5` in place of `EF0`–`EF5`.

| Level | Approximate funnel height | Approximate upper funnel width* |
| --- | ---: | ---: |
| EF0 | 8 blocks | 4 blocks |
| EF1 | 11 blocks | 5 blocks |
| EF2 | 14 blocks | 6 blocks |
| EF3 | 17 blocks | 8 blocks |
| EF4 | 21 blocks | 9 blocks |
| EF5 | 26 blocks | 11 blocks |

\* Nominal diameter before the wisps and lean. Higher levels are also darker, denser and faster. The base stays in place. The mod uses a clear ground surface you aim at from 8–26 blocks away if it finds one, otherwise tries loaded columns roughly 10–18 blocks ahead. The best first test is a flat clearing in daylight.

There's one tornado at a time. It fades at the end of its timer, clears when the level is replaced or you leave, and is never written into a save. The drawing fades out with distance, and Starling's Particles setting reduces its density. There are at most 144 billboards per frame at EF5 on All, fewer on Decreased or Minimal. `/tornado` is not provided on external servers, and LAN guests don't see the host's effect.

## Install with the Plus Fix companion

1. Keep the `.hnmod` intact; don't extract it. Import it in **Starling Mod Builder Plus Fix** as a mod.
2. Use the existing Plus workflow in a **private** repo you control. This companion still rejects a public repo. You can use a separate private repo without changing the public one.
3. Start a build for the selected mod, wait for the APK to download, then approve Android's install. Launch **Starling Modded Plus** and test in your own world.

This archive is native Rust source, not an APK or a Java/Bedrock mod. Use the pinned build; other Starling versions and architectures were not targets. No account credentials, external libraries, new permissions, file writes, or network calls are part of the mod.
