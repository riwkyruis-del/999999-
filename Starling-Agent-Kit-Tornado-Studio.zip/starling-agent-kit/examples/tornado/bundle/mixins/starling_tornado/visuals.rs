// Analytic billboards: no game entities, no vanilla particle accumulation.
use super::starling_tornado_model::{MAX_DRAW_DISTANCE, MAX_PUFFS, Storm, smooth};
use super::{ParticleEngine, ParticleLightCache, ParticleType};
use crate::{gfx::TRANSLUCENT_PARTICLE_OVERLAY, hud::Rect, mesher::Vertex};
use glam::{DVec3, Quat, Vec3};

impl ParticleEngine {
    pub fn starling_tornado(&self) -> Option<&Storm> {
        self.__horizon_mixins_starling_tornado_storm().as_ref()
    }

    pub fn starling_tornado_mut(&mut self) -> Option<&mut Storm> {
        self.__horizon_mixins_starling_tornado_storm_mut().as_mut()
    }

    pub fn starling_tornado_start(&mut self, storm: Storm) {
        *self.__horizon_mixins_starling_tornado_storm_mut() = Some(storm);
    }

    pub fn starling_tornado_stop(&mut self) -> bool {
        self.__horizon_mixins_starling_tornado_storm_mut()
            .take()
            .is_some()
    }

    pub fn starling_tornado_has_sprite(&self) -> bool {
        cloud_rects(self).is_some()
    }

    pub(super) fn starling_tornado_advance(&mut self) {
        let slot = self.__horizon_mixins_starling_tornado_storm_mut();
        if let Some(storm) = slot
            && !storm.advance()
        {
            *slot = None;
        }
    }
}

/// Pick a few of the full shapes near the head of a vanilla sprite set. Re-resolve on
/// every draw so a pack reload never leaves stale UVs. Preserve a usable fallback.
fn rects(engine: &ParticleEngine, kind: ParticleType) -> Option<[Rect; 4]> {
    let sprites = engine.set_sprites.get(engine.set_of(kind)? as usize)?;
    let mut valid = sprites
        .iter()
        .filter_map(|&index| engine.rects.get(index as usize).copied().flatten());
    let first = valid.next()?;
    Some([
        first,
        valid.next().unwrap_or(first),
        valid.next().unwrap_or(first),
        valid.next().unwrap_or(first),
    ])
}

fn cloud_rects(engine: &ParticleEngine) -> Option<[Rect; 4]> {
    rects(engine, ParticleType::Cloud)
        .or_else(|| rects(engine, ParticleType::CampfireCosySmoke))
        .or_else(|| rects(engine, ParticleType::WhiteSmoke))
        .or_else(|| rects(engine, ParticleType::Smoke))
}

#[derive(Copy, Clone)]
struct Billboard {
    pos: [f64; 3],
    relative: Vec3,
    distance_sq: f32,
    radius: f32,
    rgba: [f32; 4],
    tex: Rect,
}

pub(super) fn render(
    engine: &ParticleEngine,
    camera: DVec3,
    yaw: f32,
    pitch: f32,
    partial: f32,
    light_at: &dyn Fn([i32; 3]) -> u8,
    out: &mut Vec<Vertex>,
) {
    let Some(storm) = engine.starling_tornado() else {
        return;
    };
    // Cull before generating any puffs. Use the middle of the column so the effect
    // is still visible if the camera flies up for a shot.
    let base = DVec3::from_array(storm.base());
    let center = base + DVec3::new(0.0, storm.ef().profile().height * 0.4, 0.0);
    let distance = camera.distance_squared(center);
    if !distance.is_finite() || distance >= MAX_DRAW_DISTANCE.powi(2) {
        return;
    }
    let range_fade = (1.0 - smooth(58.0, MAX_DRAW_DISTANCE, distance.sqrt())) as f32;
    let Some(cloud) = cloud_rects(engine) else {
        return;
    };
    let dust = rects(engine, ParticleType::WhiteSmoke).unwrap_or(cloud);
    let frame = storm.frame(partial, engine.particle_level);
    let mut billboards = [None; MAX_PUFFS];
    let mut count = 0;
    for puff in frame.puffs() {
        let relative = (DVec3::from_array(puff.position) - camera).as_vec3();
        let distance_sq = relative.length_squared();
        // Near-camera fade limits overdraw, and doesn't flash if you walk into the funnel.
        let near_fade = smooth(0.75, 2.65, f64::from(distance_sq.sqrt() / puff.radius));
        let mut rgba = puff.rgba;
        rgba[3] *= range_fade * near_fade as f32;
        if rgba[3] < 0.025 {
            continue;
        }
        let tex = (if puff.dust { dust } else { cloud })[(puff.sprite >> 29 & 3) as usize];
        billboards[count] = Some(Billboard {
            pos: puff.position,
            relative,
            distance_sq,
            radius: puff.radius,
            rgba,
            tex,
        });
        count += 1;
    }
    let billboards = &mut billboards[..count];
    // Render the translucent puffs back to front without sorting the other particles.
    billboards.sort_unstable_by(|a, b| {
        b.as_ref()
            .unwrap()
            .distance_sq
            .total_cmp(&a.as_ref().unwrap().distance_sq)
    });
    let rotation = Quat::from_rotation_y(std::f32::consts::PI - yaw.to_radians())
        * Quat::from_rotation_x(-pitch.to_radians());
    let right = rotation * Vec3::X;
    let up = rotation * Vec3::Y;
    let mut cache = ParticleLightCache::default();
    out.reserve(count * 4);
    for puff in billboards.iter().flatten() {
        let packed = cache.get(puff.pos.map(|p| p.floor() as i32), light_at);
        let light = (u32::from(packed >> 4) * 16) | (u32::from(packed & 15) * 16) << 8;
        let color =
            u32::from_le_bytes(puff.rgba.map(|c| (c.clamp(0.0, 1.0) * 255.0).round() as u8));
        let r = right * puff.radius;
        let u = up * puff.radius;
        let Rect { u0, v0, u1, v1, .. } = puff.tex;
        for (offset, uv) in [
            (r - u, [u1, v1]),
            (r + u, [u1, v0]),
            (-r + u, [u0, v0]),
            (-r - u, [u0, v1]),
        ] {
            out.push(Vertex {
                pos: (puff.relative + offset).to_array(),
                uv,
                layer: TRANSLUCENT_PARTICLE_OVERLAY,
                color,
                light,
                normal: [0; 4],
                glint_uv: [0.0; 2],
            });
        }
    }
}
