# Starling Tornado · 1.0.1 kit reference

[Download the `.hnmod`](../releases/Starling-Tornado-1.0.1-starling-0.8.0.hnmod) · [Commands and options](bundle/mixins/starling_tornado/README.md) · [Checks and SHA-256](../VERIFICATION.md)

A local visual-only `/tornado` effect for Starling v0.8.0 / Java 26.3 / Android ARM64. It reuses **stock cloud/smoke sprites**: no texture ZIP or `.hmod`, dependencies, permission changes, LAN mirroring, or world writes. It places the funnel on bounded loaded terrain ahead of the player. One storm slot per `ParticleEngine` is reset when the client clears particles. Its mixins illustrate a command path and a renderer path, with per-instance state and bounded particle draws (max 144 on All).

The kit's `starling_tornado` is a metadata-compatible variant of the previously delivered `starling-tornado` 1.0.0. It changes the identifier/version and strict manifest shape, not the feature. **Select only one version.** [Install via Plus Fix](../../docs/INSTALL.md#a-code-only-hnmod--plus-fix).

From the kit root:

```sh
python3 tools/kit.py pack native examples/tornado/bundle work/Starling-Tornado-1.0.1-starling-0.8.0.hnmod
rustc --edition 2024 --test examples/tornado/bundle/mixins/starling_tornado/model.rs -o work/tornado-tests
work/tornado-tests
```

## Phone smoke test (not yet run)

1. Open a disposable local world and face a clearing in daylight. Enter `/tornado`. Look about 14 blocks ahead for an EF2 funnel and dust ring.
2. Enter `/tornado EF5`, then `/tornado set EF0`. It should resize in place. `/tornado status` should show the timer has not reset.
3. Try `/tornado EF6` (rejected), then `/tornado stop` (vanishes). `/tornado spawn EF1 5` should fade and expire after about five active seconds.
4. Spawn again, then leave the world or change dimensions. No old funnel should persist, and no terrain/entity state should have changed. Lower Particles or EF rating if needed.
