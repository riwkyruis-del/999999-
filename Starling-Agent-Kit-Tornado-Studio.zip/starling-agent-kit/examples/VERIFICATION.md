# Reference releases · exact evidence for kit 1.0.0

All four example files are in [`releases/`](releases/); their editable source is beside that directory. Do not upload the whole kit ZIP to a game or the companion. These are individual import candidates, not signed APKs.

| Archive | Bytes | SHA-256 |
|---|---:|---|
| [Starling-Tornado-1.0.1-starling-0.8.0.hnmod](releases/Starling-Tornado-1.0.1-starling-0.8.0.hnmod) | 15,506 | `299e8fe659021e2605a85d7c4114e08b20dc16bd4a6b8cdbc96d68996b81e18d` |
| [Pocket-Wrench-0.1.1-starling-0.8.0.hnmod](releases/Pocket-Wrench-0.1.1-starling-0.8.0.hnmod) | 11,068 | `ce4cdfeb6aa9a82237b3377b2a4ee59ad779402994acb74ce039b9222de01e9c` |
| [Kit-Marker-0.1.0.hmod](releases/Kit-Marker-0.1.0.hmod) | 2,307 | `7dd13325d3b1df8993691ae22f026817759037c7ff1d88d8bc8d318fe272f18a` |
| [Mint-Stick-1.0.0-java-26.3.zip](releases/Mint-Stick-1.0.0-java-26.3.zip) | 521 | `f97fcfc11b9b5b3264f281c0823d2c68be3d253375fba47dfe5fe382198060a6` |

## Checks performed

| Stage | Tornado + Pocket Wrench | Kit Marker | Mint Stick |
|---|---|---|---|
| Archive / rebuild | Pass; Python repack and `unzip -t`, both reproduced byte-for-byte | Pass; pinned CLI `build`, byte-for-byte second build, `unzip -t` | Pass; Python ZIP repack byte-for-byte, `unzip -t`; sprite decodes as 16×16 RGBA with transparency |
| Pinned `cargo-horizon-mod check` | Both pass independently as native mods with exact declared pins | Pass; `kit_marker 0.1.0`, API 0.2, both, content only | Pass; resource pack, format 97.1 |
| Plus stage / permission scan | **Pass as a pair** (`pocket_wrench` + `starling_tornado`), exact staged hashes; scan `-` on both | N/A | N/A |
| Unit tests / weave | Tornado model 7/7; pair planned and applied 10 HEAD injections, 5 modules, 1 state (see scope below) | N/A | N/A |
| Full-source Android ARM64 type check | **Pass as a pair** with Rust 1.100.0, NDK 28.2.13676358/API 26; exit 0 | N/A | N/A |
| Linked APK / private Actions run | Not run | N/A | N/A |
| Phone import, install or gameplay | Not run | Not run | Not run |

**Native check scope.** The pinned 0.6.0 weaver used a reduced index with the three exact pinned target files for the pair (`game.rs`, `game/native_hooks.rs`, `particles.rs`) plus minimal unrelated module stubs. The transformation was copied into a **complete** Starling checkout (the Android target was not stubbed) and `cargo check --offline --locked -j 1 --target aarch64-linux-android -p horizon-android` passed. The [reference helper](../docs/VALIDATE.md#4-reproduce-the-reference-weave-and-arm64-check) reproduced all three transformed files byte-for-byte. Actual APK linking, signing/delivery, runtime effects, and gameplay are separate checks.

**Why the native versions changed for the kit.** The historical Plus-only artifacts passed Plus staging and a prior Android ARM64 type check, but `cargo-horizon-mod check` on the pinned Starling commit rejected Tornado 1.0.0 (unknown `name` field) and Pocket Wrench 0.1.0 (hyphenated ID). Plus's staging parser and the Rust native manifest parser are not identical. These kit variants use `starling_tornado` / `pocket_wrench`, six strict JSON fields, and matching manifest version/revision pins, with updated Rust identity labels. No gameplay feature was added or removed. Do not co-select an original and its kit variant; they can declare the same hooks, modules and state.

The original files in the builder workspace were not changed. Original Tornado 1.0.0 SHA-256: `9c85e08380bb131794e73e08972dcdb0128e768828b1331f05ab1762f50ac8b7`. Original Pocket Wrench 0.1.0: `a8e5348929d491c526f51f06180d8ae12832503b095a67a283eb93ab16300684`.
