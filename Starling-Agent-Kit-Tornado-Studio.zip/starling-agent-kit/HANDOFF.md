# Handoff · current state

**Kit 1.0.0** · Local master now includes **Tornado Studio 2.0.0**. No build or phone action is pending unless the user asks to test it. Keep [`AGENTS.md`](AGENTS.md) as standing rules and update this file after each task.

## What is ready

- [Tornado Studio 2.0.0](projects/starling_tornado/README.md) is the updated release: one `/tornado` start/stop command plus a touch-friendly Settings page, Rope/Cone/Wedge/Twin vortex/Shuffle, EF0–5/Random, scale, palette, dust, wind lean, duration and quality. The `.hnmod` and separate resource ZIP are under `projects/starling_tornado/releases/`. No `.hmod`; original 1.x archives remain unchanged. Do not select 1.x and 2.0 together.
- [Studio evidence](projects/starling_tornado/VERIFICATION.md): exact bundles parsed/repacked; 9 tests; co-staged/co-woven with Pocket Wrench 0.1.1; soft-particle WGSL validated; final complete woven Android ARM64 type check passed. The Studio asset pack has 12 original 224×224 tiles and a stock fallback. No APK link, private build, on-phone import/frame rate, or gameplay was tested. The art preview is offline, not an Android screenshot.

- Git-ready master, upload ZIP and [starter prompt](START-HERE.md). No GitHub push, visibility change, workflow edit, private build, or phone action was performed.
- The target is **Starling v0.8.0 / Java 26.3 / Android ARM64**. See [`TARGETS.json`](TARGETS.json). The existing **Plus Fix 2.0.1** companion and Plus workflow remain unchanged. A **separate private repo** is mandatory for that workflow; the kit can be shared without it.
- [Four example releases and source](examples/VERIFICATION.md): Tornado and Pocket Wrench native bundles, Kit Marker `.hmod`, Mint Stick resource ZIP. All four reproduced and passed the pinned parser. The two native references co-staged and co-wove, and the complete woven source passed the Android ARM64 type check. No APK was linked for these files. No phone import, install, or gameplay was tested.
- The native kit examples are new **compatibility-metadata revisions**. Originals (Tornado 1.0.0, Pocket Wrench 0.1.0) accepted by Plus remain untouched. New IDs use underscores, native JSON contains only supported keys, and mixin TOML pins the same revision. Use only one variant of each mod in a set. Details and exact hashes are in [verification](examples/VERIFICATION.md).

## Pitfalls to carry forward

- Plus Fix builds `.hnmod` only. Import `.hmod` and resource ZIPs into the intended **game**, not the companion. Modded Plus does not share Official or old Modded game data by default. Tornado 1.x uses stock textures; Studio 2.0 uses **Studio Textures ZIP** for the new look or stock fallback. Never put the texture ZIP into the companion.
- Full native indexing exceeded the original ~2 GiB sandbox; use the [reference weave helper](docs/VALIDATE.md#4-reproduce-the-reference-weave-and-arm64-check) for the old example pair, the [Studio weave helper](projects/starling_tornado/VERIFICATION.md#reproduce-the-checks) for the four Studio targets, or a larger runner for fresh targets. A reduced index is not a stand-in for compiling real game code. No host-only check substitutes for `--target aarch64-linux-android`.
- The earlier successful GitHub run's phone delivery issue was **not diagnosed**. If it happens again, ask for **Copy delivery error** (not the compiler excerpt). Recover the same run while the artifact is available; don't rebuild just to retry delivery. Different Android signers require a separate migration plan—don't uninstall or clear data blindly.

## Next action

For a new request, choose a [package format](docs/FORMATS.md), read the matching example, and add it under `projects/<id>/`. If the user asks to test Studio, select Studio alone in Plus Fix, enable Studio Textures in the built game, and follow its smoke test in a disposable local world. Record the actual app version, outcome and any sanitized error.

## Task log

- **Tornado Studio 2.0.0.** Built code-only native package and a separate resource ZIP, with saved cycling settings and no world writes. The active funnel state is renderer-owned. A pinned shader boundary HEAD isolates soft alpha to tagged quads; the attempted RETURN on `include_str!` was rejected and should not be retried. [Final evidence and reproduction](projects/starling_tornado/VERIFICATION.md); the next check is real Android delivery and the device smoke test, if authorized.
- **Kit 1.0.0 — initial handoff.** Added three format routes, four source/release examples, local validation tools and private-build setup guide. Evidence and command recipe: [verification](examples/VERIFICATION.md), [validate](docs/VALIDATE.md). Pending: real private run and device validation only if requested; nothing to rerun now.

Append each completed/blocked task using [`templates/HANDOFF-ENTRY.md`](templates/HANDOFF-ENTRY.md). Keep “What is ready” and “Next action” current; put longer per-mod evidence beside its source.
