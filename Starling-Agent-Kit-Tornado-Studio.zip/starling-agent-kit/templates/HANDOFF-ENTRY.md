# Handoff entry · YYYY-MM-DD · task / version

**Status:** ready / blocked / partial. **Format & target:** artifact type, Starling/Mixins pins, Java version, ABI. **Behavior & scope:** what changes and what does not; local/client/server and any save or dependency effects.

- **Changed files:** paths relative to the kit. **Deliverables:** original archive filenames, sizes and SHA-256, source and rebuild command.
- **Mod set / pack order:** exact IDs/versions/hashes for any combination tested. **Install / smoke test:** intended app, commands/actions and expected result.

| Stage | Pass / fail / not run / N/A | Command, environment, result or first error |
|---|---|---|
| ZIP / reproducible package | | |
| Parser / Plus stage | | |
| Unit tests | | |
| Weave | | |
| Full Android ARM64 type check | | |
| Linked library / APK / private run | | |
| Phone delivery / launch | | |
| Gameplay | | |

**Blockers, limitations and risks:** what is unknown, and any old fix not to repeat. **Next action:** one specific step with the file or app involved. Redact tokens, paths to saves, private run URLs and private logs. Update the current-state section of `HANDOFF.md` as well.
