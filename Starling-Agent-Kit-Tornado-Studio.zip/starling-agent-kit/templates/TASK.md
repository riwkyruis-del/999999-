# Next mod brief

- **Feature:** what should the player see/do?
- **Where:** local single-player, client-local while connected, locally hosted/LAN, or server-authoritative? Does it change worlds/inventories or only visuals?
- **Inputs:** commands/controls, assets you can use, existing mod set or pack order to respect.
- **Done when:** 2–4 concrete in-game actions and expected results, including how to disable or undo.
- **Deliver:** choose `.hnmod`, `.hmod`, texture ZIP or separate files; use the pinned target in `TARGETS.json` unless intentionally changing platforms.
- **Agent access:** repo/terminal or upload only; state whether a real build/device test is authorized and available. Do not include credentials or private run links.
