# Choose and structure the package

Ask what the game has to do, not what the file should be named.

| Requirement | Output | Why |
|---|---|---|
| Run a custom chat command, hook block use, add per-frame behavior | `.hnmod` | Rust native mixins are woven into the game and compiled. |
| Add a declarative block/item with recipes/models/loot | `.hmod` | The game reads API 0.2 registry content at startup; no Rust build. |
| Replace existing textures, models, sounds or UI assets | Resource pack `.zip` | Enables asset overrides without changing executable code or adding a registry entry. |
| Need native behavior **and** content or art | `.hnmod` and separate `.hmod` or resource `.zip` | Plus Fix accepts code only; the game installs the other file. Give the user both routes and test together. |

A vanilla Java data pack is another thing (`pack.mcmeta` + `data/`, Java 26.3 data format **121.0**, not resource **97.1**). It is not a Plus input. Likewise a collection `.hpack`, shader-specific pack, Fabric/Forge/NeoForge `.jar`, and old WASM mod are not alternative extensions for any of the three here. See the [pinned source map](SOURCES.md) for details.

## A. Native `.hnmod` for Plus Fix

Use a ZIP with these paths at its **root** (do not wrap them in another folder):

```text
horizon-native.json
mixins/my_mod/horizon-mixin.toml
mixins/my_mod/...                # Rust hooks and support files
mixins/my_mod/README.md
mixins/my_mod/LICENSE
```

```json
{
  "schema": 1,
  "id": "my_mod",
  "version": "0.1.0",
  "game": "26.3",
  "horizon": "ac874422ed8f892505ff73d67ae486ecfee7a516",
  "mixins": "ddd9700b21997c95d95ac6ee5ecafe3830cf622a"
}
```

Start the mixin manifest with matching fields, then add real hook/module declarations adapted from a reference:

```toml
[mod]
id = "my_mod"
version = "0.1.0"

[compatibility]
horizon_revision = "ac874422ed8f892505ff73d67ae486ecfee7a516"
```

- For both parsers, use IDs matching `[a-z0-9][a-z0-9_]{0,63}`. The Plus staging path can accept hyphens, but Starling's stricter Rust loader rejects them. It also rejects unknown top-level JSON keys such as `name` and `description`; use a README for those. `hooks` is an optional positive native-hook API level, **not** a bypass for the exact Plus revision pins. Omit it unless verified for the public API you use. Match ID, version and `horizon_revision` in the TOML and any mod-list identity your Rust code exposes.
- Keep top-level `assets/`, `data/`, `horizon-mod.toml`, WebAssembly, binaries and dependencies not intended for the pinned build out of the archive. Ordinary Rust `.rs` and TOML plus supported license/README files are best. Restricted `data/` **inside** a mixin can support that crate's build; it is not installed as game content by Plus.
- Plus: **1–4** files, **16 MiB** each compressed, **32 MiB** per framed upload, **64 MiB** expanded per mod and **128 MiB** expanded total at stage. No duplicate IDs. Use relative plain paths, no symlinks, no extra wrapper. ZIP and preserve `.hnmod`; don't send the repo or an unpacked folder to the companion.
- Compare actual selectors, bindings and field types against the pinned source. Prefer small typed helpers. A private method usually needs a helper in the same module; make cross-crate support accessible on purpose. In support files wired by `[[module]]`, use normal `//` comments instead of leading `//!` inner attributes (which can trigger `E_MODULE`).
- For a visual-only client feature, keep bounded renderer state and reset it on world/dimension change. Tornado shows `native_window()` + `has_singleplayer_server()` for local commands, `ParticleEngine` constructor/tick/clear/render for lifecycle, and no world writes. `remote.is_none()` is not a single-player test here. Pocket Wrench illustrates shared `Game::use_item` HEAD priority; a cancelling hook can skip lower-priority hooks. Check the *intended mod set*, not only singles.

## B. Content-only `.hmod`

Use a root `horizon-mod.toml`, and proper `assets/<namespace>/...` / `data/<namespace>/...`. Build with the **pinned** `cargo-horizon-mod`, not a CLI installed from latest Horizon. No native manifest, `.wasm`, or code.

```toml
id = "my_content"
name = "My Content"
version = "0.1.0"
description = "One declarative block example."
authors = []
api = "0.2"
side = "both"
capabilities = ["registries"]
```

- ID: `[a-z0-9_]{1,64}`. Use your own namespace. `side = "both"` for shared registries; when testing with a Starling/Horizon server or LAN, use the same version **and the same file hash** on both sides as applicable. This is not a Vanilla Java/Fabric mod loader.
- A block definition goes in `data/<id>/horizon/block/<block>.json`; an item definition in `data/<id>/horizon/item/<item>.json`. Supply the matching item model, blockstate/model, language strings and other data the feature needs. Use Java 26.3 paths (`recipe/`, `loot_table/`, `tags/block/`, not old plural names). [`Kit Marker`](../examples/kit_marker/README.md) demonstrates a block, item model, recipe, loot and a merged vanilla pickaxe tag.
- Loading registries can affect saves. Start with a new disposable world; don't disable a mod that owns existing blocks/items in a valued save without a backup and a removal plan.

## C. Texture/resource pack ZIP

```text
pack.mcmeta
assets/minecraft/textures/item/stick.png
```

```json
{
  "pack": {
    "description": "Example texture override for Java 26.3",
    "min_format": [97, 1],
    "max_format": [97, 1]
  }
}
```

- For a texture-only pack on the pinned release, declare **97.1** as shown. Use the exact asset path the game loads, PNGs with correct dimensions/transparency, and an optional root `pack.png`. `assets/minecraft/…` overrides vanilla paths; custom names require a model or code which actually references them.
- Use pack order to resolve overrides. Upstream documents rendering parity gaps: Java shader/OptiFine/Iris behavior and special models aren't guaranteed. Run the pinned check, then **look at the item/block in the game**. A `97.1` report alone only confirms metadata/structural acceptance, not rendering.
- [Mint Stick](../examples/mint-stick/README.md) is one original sprite replacing an existing item. It adds no new item. [Tornado 1.x](../examples/tornado/README.md) needs no pack because it reuses stock atlas sprites. [Tornado Studio 2.0](../projects/starling_tornado/README.md) is the separate-code-and-art reference: namespaced `textures/particle/` sprites in a game resource pack with a stock fallback.

Continue with [validation](VALIDATE.md) or [installation](INSTALL.md).
