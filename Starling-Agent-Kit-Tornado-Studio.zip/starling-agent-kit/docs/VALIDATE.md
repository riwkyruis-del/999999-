# Validation · report exactly how far you got

Use the exact artifact hash and mod set in each record. A changed ZIP or mixin gets fresh checks. Commands below start **at the kit root**, in Bash on Linux unless noted; use separate output folders. Python 3.11+ is enough to package/export; Rust, Android NDK and Git are only required by the later checks.

| Evidence | What a pass establishes | It does **not** establish |
|---|---|---|
| **Archive**: ZIP test, root paths, SHA-256 and repeatable repack | Correct container and reproducible artifact bytes in this environment | Game can parse it |
| **Parser / Plus stage**: pinned CLI `check`; `.hnmod` also through Plus stage | Matching manifests/content; the set is accepted and extracted by the runner's stage | Hooks apply, PNG renders, or the game builds |
| **Weave**: pinned `plan` / `apply` | Target/binding resolution and source transformation in the stated index | Rust types, Android ABI, or runtime behavior |
| **ARM64 type check**: full woven checkout, `--target aarch64-linux-android` | The Android project type-checks for ARM64 | Linked `.so`, packaged APK, or successful install |
| **Linked build**: private Plus run or explicit local link/package | Actual native output or unsigned game APK; record which, build provenance, and mod hashes | Phone delivery/signing or gameplay |
| **Delivery/install**: Fix validates, signs, Android installs, intended game opens | That artifact works through delivery on that device | Feature acceptance, save/compatibility behavior |
| **Gameplay**: documented in-game test steps and results | Only tested behavior on the specified game, world and device | Other devices, mod combinations or servers |

Unit tests are separate evidence; log which logic they exercise. For `.hmod` and resource ZIP there is no weave/ARM64 build step: run archive + parser and then test the pack **in the game**. Mark not applicable vs not run.

## 1. Get the exact source and tools

Use a fresh location. A git checkout is required by the production `native_build.sh`; a verified archive of the same commit also works for the kit's local parser/stage/reference weave. Do not substitute an upstream default branch or its global `cargo horizon-mod`.

```sh
mkdir -p work
S="$PWD/work/starling"
STARLING_REV=ac874422ed8f892505ff73d67ae486ecfee7a516
MIXINS_REV=ddd9700b21997c95d95ac6ee5ecafe3830cf622a
git init -q "$S"
git -C "$S" fetch --depth=1 https://github.com/starling-client/starling.git "$STARLING_REV"
git -C "$S" checkout -q --detach FETCH_HEAD
test "$(git -C "$S" rev-parse HEAD)" = "$STARLING_REV"

# Reference test toolchain; the existing Plus runner installs live Rust stable.
rustup toolchain install 1.100.0 --profile minimal --target aarch64-linux-android
export RUSTUP_TOOLCHAIN=1.100.0
cargo build --locked --manifest-path "$S/Cargo.toml" -p cargo-horizon-mod --target-dir "$PWD/work/cli"
PACK="$PWD/work/cli/debug/cargo-horizon-mod"

# Native-only (can skip for .hmod or textures):
cargo install --locked --git https://github.com/horizon-rust/horizon-mixins --rev "$MIXINS_REV" \
  --root "$PWD/work/mixins-tool" horizon-mixins-cli
WEAVER="$PWD/work/mixins-tool/bin/horizon-mixins"
"$WEAVER" --version   # 0.6.0 at the pinned commit
```

See [source URLs](SOURCES.md) if `git fetch` is unavailable. Preserve the commits, Cargo lockfile and platform target. Rust 1.100.0 and NDK **28.2.13676358** were used for the example ARM64 check. The existing workflow additionally uses SDK `android-36`, Build Tools `35.0.0`, JDK 25 and `cargo-ndk` 3.5.4 for an APK build; those are not required to run the pack checker.

## 2. Package, hash and parse

Test the shipped references:

```sh
for f in examples/releases/*; do
  unzip -t "$f" && "$PACK" check "$f" || exit 1
done
sha256sum examples/releases/*
```

Create your own archive from a clean source tree (replace `projects/my_mod/...` with the real input):

```sh
# Native or resource: run the relevant line.
python3 tools/kit.py pack native projects/my_mod/bundle work/My-Mod-0.1.0.hnmod
python3 tools/kit.py pack resource projects/my_pack/pack work/My-Pack-0.1.0.zip

# Content: create a project, then edit horizon-mod.toml, assets/ and data/.
"$PACK" new projects/my_content
(cd projects/my_content && "$PACK" build)
"$PACK" check projects/my_content/target/horizon-mod/my_content.hmod
```

When you don't have Rust, `python3 tools/kit.py pack content projects/my_content work/My-Content-0.1.0.hmod` can assemble a **clean, content-only** tree. This is a layout check, not the upstream content checker; use `"$PACK" check ...` later. Keep README/license files outside the clean `pack/` directory for `.hmod` and texture packs. Run `unzip -t`, SHA-256 and `"$PACK" check` on the **exact** file you deliver. `check --json` can be used for machine-readable evidence (`"$PACK" check path --json`). ZIP byte-for-byte repeatability is with the same source/tooling; confirm rather than assuming it across ZIP implementations.

The pinned native Rust checker is stricter than Plus staging. `unknown field name` / `invalid native manifest` on an old Plus artifact can indicate extra manifest keys or a hyphenated ID, not a Rust compiler error. Use the normalized examples with matching metadata, IDs and explicit revision; don't “fix” eligibility by weakening the validator. A report of resource format `97.1` does not test the loaded textures.

## 3. Plus native staging and weave

Use only reviewed sources. No GitHub credentials, phone, uploads or compilation are involved in this local stage:

```sh
python3 tools/kit.py stage --starling-source "$S" --out work/reference-stage examples/releases/*.hnmod
# Replace the example glob with the actual set when testing a new mod.
python3 "$S/packaging/android/native_mod_permissions.py" work/reference-stage/job/mods/*
```

It creates `input.smb` (`SMB2`, then each archive's 4-byte big-endian length and bytes), checks the pinned parser hash and exact Plus staging script, and writes `mod-set.json` and `job/mods/`. The permission scan (e.g. `-`) is a limited source scan, not a security audit. A passed stage is **not** approval to execute a mod or a guarantee that a combination weaves.

For a **new** native mod, use a machine with enough RAM to index the pinned workspace, then follow [`packaging/android/native_build.sh`](https://github.com/starling-client/starling/blob/ac874422ed8f892505ff73d67ae486ecfee7a516/packaging/android/native_build.sh) on fresh copies. The stage preparation is important:

- Export the pristine committed Starling tree without symlinks; write the Starling commit to `.horizon-revision`. In its temporary indexing copy, redirect the `horizon-android` manifest entry from `../horizon-client/src/android_lib.rs` to an **empty** `plan-stub.rs`. Otherwise the weaver can see `game` under two crate identities. Temporarily remove the conditional `#![cfg_attr(not(target_os = "android"), forbid(unsafe_code))]` line from `crates/horizon-client/src/lib.rs` in that indexing copy so it can find the game module. Don't commit those prep edits to the mod or upstream.
- Fetch locked dependencies as needed (`cargo fetch --locked --manifest-path "$INDEX/Cargo.toml"`). Use a disposable copy of the staged mixins and apply upstream adaptation to it: `python3 "$S/packaging/android/native_mod_adapt.py" "$INDEX" "$MODS"`. The production build also normalizes explicit revision pins in its **copies**; start with matching pins in your actual package.
- With `$INDEX` the prepared pristine-source copy and `$MODS` the adapted directory of bundle folders, run:

  ```sh
  "$WEAVER" plan --workspace "$INDEX" --mods "$MODS" --out work/mod-plan.json
  "$WEAVER" apply --workspace "$INDEX" --mods "$MODS" --out work/mod-woven
  ```

- Use the woven source in the **complete** pinned workspace. Restore the Android manifest's real `android_lib.rs` target and remove `plan-stub.rs` before compiling. Prefer the unchanged sanctioned Plus workflow for an actual APK; don't run or link unknown native mods in a normal environment holding secrets.

Full indexing was killed in the original ~2 GiB environment. Keep the checkout on ordinary disk (not a RAM-backed `/tmp`), use `-j 1` for later Cargo checks, and use a larger runner for an unfamiliar mod rather than retrying the identical killed index. The next section is a narrow, tested alternative for these reference bundles only.

## 4. Reproduce the reference weave and ARM64 check

This helper confirms both archive hashes, stages/adapts them, and weaves **three byte-exact targets** with minimal manifests and empty stubs for unrelated modules. It reports 10 HEAD injections, 5 support modules and 1 state field. Never run `cargo check` on its stubbed tree and call it a game check.

```sh
python3 tools/weave_examples.py --starling-source "$S" --weaver "$WEAVER" \
  --out work/reference-weave

# Reproduce the full-source check by copying ONLY the transformed targets.
CHECK="$PWD/work/android-check"
mkdir "$CHECK"  # new directory
# If starting from the pinned tarball instead of Git, extract it here.
git -C "$S" archive --format=tar HEAD | tar -xf - -C "$CHECK"
for rel in \
  crates/horizon-client/src/game.rs \
  crates/horizon-client/src/game/native_hooks.rs \
  crates/horizon-client-render/src/particles.rs
do
  cmp "$CHECK/$rel" "work/reference-weave/targets/$rel" || exit 1
  cp "work/reference-weave/woven/$rel" "$CHECK/$rel"
done

# Linux x86_64 host. Set this to the installed NDK 28.2.13676358 directory.
export ANDROID_NDK_HOME="$ANDROID_HOME/ndk/28.2.13676358"
NDK_BIN="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64/bin"
export CC_aarch64_linux_android="$NDK_BIN/aarch64-linux-android26-clang"
export CXX_aarch64_linux_android="$NDK_BIN/aarch64-linux-android26-clang++"
export AR_aarch64_linux_android="$NDK_BIN/llvm-ar"
export CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER="$CC_aarch64_linux_android"
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_INCREMENTAL=0
export CARGO_TARGET_DIR="$PWD/work/android-target"

# Prime the locked Cargo cache if cold; offline checking cannot fetch missing crates.
cargo fetch --locked --manifest-path "$CHECK/Cargo.toml" --target aarch64-linux-android
cargo check --offline --locked -j 1 --manifest-path "$CHECK/Cargo.toml" \
  --target aarch64-linux-android -p horizon-android
```

A host-only `cargo check -p horizon-android` can exercise an empty target instead of game code. The ABI and full checkout above matter. This check does **not** link a game or phone APK. For Tornado's pure logic, independently run:

```sh
mkdir -p work
rustc --edition 2024 --test examples/tornado/bundle/mixins/starling_tornado/model.rs -o work/tornado-tests
work/tornado-tests
```

## 5. Finish with a smoke test and a handoff

Only when you have the user's permission and the necessary APK/device, follow [Install](INSTALL.md) and the relevant example smoke test. Record app version/ABI, artifact SHA-256, mod combination, world type, exact actions and actual outcomes in [a handoff entry](../templates/HANDOFF-ENTRY.md). If a private run succeeds and phone delivery fails, record them separately; recover the existing artifact instead of assuming a new compile is needed.
