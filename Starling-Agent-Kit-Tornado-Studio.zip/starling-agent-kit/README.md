# Starling Agent Kit

**Handoff v1.0.0** · Starling **v0.8.0** · Minecraft **Java 26.3** · Android **ARM64**

Give the next agent this folder or its ZIP—not the old conversation. It has the target revisions, editable source examples, installation routes, and a record of exactly what was tested.

## Start here

| Your agent can… | Give it… | Tell it to start with… |
|---|---|---|
| Read a repo or use a terminal | The `starling-agent-kit` folder or a clone of your shared kit repo | [`AGENTS.md`](AGENTS.md) → [`HANDOFF.md`](HANDOFF.md) → your new task |
| Only read chat uploads | `Starling-Agent-Kit-1.0.0.zip` | Paste the [starter prompt](START-HERE.md) and describe the mod you want. If the chat can't open ZIPs, attach the listed files individually. |

**The kit repository is not the build repository.** Use one Git master for project memory. Plus Fix requires a *separate private build repo* on GitHub. This folder contains a reference copy of its workflow as text, not an active workflow, Plus Fix APK, or game APK.

## New project: Tornado Studio 2.0.0

[Get Tornado Studio](projects/starling_tornado/README.md): one `/tornado` toggle, live settings, four shapes and custom smoke, mist and dust. Import its `.hnmod` into Plus Fix and its separate texture ZIP into the game. The original Tornado below remains a reference.

## Pick an output

| You want to… | Make this | Install with… | Reference |
|---|---|---|---|
| Change Rust behavior, add a command or custom render effect | `.hnmod` | **Plus Fix** → build/install **Starling Modded Plus** | [Tornado](examples/tornado/README.md), [Pocket Wrench](examples/pocket-wrench/README.md) |
| Add blocks/items using the game's declarative content API | `.hmod` | **The game** → **Options → Mods** or new-world mod selection | [Kit Marker](examples/kit_marker/README.md) |
| Change the look of existing content | Resource pack `.zip` | **The game** → **Options → Resource Packs** | [Mint Stick](examples/mint-stick/README.md) |

[Ready-to-import example files](examples/releases/) are separate from their editable sources. The original Tornado reference uses stock sprites. Studio 2.0 adds a separate optional resource pack for the new art. If a new mod needs code and art, supply separate packages and state whether each is required.

## Where to look

- [`AGENTS.md`](AGENTS.md) — standing rules; read first. [`HANDOFF.md`](HANDOFF.md) — what is current and what to do next.
- [`TARGETS.json`](TARGETS.json) — exact commits, Android target, game/API formats, Plus limits and workflow hash.
- [`docs/FORMATS.md`](docs/FORMATS.md) — package structure and how to choose a format.
- [`docs/VALIDATE.md`](docs/VALIDATE.md) — reproducible packaging, pinned parser, local Plus stage, weave, and ARM64 check commands.
- [`docs/INSTALL.md`](docs/INSTALL.md) — phone routes, private repo setup, and recovery. [`docs/SOURCES.md`](docs/SOURCES.md) — pinned source map.
- [`examples/VERIFICATION.md`](examples/VERIFICATION.md) — checksums and stage-by-stage results. No live private run, APK link, or phone gameplay is claimed for these examples.
- [`templates/TASK.md`](templates/TASK.md) and [`templates/HANDOFF-ENTRY.md`](templates/HANDOFF-ENTRY.md) — briefs and evidence records for the next mod.

## Keep it current

1. Put new shareable source and instructions in `projects/<id>/`, private scratch in `work/`. After a task, update `HANDOFF.md` with changed files, artifact hashes, checks actually run, and one concrete next step.
2. Review the diff and commit the update to the **kit master**. The workspace master has a local Git history; no remote or push is needed. An upload ZIP does not carry that history. Use your own Git identity if committing. Keep credentials, build receipts/logs, keys, APKs, user saves, and private material out of Git and ZIPs.
3. For upload-only chats, export the current master (Python 3.11+):

   ```sh
   python3 tools/kit.py export ../Starling-Agent-Kit-1.0.0.zip
   python3 tools/kit.py verify-export ../Starling-Agent-Kit-1.0.0.zip
   ```

   This exports the shareable paths **as they are on disk** (including edits not yet committed), with `SNAPSHOT.sha256`, not Git history. Review files before sharing; hashes help detect accidental changes, not establish trust. Use a new filename for a newer snapshot. When an upload-only agent returns changes, review and merge them into the one master before exporting again.
