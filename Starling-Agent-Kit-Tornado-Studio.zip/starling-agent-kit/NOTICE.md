# Source and asset notices

- **Tornado** is carried forward under the MIT notice in `examples/tornado/bundle/mixins/starling_tornado/LICENSE`. The kit variant changes bundle identity metadata, version labels and documentation.
- **Tornado Studio 2.0.0** extends Tornado under the license in `projects/starling_tornado/bundle/mixins/starling_tornado/LICENSE`. The Studio PNGs are original procedural art made by the included bake tool; the icon and offline preview compose those sprites. No game assets are included.
- **Pocket Wrench** is adapted from Starling's MIT-licensed Wrench example. The full copyright and license are preserved as `examples/pocket-wrench/bundle/mixins/pocket_wrench/LICENSE.txt` and inside the archive.
- **Kit Marker** adapts the Starling/Horizon pinned `cargo-horizon-mod` content template. Its upstream MIT license is included at `examples/kit_marker/LICENSE`. The example references game textures by name and does not carry them.
- **Mint Stick** supplies an original tiny pixel sprite and its generator; it contains no copied Minecraft art.
- The Plus workflow text and stage script are references from the builder project. `references/STARLING-LICENSE.txt` records the upstream license at this specific Starling revision. The kit contains no Minecraft binary or vanilla asset dump, game or builder APK, account data, or build credentials. Keep notices and review your rights before adding or publishing other assets.
