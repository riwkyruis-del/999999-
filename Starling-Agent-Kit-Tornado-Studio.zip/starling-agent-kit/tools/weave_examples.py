#!/usr/bin/env python3
"""Low-memory reference weave for the two kit-native examples; not a general builder."""

import argparse
import hashlib
import os
from pathlib import Path
import re
import subprocess
import sys

from kit import ROOT, STARLING, require

TARGET_FILES = {
    'crates/horizon-client/src/game.rs': '7bb0b0a026f53a1c72a1e928c2377c0d7ce755e961f93b06442516d01f2971c6',
    'crates/horizon-client/src/game/native_hooks.rs': 'd845cd1019e8f76afb8b72564a4cf1159bbcbfd5dbd35501ec07acee7a35ef49',
    'crates/horizon-client-render/src/particles.rs': 'afb90f24bef0f0803377205a84bd90814ac11f8938340f6c6d32be116ce22283',
}
EXAMPLES = {
    'Pocket-Wrench-0.1.1-starling-0.8.0.hnmod': 'ce4cdfeb6aa9a82237b3377b2a4ee59ad779402994acb74ce039b9222de01e9c',
    'Starling-Tornado-1.0.1-starling-0.8.0.hnmod': '299e8fe659021e2605a85d7c4114e08b20dc16bd4a6b8cdbc96d68996b81e18d',
}


def checked_read(path, digest):
    data = path.read_bytes()
    require(hashlib.sha256(data).hexdigest() == digest, f'not the kit reference bytes: {path}')
    return data


def put(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data if isinstance(data, bytes) else data.encode())


def weave(args):
    source, weaver, out = (p.resolve() for p in (args.starling_source, args.weaver, args.out))
    require(not out.exists() and not out.is_relative_to(source),
            'choose a fresh output directory outside the Starling source')
    files = {rel: checked_read(source / rel, digest) for rel, digest in TARGET_FILES.items()}
    archives = [ROOT / 'examples/releases' / name for name in EXAMPLES]
    for arc, sha in zip(archives, EXAMPLES.values(), strict=True):
        checked_read(arc, sha)
    out.mkdir(parents=True)
    subprocess.run([sys.executable, str(ROOT / 'tools/kit.py'), 'stage', '--starling-source',
                    str(source), '--out', str(out / 'stage'), *(str(p) for p in archives)], check=True)
    mods = out / 'stage/job/mods'
    android = source / 'packaging/android'
    subprocess.run([sys.executable, str(android / 'native_mod_permissions.py'),
                    *map(str, sorted(mods.iterdir()))], check=True)
    subprocess.run([sys.executable, str(android / 'native_mod_adapt.py'), str(source), str(mods)], check=True)
    src = out / 'targets'
    put(src / '.horizon-revision', STARLING['commit'] + '\n')
    put(src / 'Cargo.toml', '[workspace]\nresolver = "2"\nmembers = '
        '["crates/horizon-client", "crates/horizon-client-render"]\n')
    for name, module in [('horizon-client', 'game'), ('horizon-client-render', 'particles')]:
        cr = src / f'crates/{name}'
        put(cr / 'Cargo.toml', f'[package]\nname = "{name}"\nversion = "0.1.0"\nedition = "2024"\n')
        put(cr / 'src/lib.rs', f'pub mod {module};\n')
    # Only the indexed example targets are real modules. Names of unrelated modules in game.rs
    # remain resolvable as empty stubs; they are NOT used for type checking.
    for name in re.findall(r'^(?:pub(?:\([^)]*\))? )?mod ([A-Za-z_][A-Za-z0-9_]*);',
                           files['crates/horizon-client/src/game.rs'].decode('utf-8'), re.M):
        put(src / f'crates/horizon-client/src/game/{name}.rs', b'')
    for rel, data in files.items():
        put(src / rel, data)
    subprocess.run(['cargo', 'generate-lockfile', '--offline', '--manifest-path', str(src / 'Cargo.toml')],
                   check=True, env=dict(os.environ, CARGO_NET_OFFLINE='true'))
    common = ['--workspace', str(src), '--mods', str(mods)]
    subprocess.run([str(weaver), 'plan', *common, '--out', str(out / 'plan.json')], check=True)
    subprocess.run([str(weaver), 'apply', *common, '--out', str(out / 'woven')], check=True)
    print('Reference weave only. For an ARM64 check, copy ONLY these woven files into a complete pinned tree:')
    print('\n'.join(TARGET_FILES))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--starling-source', type=Path, required=True)
    p.add_argument('--weaver', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    try:
        weave(p.parse_args())
    except (OSError, ValueError, subprocess.CalledProcessError) as e:
        p.exit(1, f'error: {e}\n')


if __name__ == '__main__':
    main()
