#!/usr/bin/env python3
"""Package, stage, or export from the Starling Agent Kit (Python 3.11+)."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import struct
import subprocess
import sys
import tempfile
import tomllib
import zipfile

ROOT = Path(__file__).resolve().parent.parent
PINS = json.loads((ROOT / 'TARGETS.json').read_text(encoding='utf-8'))
STARLING, MIXINS, PLUS = (PINS[k] for k in ('starling', 'mixins', 'plus_fix'))
MIB = 1 << 20
KINDS = {'native': '.hnmod', 'content': '.hmod', 'resource': '.zip'}
# Only these paths participate in the shareable snapshot. Keep private material under work/.
EXPORT_FILES = ('.gitattributes', '.gitignore', 'README.md', 'AGENTS.md', 'HANDOFF.md',
                'START-HERE.md', 'TARGETS.json', 'NOTICE.md')
EXPORT_DIRS = ('docs', 'templates', 'references', 'examples', 'tools', 'projects')
EXPORT_SUFFIXES = {'.md', '.txt', '.json', '.mcmeta', '.toml', '.rs', '.py', '.png', '.ogg',
                   '.hnmod', '.hmod', '.zip'}
LOCAL_DIRS = {'__pycache__', 'target', '.cache', 'work', 'local', 'saves', 'receipts', 'diagnostics'}
SNAPSHOT = 'SNAPSHOT.sha256'


def require(ok, reason):
    if not ok:
        raise ValueError(reason)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def plain(rel):
    return ('\\' not in rel and ':' not in rel and '\0' not in rel
            and not any(part in ('', '.', '..') for part in rel.split('/'))
            and not any(ord(c) < 32 or ord(c) == 127 for c in rel))


def source_paths(root, exporting=False):
    require(root.is_dir() and not root.is_symlink(), f'not a plain source directory: {root}')
    def walk(folder):
        for path in sorted(folder.iterdir()):
            rel = path.relative_to(root).as_posix()
            if exporting and path.name in LOCAL_DIRS:
                continue
            require(plain(rel) and not path.is_symlink(), f'not a plain path: {rel}')
            if path.is_dir():
                require(not exporting or not path.name.startswith('.'), f'hidden directory in export: {rel}')
                yield from walk(path)
                continue
            require(path.is_file(), f'not a file: {rel}')
            if exporting:
                require(((path.suffix in EXPORT_SUFFIXES and not path.name.startswith('.'))
                         or path.name in {'LICENSE', 'COPYING', 'NOTICE', '.gitignore'})
                        and path.name != 'receipt.json',
                        f'unexpected shareable file: {rel}; keep private/build outputs under work/')
            yield rel, path
    yield from walk(root)


def unique_paths(files):
    require(len({n.casefold() for n in files}) == len(files), 'duplicate (case-insensitive) paths')


def native_layout(files):
    m = json.loads(files['horizon-native.json'])
    require(isinstance(m, dict), 'expected a JSON object in horizon-native.json')
    mod_id = m.get('id', '')
    require(isinstance(mod_id, str) and re.fullmatch('[a-z0-9][a-z0-9_]{0,63}', mod_id),
            'native id: start with a letter/digit, then lowercase letters, digits or underscores')
    fields = {'schema', 'id', 'version', 'game', 'horizon', 'mixins'}
    require(fields <= m.keys() <= fields | {'hooks'}, 'unknown or missing native manifest fields')
    require(type(m['schema']) is int and m['schema'] == PLUS['native_manifest_schema']
            and m['game'] == STARLING['java_game'] and m['horizon'] == STARLING['commit']
            and m['mixins'] == MIXINS['commit'], 'native manifest schema or target differs from TARGETS.json')
    require(isinstance(m['version'], str) and bool(m['version']), 'missing native version')
    require('hooks' not in m or (type(m['hooks']) is int and m['hooks'] > 0), 'invalid hooks value')
    prefix = f'mixins/{mod_id}/'
    require(all(n == 'horizon-native.json' or n.startswith(prefix) for n in files),
            'native bundle must be code-only: root manifest and one mixins/<id>/')
    t = tomllib.loads(files[f'{prefix}horizon-mixin.toml'].decode('utf-8'))
    require(t.get('mod', {}).get('id') == mod_id and t['mod'].get('version') == m['version']
            and t.get('compatibility', {}).get('horizon_revision') == m['horizon'],
            'native JSON and mixin TOML identity/version/revision must match')
    require(len(files) <= 512 and sum(map(len, files.values())) <= PLUS['expanded_archive_mib'] * MIB,
            'native bundle exceeds entry or expanded size limit')


def content_layout(files):
    m = tomllib.loads(files['horizon-mod.toml'].decode('utf-8'))
    require(re.fullmatch('[a-z0-9_]{1,64}', m.get('id', '')) and m.get('api') == STARLING['content_mod_api']
            and m.get('capabilities') == ['registries'] and m.get('side') in {'both', 'client', 'server'},
            'expected an API 0.2 registries content mod; check docs/FORMATS.md')
    require(all(n == 'horizon-mod.toml' or
                (n.startswith(('assets/', 'data/')) and len(n.split('/')) >= 3
                 and Path(n).suffix.lower() not in {'.wasm', '.rs', '.jar', '.so', '.dll', '.exe'})
                for n in files), 'keep only content under assets/ and data/ beside horizon-mod.toml')
    require(any(n.startswith(('assets/', 'data/')) for n in files), 'no content files')


def resource_layout(files):
    m = json.loads(files['pack.mcmeta'])['pack']
    require(isinstance(m, dict), 'expected a pack object in pack.mcmeta')
    want = STARLING['resource_pack_format']
    require(m.get('min_format') == want and m.get('max_format') == want,
            'pack.mcmeta min_format and max_format must match the pinned resource format')
    require(any(n.startswith('assets/') and len(n.split('/')) >= 3 for n in files), 'no namespaced assets/')
    require(all(n in {'pack.mcmeta', 'pack.png'} or n.startswith('assets/') for n in files),
            'resource pack should contain only pack.mcmeta, optional pack.png, and assets/')


def write_zip(out, files, compressed_limit=None):
    unique_paths(files)
    out.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix='.kit-', suffix='.tmp', dir=out.parent)
    os.close(fd)
    scratch = Path(temp)
    try:
        with zipfile.ZipFile(scratch, 'w') as z:
            for name, data in sorted(files.items()):
                info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
                info.create_system = 3
                info.external_attr = (stat.S_IFREG | 0o644) << 16
                z.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        require(compressed_limit is None or scratch.stat().st_size <= compressed_limit,
                'native archive exceeds archive size limit')
        os.replace(scratch, out)
    finally:
        scratch.unlink(missing_ok=True)
    print(f'{out}: {out.stat().st_size:,} bytes, SHA-256 {sha(out.read_bytes())}')


def pack(args):
    src, out = args.source, args.output.resolve()
    require(out.suffix == KINDS[args.kind], f'output must end in {KINDS[args.kind]}')
    require(not out.is_relative_to(src.resolve()), 'output must be outside the source directory')
    paths = dict(source_paths(src))
    require(sum(p.stat().st_size for p in paths.values()) <= 64 * MIB, 'source files exceed 64 MiB')
    files = {n: p.read_bytes() for n, p in paths.items()}
    {'native': native_layout, 'content': content_layout, 'resource': resource_layout}[args.kind](files)
    write_zip(out, files, PLUS['archive_mib'] * MIB if args.kind == 'native' else None)
    print('Packaged only. Run the pinned parser and any build/runtime checks separately.')


def stage(args):
    out = args.out.resolve()
    require(not out.exists(), f'choose a new stage output directory: {out}')
    parser = (args.starling_source / 'packaging/android/mod_build_server.py').read_bytes()
    require(sha(parser) == PLUS['upstream_parser_sha256'], 'upstream parser differs from TARGETS.json')
    script = ROOT / 'tools/plus_stage.py'
    require(sha(script.read_bytes()) == PLUS['local_stage_sha256'], 'Plus stage script differs from TARGETS.json')
    require(1 <= len(args.mods) <= PLUS['max_mods'], 'expected 1–4 native archives')
    payload = bytearray(b'SMB2')
    for archive in args.mods:
        require(archive.suffix == '.hnmod' and archive.is_file()
                and 0 < archive.stat().st_size <= PLUS['archive_mib'] * MIB,
                f'not a .hnmod of allowed size: {archive}')
        data = archive.read_bytes()
        payload += struct.pack('>I', len(data))
        payload += data
    require(len(payload) <= PLUS['upload_mib'] * MIB, 'mod set exceeds framed upload size limit')
    out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.stage-', dir=out.parent) as temp:
        job = Path(temp) / 'stage'
        source = job / 'source/packaging/android'
        source.mkdir(parents=True)
        (source / 'mod_build_server.py').write_bytes(parser)
        (job / 'input.smb').write_bytes(payload)
        subprocess.run([sys.executable, str(script)], check=True, env=dict(os.environ,
                       SBUILD_ROOT=str(job), SBUILD_SHA=sha(payload), SBUILD_COMMIT=STARLING['commit'],
                       PYTHONDONTWRITEBYTECODE='1'))
        shutil.rmtree(job / 'source')
        job.rename(out)
    print(f'Plus stage only (no weave or compile): {out / "mod-set.json"}')
    print((out / 'mod-set.json').read_text(encoding='utf-8').strip())


def export(args):
    out = args.output.resolve()
    require(out.suffix == '.zip' and not out.is_relative_to(ROOT), 'write the kit ZIP outside the kit folder')
    files = {}
    for name in EXPORT_FILES:
        p = ROOT / name
        require(p.is_file() and not p.is_symlink(), f'not a plain kit file: {p}')
        files[name] = p.read_bytes()
    for d in EXPORT_DIRS:
        if (ROOT / d).exists() or (ROOT / d).is_symlink():
            files.update({f'{d}/{n}': p.read_bytes() for n, p in source_paths(ROOT / d, exporting=True)})
    files[SNAPSHOT] = ''.join(f'{sha(data)}  {name}\n' for name, data in sorted(files.items())).encode()
    write_zip(out, {f'starling-agent-kit/{n}': data for n, data in files.items()})


def verify(args):
    with zipfile.ZipFile(args.archive) as z:
        prefix = 'starling-agent-kit/'
        names = z.namelist()
        require(len(set(names)) == len(names) and all(n.startswith(prefix) and plain(n) for n in names),
                'unexpected ZIP path or duplicate')
        unique_paths(names)
        require(all(stat.S_IFMT(i.external_attr >> 16) == stat.S_IFREG for i in z.infolist()),
                'snapshot contains non-regular entries')
        expected = {}
        for line in z.read(prefix + SNAPSHOT).decode().splitlines():
            digest, name = line.split('  ', 1)
            require(plain(name) and name not in expected and name != SNAPSHOT
                    and re.fullmatch('[a-f0-9]{64}', digest), 'malformed snapshot manifest')
            expected[name] = digest
        require(set(names) == {prefix + n for n in (*expected, SNAPSHOT)}, 'snapshot file list differs')
        require(set(EXPORT_FILES) <= expected.keys(), 'snapshot is missing kit files')
        for name, digest in expected.items():
            require(sha(z.read(prefix + name)) == digest, f'snapshot checksum differs: {name}')
    print(f'Snapshot OK: {len(expected)} files match {SNAPSHOT} (integrity, not a signature).')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    commands = p.add_subparsers(required=True)
    c = commands.add_parser('pack', help='make an archive from a clean source tree')
    c.add_argument('kind', choices=KINDS)
    c.add_argument('source', type=Path)
    c.add_argument('output', type=Path)
    c.set_defaults(run=pack)
    c = commands.add_parser('stage', help='run the exact Plus staging step, offline')
    c.add_argument('--starling-source', type=Path, required=True)
    c.add_argument('--out', type=Path, required=True)
    c.add_argument('mods', type=Path, nargs='+')
    c.set_defaults(run=stage)
    c = commands.add_parser('export', help='export selected shareable files without Git history')
    c.add_argument('output', type=Path)
    c.set_defaults(run=export)
    c = commands.add_parser('verify-export', help='check the exported file list and hashes')
    c.add_argument('archive', type=Path)
    c.set_defaults(run=verify)
    args = p.parse_args()
    try:
        args.run(args)
    except (OSError, TypeError, KeyError, ValueError, zipfile.BadZipFile, subprocess.CalledProcessError) as e:
        p.exit(1, f'error: {e}\n')


if __name__ == '__main__':
    main()
