"""Stage a bounded Plus mod set using the pinned upstream bundle parser. No code runs here."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import struct
import tomllib
import zipfile

MAX_INPUT = 32 << 20
MAX_MOD = 16 << 20
MAX_EXPANDED = 64 << 20
MAX_SET_EXPANDED = 128 << 20
MAX_MODS = 4
ID = re.compile(r'[a-z0-9][a-z0-9_-]{0,63}')
REV = re.compile(r'[a-f0-9]{40}')
MIXINS = 'ddd9700b21997c95d95ac6ee5ecafe3830cf622a'


def metadata(archive):
    with zipfile.ZipFile(archive) as z:
        entries = z.infolist()
        names = [i.filename for i in entries]
        files = [i for i in entries if not i.is_dir()]
        expanded = sum(i.file_size for i in files)
        if (len(names) != len(set(names)) or len(entries) > 768
                or len(files) > 512 or expanded > MAX_EXPANDED):
            raise ValueError('A .hnmod has too many entries, duplicate paths or too much uncompressed data.')
        file_names = {i.filename for i in files}
        for i in entries:
            parts = i.filename.removesuffix('/').split('/')
            if (len(i.filename) > 360 or re.search(r'[:\\\x00-\x1f\x7f]', i.filename)
                    or any(p in ('.', '..', '') for p in parts)
                    or any('/'.join(parts[:k]) in file_names for k in range(1, len(parts)))
                    or (i.is_dir() and i.filename[:-1] in file_names)):
                raise ValueError('A .hnmod has an invalid or conflicting path.')
            kind = stat.S_IFMT(i.external_attr >> 16)
            if i.flag_bits & 1 or kind not in (0, stat.S_IFDIR if i.is_dir() else stat.S_IFREG):
                raise ValueError('Encrypted entries, links and special files are not supported.')
        if 'horizon-mod.toml' in names or any(n.startswith(('assets/', 'data/')) for n in file_names):
            raise ValueError('Choose code-only .hnmods. Separate content packs are not supported.')
        info = z.getinfo('horizon-native.json')
        if info.is_dir() or not 0 < info.file_size <= 65536:
            raise ValueError('The native mod manifest is missing or too large.')
        manifest = json.loads(z.read(info))
        if not (isinstance(manifest, dict) and type(manifest.get('schema')) is int and manifest['schema'] == 1
                and isinstance(manifest.get('id'), str) and ID.fullmatch(manifest['id'])
                and isinstance(manifest.get('version'), str) and 0 < len(manifest['version']) <= 128
                and not re.search(r'[\x00-\x1f\x7f]', manifest['version'])
                and all(isinstance(manifest.get(k), str) and REV.fullmatch(manifest[k]) for k in ('horizon', 'mixins'))):
            raise ValueError('Expected a schema 1 .hnmod with an ID, version and both 40-character revision pins.')
        if manifest.get('game') != '26.3':
            raise ValueError('This .hnmod is not for Minecraft Java 26.3.')
        mixin = z.getinfo('mixins/' + manifest['id'] + '/horizon-mixin.toml')
        if mixin.is_dir() or not 0 < mixin.file_size <= 256 * 1024:
            raise ValueError('The mixin manifest is missing or too large.')
    return manifest, expanded


def stage(root):
    pack = root / 'input.smb'
    if not 0 < pack.stat().st_size <= MAX_INPUT:
        raise ValueError('Plus mod sets must be no larger than 32 MiB.')
    expected = os.environ['SBUILD_SHA']
    with pack.open('rb') as f:
        if hashlib.file_digest(f, 'sha256').hexdigest() != expected:
            raise ValueError('The received mod set failed its SHA-256 check.')
    src = root / 'source' / 'packaging' / 'android' / 'mod_build_server.py'
    spec = importlib.util.spec_from_file_location('starling_checked_bundle', src)
    upstream = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(upstream)
    stage_dir = root / 'validated'
    stage_dir.mkdir()
    picked, modules, heads = {}, {}, {}
    expanded = 0
    with pack.open('rb') as f:
        if f.read(4) != b'SMB2':
            raise ValueError('Not a Plus mod set. Use the Plus app and workflow together.')
        while (header := f.read(4)):
            if len(header) != 4 or len(picked) >= MAX_MODS:
                raise ValueError('A mod set must contain one to four complete bundles.')
            size, = struct.unpack('>I', header)
            if not 0 < size <= MAX_MOD:
                raise ValueError('Each .hnmod must be no larger than 16 MiB.')
            data = f.read(size)
            if len(data) != size:
                raise ValueError('The mod-set upload was cut short.')
            archive = stage_dir / 'current.hnmod'
            archive.write_bytes(data)
            sha = hashlib.sha256(data).hexdigest()
            del data
            manifest, size = metadata(archive)
            mid = manifest['id']
            if mid in picked:
                raise ValueError(f'Two mods use the ID {mid}. Choose only one version of that mod.')
            expanded += size
            if expanded > MAX_SET_EXPANDED:
                raise ValueError('The combined uncompressed mod set is larger than 128 MiB.')
            validated_id, files = upstream.read_bundle(archive)
            archive.unlink()
            bundle = tomllib.loads(files['horizon-mixin.toml'].decode('utf-8'))
            if validated_id != mid or bundle['mod']['id'] != mid or bundle['mod']['version'] != manifest['version']:
                raise ValueError(f'The two manifests in {mid} disagree on its ID or version.')
            for entry in bundle.get('module', []):
                target = (entry['file'], entry['name'])
                other = modules.get(target)
                if other:
                    raise ValueError(f'{mid} and {other} declare the same Rust module in the same file. Try building them separately.')
                modules[target] = mid
            for hook in bundle.get('injection', []):
                if hook.get('kind') == 'HEAD' and hook.get('cancellable') is True and isinstance(hook.get('target'), str):
                    target = hook['target']
                    other = heads.setdefault(target, mid)
                    if other != mid:
                        print(f'Compatibility note: {other} and {mid} can both cancel the same HEAD hook. Test them separately if behavior is unexpected.')
            dest = stage_dir / 'mods' / mid
            dest.mkdir(parents=True)
            for rel, contents in files.items():
                path = dest / rel
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(contents)
            picked[mid] = {'id': mid, 'version': manifest['version'], 'sha256': sha}
            if manifest['horizon'] != os.environ['SBUILD_COMMIT'] or manifest['mixins'] != MIXINS:
                print(f'Compatibility note: {mid} declares different revision pins. Compilation can still fail.')
            del files
    if not picked:
        raise ValueError('Select at least one .hnmod.')
    (stage_dir / 'out').mkdir()
    stage_dir.rename(root / 'job')
    (root / 'mod-set.json').write_text(json.dumps([picked[key] for key in sorted(picked)]), encoding='utf-8')
    print(f'Validated {len(picked)} selected mod(s): ' + ', '.join(sorted(picked)))


if __name__ == '__main__':
    try:
        stage(Path(os.environ['SBUILD_ROOT']))
    except Exception as exc:
        message = re.sub(r'[\x00-\x1f\x7f]', ' ', str(exc))
        raise SystemExit('Invalid mod set: ' + message[:600]) from None
