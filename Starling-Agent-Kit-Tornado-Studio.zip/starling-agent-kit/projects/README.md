# New mods go here

Create one folder per mod or pack (e.g. `projects/my_mod/`). Keep a short feature/readme with controls, install/disable instructions and a smoke test; put the clean package source in `bundle/` (`.hnmod`) or `pack/` (`.hmod` / resource ZIP), and record evidence with the release's SHA-256. Keep generated build caches, private inputs, saves and logs under `work/` instead.

Start with the [task brief](../templates/TASK.md) and append a [handoff entry](../templates/HANDOFF-ENTRY.md) when done or blocked. Do not alter the shipped reference examples just to make a new project.
