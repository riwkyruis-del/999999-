# Tornado Studio 2.0.0 · evidence

**Target:** Starling v0.8.0 (`ac874422ed8f892505ff73d67ae486ecfee7a516`), horizon-mixins 0.6.0 (`ddd9700b21997c95d95ac6ee5ecafe3830cf622a`), Java 26.3, Android `arm64-v8a`. Resource pack format 97.1.

| Artifact | Bytes | SHA-256 |
|---|---:|---|
| [Starling-Tornado-Studio-2.0.0-starling-0.8.0.hnmod](releases/Starling-Tornado-Studio-2.0.0-starling-0.8.0.hnmod) | 19,991 | `b42983dff98d0a606c90f942a061a036c7b53567ddbf67535cbbeb09a52d167b` |
| [Starling-Tornado-Studio-Textures-2.0.0-java-26.3.zip](releases/Starling-Tornado-Studio-Textures-2.0.0-java-26.3.zip) | 258,912 | `051d1f55f6ad931e50f55aec1a8e377e6fa023d11b5969e0dd9ea6fe412be8d2` |

| Stage | Evidence |
|---|---|
| Package and parse | Both reproduced byte-for-byte from the shipped source, passed `unzip -t` and the pinned `cargo-horizon-mod check`. All 12 texture tiles decoded as 224×224 RGBA, match the renderer's namespaced atlas keys, and have a zero-alpha border. Pack includes no `assets/minecraft/`. |
| Unit tests | 9 passed: one command, settings round trips, seeded variation, distinctive profiles, live retune continuity, exact expiry, LOD/dust and particle budget bounds. |
| Plus stage | Passed with [`pocket_wrench` 0.1.1](../../examples/releases/Pocket-Wrench-0.1.1-starling-0.8.0.hnmod) (`ce4cdfeb6aa9a82237b3377b2a4ee59ad779402994acb74ce039b9222de01e9c`); no extra detected permissions. The ZIP is game content and was not sent to native stage. |
| Weave | Pinned `plan` and `apply`: Studio 9 HEAD hooks, 4 support modules and 1 state; 13 HEAD hooks and 6 modules with Wrench. Four pristine target files indexed with unrelated modules stubbed; only those four transformed files went into the complete pinned checkout. |
| WGSL static validation | Vendored Naga accepted the patched entity shader, static entities, both OIT concatenations and the GLES lowering. Only marked tornado quads get the smaller alpha cutoff and optional manual bilinear taps. This is shader-source validation, not a GPU/device test. |
| Final full Android ARM64 type check | Passed (`exit 0`) for the complete woven source and the paired set, Rust 1.100.0 · NDK 28.2.13676358/API 26. |
| APK link, live GitHub run, phone installation and gameplay | **Not run.** The art preview composites real project geometry and tiles offline, not screenshots of the Android app. |

## Reproduce the checks

Use [the kit tool setup](../../docs/VALIDATE.md#1-get-the-exact-source-and-tools) to set `$S`, `$PACK` and `$WEAVER` to the **pinned** checkout, pack checker and weaver. The 2 GiB sandbox could not index the full upstream tree; the helper below is specific to these targets, not a general substitute for a production build. Run from the kit root:

```sh
P=projects/starling_tornado
for f in "$P"/releases/*; do unzip -t "$f" && "$PACK" check "$f" || exit 1; done
python3 "$P/tools/check_shader.py" --starling-source "$S" --out work/studio-shader-check
python3 "$P/tools/weave_release.py" --starling-source "$S" --weaver "$WEAVER" --out work/studio-weave

# $S is a pristine Git checkout of the exact commit. If using the pinned source
# tarball instead, extract it here. Never compile the helper's stub index.
CHECK="$PWD/work/android-studio"
mkdir "$CHECK"
git -C "$S" archive --format=tar HEAD | tar -xf - -C "$CHECK"
while IFS= read -r file; do
  cmp "$CHECK/$file" "work/studio-weave/targets/$file" || exit 1
  cp "work/studio-weave/woven/$file" "$CHECK/$file"
done < work/studio-weave/targets.txt

# Set the Rust 1.100.0/NDK 28.2.13676358/API 26 vars and prime the locked cache
# per docs/VALIDATE.md, then run the complete woven tree's ARM64 type check.
cargo check --offline --locked -j 1 --manifest-path "$CHECK/Cargo.toml" \
  --target aarch64-linux-android -p horizon-android
```

The initial sketch used a `RETURN` modifier on `gfx::entity_shader`; the weaver rejected the `include_str!` return operand with `E_UNSUPPORTED_MACRO`. The shipped helper is a boundary HEAD that recreates the exact pinned base WGSL and applies a checked single-site patch. It changes neither the shared atlas nor the stock alpha rules for unmarked quads. Other mods replacing that same shader constructor may conflict; don't assume compatibility beyond the tested pair.
