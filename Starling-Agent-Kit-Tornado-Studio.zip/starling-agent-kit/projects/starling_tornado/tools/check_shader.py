#!/usr/bin/env python3
"""Validate the patched WGSL with Starling's vendored Naga; no GPU required."""
import argparse
import json
from pathlib import Path
import subprocess

PROJECT = Path(__file__).resolve().parents[1]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--starling-source', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    args = p.parse_args()
    s, out = args.starling_source.resolve(), args.out.resolve()
    render = s / 'crates/horizon-client-render/src'
    patch = PROJECT / 'bundle/mixins/starling_tornado/shader_source.rs'
    cargo = '[package]\nname = "tornado-studio-shader-check"\nversion = "0.1.0"\nedition = "2024"\n'
    cargo += '[dependencies]\nnaga = { path = ' + json.dumps(str(s / 'third_party/naga')) + ', features = ["wgsl-in"] }\n'
    src = out / 'src'
    src.mkdir(parents=True)
    (out / 'Cargo.toml').write_text(cargo)
    modules = {'overlay': render / 'overlay.rs', 'studio': patch,
               'entity_source': render / 'gfx/entity_source.rs', 'terrain_source': render / 'gfx/terrain_source.rs'}
    prelude = ''.join(f'#[path = {json.dumps(str(path))}]\nmod {name};\n' for name, path in modules.items())
    for name in ('entity', 'static_entity', 'oit', 'oit_features', 'oit_clouds'):
        prelude += f'const {name.upper()}: &str = include_str!({json.dumps(str(render / (name + ".wgsl")))});\n'
    (src / 'main.rs').write_text(prelude + '''
fn validate(name: &str, wgsl: &str) {
    let module = naga::front::wgsl::parse_str(wgsl).unwrap_or_else(|e| panic!("{name}: {}", e.emit_to_string(wgsl)));
    naga::valid::Validator::new(naga::valid::ValidationFlags::all(), naga::valid::Capabilities::all())
        .validate(&module).unwrap_or_else(|e| panic!("{name}: {e:?}"));
    println!("{name}: {} WGSL entry points", module.entry_points.len());
}
fn main() {
    let base = overlay::wgsl_constants() + ENTITY;
    let studio = studio::patch(base.clone());
    assert_ne!(studio, base, "patch did not match pinned shader");
    assert_eq!(studio.matches("let tornado_soft").count(), 1);
    assert_eq!(studio::patch(studio.clone()), studio, "patch must be idempotent");
    assert_eq!(studio::patch("modified".into()), "modified");
    validate("Entity", &studio);
    validate("Static entity", &(studio.clone() + STATIC_ENTITY));
    validate("OIT features", &(studio.clone() + OIT + OIT_FEATURES));
    validate("OIT clouds", &(studio.clone() + OIT + OIT_CLOUDS));
    validate("GLES-lowered entity", &terrain_source::gles_uniforms(&entity_source::legacy_overlay(&studio)));
}
''')
    subprocess.run(['cargo', 'run', '--offline', '-j', '1', '--manifest-path', str(out / 'Cargo.toml')], check=True)


if __name__ == '__main__':
    main()
