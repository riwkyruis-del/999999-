#!/usr/bin/env python3
"""Bake 12 original RGBA sprites by integrating small 3D vapor volumes.

Offline authoring only, no game files or external art. Needs NumPy + Pillow.
Sample the light's optical depth above each voxel, then integrate scattering
back to front using Beer-Lambert extinction, retaining unassociated alpha.
"""
from pathlib import Path

import numpy as np
from PIL import Image

SIDE, STEPS = 224, 48
ROOT = Path(__file__).resolve().parent.parent / 'pack'
NS = 'starling_tornado'
OUT = ROOT / f'assets/{NS}/textures/particle'


def smooth(t):
    t = np.clip(t, 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def lattice(rng, x, y, z, frequency):
    """Smooth 3-D value noise; every mip of detail has an independent grid."""
    p = [u * frequency + rng.uniform(1, 31) for u in (x, y, z)]
    i = [np.floor(u).astype('int32') for u in p]
    a, b, c = [smooth((q - j).astype('float32')) for q, j in zip(p, i, strict=True)]
    i, j, k = [s % 48 for s in i]
    ip, jp, kp = (i + 1) % 48, (j + 1) % 48, (k + 1) % 48
    g = rng.random((48, 48, 48), dtype='float32')
    mix = lambda l, r, w: l + (r - l) * w
    near = mix(mix(g[k, j, i], g[k, j, ip], a), mix(g[k, jp, i], g[k, jp, ip], a), b)
    far = mix(mix(g[kp, j, i], g[kp, j, ip], a), mix(g[kp, jp, i], g[kp, jp, ip], a), b)
    return mix(near, far, c)


def bake(kind, index):
    setup = {'cloud': (0, 2.2, 1.0), 'mist': (700, 1.35, 0.56), 'dust': (1300, 2.7, 0.67)}
    key, extinction, thickness = setup[kind]
    rng = np.random.default_rng(43017 + key + 923 * index)
    px = (np.arange(SIDE, dtype='float32') + 0.5) * (2 / SIDE) - 1
    z_ray = np.linspace(-1.03, 1.03, STEPS, dtype='float32')
    x, y, z = px[None, None, :], -px[None, :, None], z_ray[:, None, None]
    # Break symmetry before evaluating the density; elongated ribbons for the wisps.
    twist = rng.uniform(-0.36, 0.36) + (0.22 if kind == 'mist' else 0)
    y1 = (y + twist * x + 0.08 * np.sin(3.8 * x + index)) / thickness
    x1 = x + 0.12 * np.sin(4.5 * y + 2.0 * z + index)
    shell = np.zeros((STEPS, SIDE, SIDE), dtype='float32')
    # Union several off-axis elliptical eddies into a multi-lobed volume.
    for lobe in range(12 if kind == 'dust' else 10):
        at = 2 * np.pi * (lobe / 10.0) + rng.uniform(-0.36, 0.36)
        ring = 0 if lobe == 0 else rng.uniform(0.2, 0.64)
        cx, cy = np.cos(at) * ring, np.sin(at) * ring * 0.73
        cz = rng.uniform(-0.47, 0.47)
        sx, sy, sz = rng.uniform(0.23, 0.55, size=3)
        if lobe == 0:
            sx, sy, sz = 0.53, 0.46, 0.37
        q = ((x1 - cx) / sx) ** 2 + ((y1 - cy) / sy) ** 2 + ((z - cz) / sz) ** 2
        shell += np.maximum(0.0, 1.0 - q * 0.48) ** 2
    coords = (x1, y1 + 0.11 * z, z)
    coarse = lattice(rng, *coords, 3.2)
    fine = lattice(rng, *coords, 8.1)
    detail = lattice(rng, *coords, 18.0)
    grit = lattice(rng, *coords, 35.0)
    fbm = 0.46 * coarse + 0.27 * fine + 0.18 * detail + 0.09 * grit
    # Fractal erosion keeps smaller billows and filament gaps visible at the edge.
    density = np.clip(shell * (0.79 + fbm * 0.57) - (1.0 - fbm) * 0.59, 0.0, 1.48)
    density *= (0.37 + 1.50 * fbm) * (0.58 + 0.70 * detail)
    if kind == 'mist':
        density *= 0.77 + 0.23 * np.cos(y1 * 12 + x1 * 3.4 + z * 4.5)
    # Transparent guard band: isolation even if a mobile atlas halves the tile.
    vignette = (1.0 - smooth((np.abs(x) - 0.76) / 0.20)) * (1.0 - smooth((np.abs(y) - 0.76) / 0.20))
    density *= vignette
    optical_step = 2.06 / STEPS
    occlusion = np.zeros_like(density)
    # Sample a broad light from upper-left/front, plus room for skylight below.
    for r in (1, 3, 7, 13, 21, 31):
        dx, dy, dz = r // 2 + 1, r, r // 4 + 1
        occlusion[dz:, dy:, dx:] += density[:-dz, :-dy, :-dx] * (0.20 + r * 0.022)
    sun = np.exp(-occlusion * 1.37)
    radiance = np.clip(0.36 + 0.57 * sun + 0.079 * fbm + 0.04 * y, 0.0, 1.0)
    incoming = 1.0 - np.exp((-extinction * optical_step) * density)
    # The eye is at the negative-z end. Transmittance drops across the volume.
    trans = np.cumprod(1.0 - incoming, axis=0)
    transmission_before = np.concatenate((np.ones_like(trans[:1]), trans[:-1]), axis=0)
    weight = incoming * transmission_before
    alpha = 1.0 - trans[-1]
    received = np.sum(weight * radiance, axis=0)
    linear_color = np.divide(received, alpha, out=np.full_like(alpha, 0.78), where=alpha > 1e-5)
    rgb = np.clip(linear_color, 0.0, 1.0)
    # Neutral sprite plates so the in-game palette remains adjustable.
    rgba = np.stack((rgb, rgb, rgb, alpha), axis=-1)
    return Image.fromarray(np.round(rgba * 255.0).clip(0, 255).astype('uint8'))


def main():
    OUT.mkdir(exist_ok=True, parents=True)
    for kind in ('cloud', 'mist', 'dust'):
        for index in range(4):
            dst = OUT / f'{kind}_{index}.png'
            bake(kind, index).save(dst, compress_level=9)
            print(f'{dst.name}: {dst.stat().st_size:,} bytes', flush=True)


if __name__ == '__main__':
    main()
