// Offline geometry snapshot for preview_art.py, not part of the native bundle.
#[allow(dead_code)]
#[path = "../bundle/mixins/starling_tornado/model.rs"]
mod model;

fn main() {
    let encoded = std::env::args()
        .nth(1)
        .expect("supply a studio-1 preference record");
    let prefs = model::Preferences::decode(&encoded).expect("valid studio settings");
    let mut s = model::Storm::new([0.0; 3], prefs, 9_341_223).unwrap();
    for _ in 0..104 {
        s.advance();
    }
    for p in s.frame(0.5, 0, 1.0).puffs() {
        let [x, y, z] = p.at;
        let [r, g, b, a] = p.color;
        println!(
            "{x},{y},{z},{},{},{},{},{},{r},{g},{b},{a}",
            p.half_width, p.half_height, p.roll, p.sprite as u32, p.tile
        );
    }
}
