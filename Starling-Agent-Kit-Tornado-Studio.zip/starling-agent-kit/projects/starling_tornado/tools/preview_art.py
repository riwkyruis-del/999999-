#!/usr/bin/env python3
"""Composite the actual sprite tiles and Rust geometry into an offline art preview."""
import argparse
from pathlib import Path
import subprocess

import numpy as np
from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
SKINS = HERE.parent / 'pack/assets/starling_tornado/textures/particle'


def paint(base, rows, eye, focus, center, lens):
    direction = focus - eye
    direction /= np.linalg.norm(direction)
    right = np.cross(direction, [0, 1, 0])
    right /= np.linalg.norm(right)
    up = np.cross(right, direction)
    seen = []
    for row in rows:
        pos = np.asarray(row[:3]) - eye
        z = float(pos @ direction)
        if z <= 0.5:
            continue
        seen.append((z, float(pos @ right), float(pos @ up), row))
    textures = [[Image.open(SKINS / f'{stem}_{i}.png').convert('RGBA') for i in range(4)]
                for stem in ('cloud', 'mist', 'dust')]
    for z, x, y, row in sorted(seen, key=lambda r: -r[0]):
        w, h, angle, kind, tile, r, g, b, a = row[3:]
        if a < 0.008:
            continue
        tex = textures[int(kind)][int(tile)]
        scale = lens / z
        tex = tex.resize((max(1, round(2 * w * scale)), max(1, round(2 * h * scale))), Image.Resampling.BILINEAR)
        tint = np.asarray((r, g, b, a), dtype='float32')
        tex = Image.fromarray(np.round(np.array(tex) * tint).astype('uint8'))
        tex = tex.rotate(np.degrees(angle), resample=Image.Resampling.BICUBIC, expand=True)
        pixel = (round(center[0] + x * scale - tex.width / 2), round(center[1] - y * scale - tex.height / 2))
        base.alpha_composite(tex, pixel)


def background(width, height):
    x = np.linspace(0, 1, width)[None, :]
    y = np.linspace(0, 1, height)[:, None]
    sky_a = np.array([72, 97, 113]); sky_b = np.array([187, 193, 185])
    v = np.clip(0.84 * (y / 0.79) ** 1.2 + 0.21 * x, 0, 1)
    rgb = sky_a + v[:, :, None] * (sky_b - sky_a)
    field_line = 0.745 - np.sin(x * 18 + .3) * 0.013 - np.sin(x * 39) * 0.008
    field = y > field_line
    ground = np.array([84, 104, 90]) - np.clip(y - 0.8, 0, 0.25)[:, :, None] * np.array([160, 147, 116])
    rgb = np.where(field[:, :, None], ground, rgb)
    return Image.fromarray(rgb.astype('uint8')).convert('RGBA')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--sample', type=Path, required=True, help='compiled frame_sample.rs')
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--prefs', default='studio-1 1 3 1 0 2 2 2 2')
    p.add_argument('--icon', type=Path, help='also make a square pack icon')
    args = p.parse_args()
    pixels = subprocess.check_output([str(args.sample.resolve()), args.prefs], text=True)
    rows = [tuple(map(float, ln.split(','))) for ln in pixels.splitlines()]
    img = background(1080, 660)
    paint(img, rows, np.asarray([37., 4.7, -11.]), np.asarray([0., 10.2, 0.]), (673., 334.), 665.)
    d = ImageDraw.Draw(img)
    font = lambda size: ImageFont.truetype('DejaVuSans.ttf', size)
    d.text((43, 35), 'S T A R L I N G   /   T O R N A D O   S T U D I O', font=font(15), fill='#ffffff')
    d.text((44, 105), 'Tornado\nStudio', font=font(57), fill='#ffffff', spacing=-4)
    d.text((46, 252), 'Original smoke, mist and dust\ncomposited from the mod assets.', font=font(17), fill='#eef9fc', spacing=7)
    d.text((45, 612), 'OFFLINE ART PREVIEW  ·  NOT AN IN-GAME SCREENSHOT', font=font(15), fill='#ffffff')
    args.out.parent.mkdir(parents=True, exist_ok=True)
    img.convert('RGB').save(args.out, compress_level=7)
    if args.icon is not None:
        icon = background(128, 128)
        paint(icon, rows, np.asarray([37., 4.7, -11.]), np.asarray([0., 10.2, 0.]), (64., 61.), 158.)
        icon.convert('RGB').save(args.icon, compress_level=9)


if __name__ == '__main__':
    main()
