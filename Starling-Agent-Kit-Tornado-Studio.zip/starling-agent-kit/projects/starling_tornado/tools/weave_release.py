#!/usr/bin/env python3
"""Reproduce this Studio release's reduced index on four exact pinned source files."""
import argparse
import os
from pathlib import Path
import re
import subprocess
import sys

PROJECT = Path(__file__).resolve().parents[1]
ROOT = PROJECT.parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from weave_examples import TARGET_FILES, checked_read, put  # noqa: E402

FILES = {**TARGET_FILES, 'crates/horizon-client-render/src/gfx.rs':
         'f998707755e4f51fa84d5a6168d3966a17ba512ac3537d0b0f5dc420b43e2734'}
COMPANION = ROOT / 'examples/releases/Pocket-Wrench-0.1.1-starling-0.8.0.hnmod'
STUDIO = PROJECT / 'releases/Starling-Tornado-Studio-2.0.0-starling-0.8.0.hnmod'


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--starling-source', type=Path, required=True)
    p.add_argument('--weaver', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    args = p.parse_args()
    source, weaver, out = (a.resolve() for a in (args.starling_source, args.weaver, args.out))
    if out.exists() or out.is_relative_to(source):
        p.error('choose a new output folder outside the source')
    files = {name: checked_read(source / name, sha) for name, sha in FILES.items()}
    out.mkdir(parents=True)
    subprocess.run([sys.executable, str(ROOT / 'tools/kit.py'), 'stage', '--starling-source', str(source),
                    '--out', str(out / 'stage'), str(COMPANION), str(STUDIO)], check=True)
    compiled = out / 'stage/job/mods'
    android = source / 'packaging/android'
    subprocess.run([sys.executable, str(android / 'native_mod_permissions.py'),
                    *map(str, sorted(compiled.iterdir()))], check=True)
    subprocess.run([sys.executable, str(android / 'native_mod_adapt.py'), str(source), str(compiled)], check=True)
    index = out / 'targets'
    put(index / '.horizon-revision', 'ac874422ed8f892505ff73d67ae486ecfee7a516\n')
    put(index / 'Cargo.toml', '[workspace]\nresolver = "2"\nmembers = '
        '["crates/horizon-client", "crates/horizon-client-render"]\n')
    for name, modules in [('horizon-client', ['game']), ('horizon-client-render', ['gfx', 'particles'])]:
        cr = index / f'crates/{name}'
        put(cr / 'Cargo.toml', f'[package]\nname = "{name}"\nversion = "0.1.0"\nedition = "2024"\n')
        put(cr / 'src/lib.rs', ''.join(f'pub mod {module};\n' for module in modules))
    pattern = r'^(?:pub(?:\([^)]*\))? )?mod ([A-Za-z_][A-Za-z0-9_]*);'
    for rel, bytes_ in files.items():
        for sibling in re.findall(pattern, bytes_.decode('utf-8'), re.M):
            put(index / Path(rel).with_suffix('') / f'{sibling}.rs', b'')
    for rel, bytes_ in files.items():
        put(index / rel, bytes_)
    subprocess.run(['cargo', 'generate-lockfile', '--offline', '--manifest-path', str(index / 'Cargo.toml')],
                   check=True, env=dict(os.environ, CARGO_NET_OFFLINE='true'))
    common = ['--workspace', str(index), '--mods', str(compiled)]
    subprocess.run([str(weaver), 'plan', *common, '--out', str(out / 'plan.json')], check=True)
    subprocess.run([str(weaver), 'apply', *common, '--out', str(out / 'woven')], check=True)
    put(out / 'targets.txt', '\n'.join(FILES) + '\n')
    print('To check the build, copy ONLY targets.txt paths from woven/ into a complete pinned Starling tree.')


if __name__ == '__main__':
    main()
