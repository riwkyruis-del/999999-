fn tornado_page(game: &crate::game::Game<'_>, mod_id: &str, buttons: &mut Vec<String>) {
    use crate::game::starling_tornado as studio;
    if mod_id == studio::ID {
        studio::settings(game, buttons);
    }
}
