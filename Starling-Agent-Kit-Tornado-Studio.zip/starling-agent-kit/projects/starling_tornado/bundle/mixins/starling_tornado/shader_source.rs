// Mod-only alpha cutoff and optional filtering. Keep the pinned entity pipeline for
// fog, lighting and batching. Overlay 15 normally has no use for the foil UV attribute.
pub(super) fn patch(source: String) -> String {
    const ORIGINAL_SAMPLE: &str =
        "    let texel = textureSample(atlas, atlas_sampler, uv);\n    var tint";
    const ORIGINAL_CUTOFF: &str = "    if color.a < 0.1 || (in.cull != 0u && !front) { discard; }";
    const STUDIO_SAMPLE: &str = r#"    let tornado_soft = in.overlay == 15u && in.glint_uv.x < -0.5 && in.glint_uv.y < -0.5;
    var texel = textureSample(atlas, atlas_sampler, uv);
    if tornado_soft && in.glint_uv.x < -1.5 {
        // Ultra, Studio tiles only. Bilinear within the quad's inset, on the otherwise nearest atlas.
        let texel_xy = uv * vec2<f32>(textureDimensions(atlas)) - vec2(0.5);
        let corner = vec2<i32>(floor(texel_xy));
        let f = fract(texel_xy);
        let top = mix(textureLoad(atlas, corner, 0), textureLoad(atlas, corner + vec2(1, 0), 0), f.x);
        let bottom = mix(textureLoad(atlas, corner + vec2(0, 1), 0), textureLoad(atlas, corner + vec2(1, 1), 0), f.x);
        texel = mix(top, bottom, f.y);
    }
    var tint"#;
    if source.matches(ORIGINAL_SAMPLE).count() != 1 || source.matches(ORIGINAL_CUTOFF).count() != 1
    {
        // If another renderer mod already rewrote these exact points, preserve its shader.
        return source;
    }
    source.replacen(ORIGINAL_SAMPLE, STUDIO_SAMPLE, 1).replacen(
        ORIGINAL_CUTOFF,
        "    if color.a < select(0.1, 0.006, tornado_soft) || (in.cull != 0u && !front) { discard; }",
        1,
    )
}
