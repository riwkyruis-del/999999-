// Bounded camera-facing fog cards. The game owns the atlas, lightmap and depth.
use super::starling_tornado_model::{MAX_DRAW_DISTANCE, MAX_PUFFS, Puff, Storm, hash, smooth};
use super::{ParticleEngine, ParticleLightCache, ParticleType};
use crate::{gfx::TRANSLUCENT_PARTICLE_OVERLAY, hud::Rect, mesher::Vertex};
use glam::{DVec3, Quat, Vec3};

impl ParticleEngine {
    pub fn starling_tornado(&self) -> Option<&Storm> {
        self.__horizon_mixins_starling_tornado_storm()
            .storm
            .as_ref()
    }
    pub fn starling_tornado_mut(&mut self) -> Option<&mut Storm> {
        self.__horizon_mixins_starling_tornado_storm_mut()
            .storm
            .as_mut()
    }
    pub fn starling_tornado_seed(&mut self, salt: u32) -> u32 {
        let state = self.__horizon_mixins_starling_tornado_storm_mut();
        state.serial = state.serial.wrapping_add(1);
        hash(salt ^ state.serial.wrapping_mul(0x9e37_79b9))
    }
    pub fn starling_tornado_start(&mut self, storm: Storm) {
        self.__horizon_mixins_starling_tornado_storm_mut().storm = Some(storm);
    }
    pub fn starling_tornado_stop(&mut self) -> bool {
        self.__horizon_mixins_starling_tornado_storm_mut()
            .storm
            .take()
            .is_some()
    }
    pub fn starling_tornado_texture_mode(&self) -> Option<bool> {
        art(self).map(|plan| plan.studio)
    }
    pub(super) fn starling_tornado_advance(&mut self) {
        let slot = &mut self.__horizon_mixins_starling_tornado_storm_mut().storm;
        if let Some(storm) = slot
            && !storm.advance()
        {
            *slot = None;
        }
    }
}

// A pack can add namespaced atlas sprites without adding registered content or replacing smoke.
// Match the keys constructed by hud.rs's get-name path (`ns:textures` → `ns:particle/name`).
const ART: [[&str; 4]; 3] = [
    [
        "starling_tornado:particle/cloud_0",
        "starling_tornado:particle/cloud_1",
        "starling_tornado:particle/cloud_2",
        "starling_tornado:particle/cloud_3",
    ],
    [
        "starling_tornado:particle/mist_0",
        "starling_tornado:particle/mist_1",
        "starling_tornado:particle/mist_2",
        "starling_tornado:particle/mist_3",
    ],
    [
        "starling_tornado:particle/dust_0",
        "starling_tornado:particle/dust_1",
        "starling_tornado:particle/dust_2",
        "starling_tornado:particle/dust_3",
    ],
];

struct Art {
    sprites: [[Rect; 4]; 3],
    studio: bool,
}

fn stock(engine: &ParticleEngine, kind: ParticleType) -> Option<[Rect; 4]> {
    let set = engine.set_sprites.get(engine.set_of(kind)? as usize)?;
    let mut rects = set
        .iter()
        .filter_map(|&index| engine.rects.get(index as usize).copied().flatten());
    let first = rects.next()?;
    Some([
        first,
        rects.next().unwrap_or(first),
        rects.next().unwrap_or(first),
        rects.next().unwrap_or(first),
    ])
}

fn studio_art(engine: &ParticleEngine) -> Option<Art> {
    let lookup = |name| engine.atlas.get(name).map(|&(rect, _)| rect);
    let mut sprites = [[lookup(ART[0][0])?; 4]; 3];
    for (group, keys) in sprites.iter_mut().zip(ART) {
        for (slot, name) in group.iter_mut().zip(keys) {
            *slot = lookup(name)?;
        }
    }
    Some(Art {
        sprites,
        studio: true,
    })
}

fn art(engine: &ParticleEngine) -> Option<Art> {
    studio_art(engine).or_else(|| {
        let cloud = stock(engine, ParticleType::Cloud)
            .or_else(|| stock(engine, ParticleType::CampfireCosySmoke))
            .or_else(|| stock(engine, ParticleType::WhiteSmoke))
            .or_else(|| stock(engine, ParticleType::Smoke))?;
        let mist = stock(engine, ParticleType::WhiteSmoke).unwrap_or(cloud);
        Some(Art {
            sprites: [cloud, mist, mist],
            studio: false,
        })
    })
}

#[derive(Clone, Copy)]
struct Card {
    puff: Puff,
    relative: Vec3,
    depth: f32,
}

pub(super) fn render(
    engine: &ParticleEngine,
    camera: DVec3,
    yaw: f32,
    pitch: f32,
    partial: f32,
    light_at: &dyn Fn([i32; 3]) -> u8,
    out: &mut Vec<Vertex>,
) {
    let Some(storm) = engine.starling_tornado() else {
        return;
    };
    let base = DVec3::from_array(storm.base());
    let distance = camera.distance_squared(base + DVec3::Y * (0.42 * storm.height()));
    if !distance.is_finite()
        || !yaw.is_finite()
        || !pitch.is_finite()
        || distance >= MAX_DRAW_DISTANCE.powi(2)
    {
        return;
    }
    // Atlas UVs change on pack reload. Resolve current names rather than keeping stale regions.
    let Some(art) = art(engine) else { return };
    let distance = distance.sqrt();
    let range_alpha = (1.0 - smooth(79.0, MAX_DRAW_DISTANCE, distance)) as f32;
    let lod = 1.0 - 0.51 * smooth(46.0, 100.0, distance);
    let facing = Quat::from_rotation_y(std::f32::consts::PI - yaw.to_radians())
        * Quat::from_rotation_x(-pitch.to_radians());
    let forward = facing * -Vec3::Z;
    let frame = storm.frame(partial, engine.particle_level, lod);
    let mut cards = [None; MAX_PUFFS];
    let mut count = 0;
    for mut puff in frame.puffs() {
        let relative = (DVec3::from_array(puff.at) - camera).as_vec3();
        let depth = relative.dot(forward);
        if depth <= 0.20 {
            continue;
        }
        // A close giant sprite would fill the whole screen. Soft near fade limits overdraw.
        let scale = puff.half_width.max(puff.half_height).max(0.20);
        let near = smooth(0.78, 3.1, f64::from(depth / scale));
        puff.color[3] *= range_alpha * near as f32;
        if puff.color[3] < 0.008 {
            continue;
        }
        cards[count] = Some(Card {
            puff,
            relative,
            depth,
        });
        count += 1;
    }
    let cards = &mut cards[..count];
    // All quads face the same view plane: sort by that plane's depth rather than radial distance.
    cards.sort_unstable_by(|a, b| {
        b.as_ref()
            .unwrap()
            .depth
            .total_cmp(&a.as_ref().unwrap().depth)
    });
    let mut light_cache = ParticleLightCache::default();
    let shader_tag = if art.studio && storm.ultra() && engine.particle_level == 0 && distance < 59.0
    {
        [-2.0, -1.0] // optional local four-tap filtering only on near, Ultra Studio tiles
    } else {
        [-1.0, -1.0] // soft cutoff, atlas's normal sampler
    };
    out.reserve(count * 4);
    for card in cards.iter().flatten() {
        let p = card.puff;
        let packed = light_cache.get(p.at.map(|x| x.floor() as i32), light_at);
        let light = (u32::from(packed >> 4) * 16) | (u32::from(packed & 15) * 16) << 8;
        let color = u32::from_le_bytes(p.color.map(|v| (v.clamp(0.0, 1.0) * 255.0).round() as u8));
        let rot = facing * Quat::from_rotation_z(p.roll);
        let right = rot * Vec3::X * p.half_width;
        let up = rot * Vec3::Y * p.half_height;
        let Rect { u0, v0, u1, v1, .. } = art.sprites[p.sprite as usize][p.tile];
        let (du, dv) = ((u1 - u0) * 0.013, (v1 - v0) * 0.013);
        for (offset, uv) in [
            (right - up, [u1 - du, v1 - dv]),
            (right + up, [u1 - du, v0 + dv]),
            (-right + up, [u0 + du, v0 + dv]),
            (-right - up, [u0 + du, v1 - dv]),
        ] {
            out.push(Vertex {
                pos: (card.relative + offset).to_array(),
                uv,
                layer: TRANSLUCENT_PARTICLE_OVERLAY,
                color,
                light,
                normal: [0; 4],
                glint_uv: shader_tag,
            });
        }
    }
}
