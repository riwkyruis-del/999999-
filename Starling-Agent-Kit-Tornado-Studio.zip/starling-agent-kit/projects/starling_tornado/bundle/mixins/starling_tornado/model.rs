// Tornado Studio: bounded, deterministic visual simulation. No engine or I/O dependencies.
use std::f64::consts::TAU;

pub const ID: &str = "starling_tornado";
pub const VERSION: &str = "2.0.0";
pub const COMMAND: &str = "tornado";
pub const MAX_PUFFS: usize = 256;
pub const MAX_DRAW_DISTANCE: f64 = 102.0;
const TPS: u32 = 20;

// Kept by ParticleEngine, not a global: resets the funnel without reusing a preview seed.
#[derive(Default)]
pub struct StudioState {
    pub(crate) storm: Option<Storm>,
    pub(crate) serial: u32,
}

pub fn parse(line: &str) -> Option<Result<(), &'static str>> {
    let mut words = line.split_ascii_whitespace();
    if words.next()? != COMMAND {
        return None;
    }
    Some(if words.next().is_none() {
        Ok(())
    } else {
        Err(
            "Use /tornado to start or stop. Change the look in Options > Mods > Tornado Studio > Settings.",
        )
    })
}

#[derive(Clone, Copy, Debug)]
#[repr(usize)]
pub enum Control {
    Shape,
    Intensity,
    Scale,
    Palette,
    Dust,
    Wind,
    Duration,
    Detail,
}

pub const CONTROLS: [Control; 8] = [
    Control::Shape,
    Control::Intensity,
    Control::Scale,
    Control::Palette,
    Control::Dust,
    Control::Wind,
    Control::Duration,
    Control::Detail,
];

impl Control {
    fn name(self) -> &'static str {
        match self {
            Self::Shape => "Shape",
            Self::Intensity => "Intensity",
            Self::Scale => "Scale",
            Self::Palette => "Palette",
            Self::Dust => "Ground dust",
            Self::Wind => "Wind lean",
            Self::Duration => "Duration (next spawn)",
            Self::Detail => "Detail",
        }
    }
    fn choices(self) -> &'static [&'static str] {
        match self {
            Self::Shape => &["Rope", "Cone", "Wedge", "Twin vortex", "Shuffle"],
            Self::Intensity => &["EF0", "EF1", "EF2", "EF3", "EF4", "EF5", "Random"],
            Self::Scale => &["75%", "100%", "125%", "145%"],
            Self::Palette => &["Storm blue", "Pale mist", "Dry earth", "Sunset"],
            Self::Dust => &["Off", "Light", "Heavy"],
            Self::Wind => &["Calm", "Breeze", "Strong"],
            Self::Duration => &["15 s", "30 s", "45 s", "60 s", "90 s", "120 s"],
            Self::Detail => &["Lite", "Balanced", "Ultra"],
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Preferences([u8; CONTROLS.len()]);

impl Default for Preferences {
    fn default() -> Self {
        // Cone, EF2, 100%, Storm blue, Light dust, Breeze, 45 s, Balanced.
        Self([1, 2, 1, 0, 1, 1, 2, 1])
    }
}

impl Preferences {
    pub fn decode(text: &str) -> Option<Self> {
        let mut parts = text.split_ascii_whitespace();
        if parts.next()? != "studio-1" {
            return None;
        }
        let mut prefs = Self::default();
        for control in CONTROLS {
            let n = parts.next()?.parse::<u8>().ok()?;
            if usize::from(n) >= control.choices().len() {
                return None;
            }
            prefs.0[control as usize] = n;
        }
        parts.next().is_none().then_some(prefs)
    }
    pub fn encode(self) -> String {
        let [a, b, c, d, e, f, g, h] = self.0;
        format!("studio-1 {a} {b} {c} {d} {e} {f} {g} {h}")
    }
    fn get(self, control: Control) -> usize {
        usize::from(self.0[control as usize])
    }
    pub fn label(self, control: Control) -> String {
        format!(
            "{}: {}",
            control.name(),
            control.choices()[self.get(control)]
        )
    }
    pub fn cycle(&mut self, control: Control) {
        let i = control as usize;
        self.0[i] = (self.0[i] + 1) % control.choices().len() as u8;
    }
    pub fn seconds(self) -> u32 {
        [15, 30, 45, 60, 90, 120][self.get(Control::Duration)]
    }
    pub fn shape(self, seed: u32) -> usize {
        match self.get(Control::Shape) {
            4 => (hash(seed ^ 0x947a_2e35) % 4) as usize,
            n => n,
        }
    }
    pub fn intensity(self, seed: u32) -> usize {
        match self.get(Control::Intensity) {
            6 => (hash(seed ^ 0x90a1_63d7) % 6) as usize,
            n => n,
        }
    }
    pub fn shape_name(self, seed: u32) -> &'static str {
        Control::Shape.choices()[self.shape(seed)]
    }
    pub fn focus_distance(self, seed: u32) -> f64 {
        (Look::new(self, seed).profile().height * 1.77).clamp(17.0, 45.0)
    }
}

pub fn hash(mut x: u32) -> u32 {
    x ^= x >> 16;
    x = x.wrapping_mul(0x7feb_352d);
    x ^= x >> 15;
    x = x.wrapping_mul(0x846c_a68b);
    x ^ (x >> 16)
}

fn noise(x: u32) -> f64 {
    f64::from(hash(x)) / 4_294_967_296.0
}

fn lerp(a: f64, b: f64, t: f64) -> f64 {
    a + (b - a) * t
}

pub fn smooth(a: f64, b: f64, v: f64) -> f64 {
    let t = ((v - a) / (b - a)).clamp(0.0, 1.0);
    t * t * (3.0 - 2.0 * t)
}

// [height multiplier, crown multiplier, relative foot radius, taper, sinuosity, split].
const SHAPES: [[f64; 6]; 4] = [
    [1.11, 0.45, 0.26, 1.52, 0.38, 0.0], // thin, wandering rope
    [1.00, 1.00, 0.18, 1.16, 0.15, 0.0], // classical taper
    [0.81, 1.40, 0.65, 0.77, 0.09, 0.0], // near-ground width
    [0.98, 0.66, 0.23, 1.23, 0.20, 1.0], // two winding columns, joining above
];
// Reference sizes in blocks and rotation in turns/s. EF is a visual preset, not physical wind speed.
const INTENSITIES: [[f64; 3]; 6] = [
    [9.5, 1.65, 0.23],
    [13.0, 2.25, 0.27],
    [17.5, 3.15, 0.33],
    [22.0, 4.05, 0.39],
    [27.0, 5.05, 0.46],
    [33.0, 6.25, 0.54],
];
// Condensation and airborne dust tint. Neutral source textures preserve all four choices.
const PALETTES: [([f64; 3], [f64; 3]); 4] = [
    ([0.74, 0.84, 0.94], [0.80, 0.72, 0.62]),
    ([0.98, 0.99, 1.00], [0.92, 0.88, 0.81]),
    ([0.94, 0.81, 0.67], [0.91, 0.72, 0.49]),
    ([1.00, 0.72, 0.59], [0.91, 0.63, 0.48]),
];

#[derive(Clone, Copy, Debug)]
struct Look {
    level: f64,
    scale: f64,
    form: [f64; 6],
    mist: [f64; 3],
    dust: [f64; 3],
    grit: f64,
    lean: f64,
    budget: f64,
}

impl Look {
    fn new(prefs: Preferences, seed: u32) -> Self {
        let (mist, dust) = PALETTES[prefs.get(Control::Palette)];
        Self {
            level: prefs.intensity(seed) as f64,
            scale: [0.75, 1.0, 1.25, 1.45][prefs.get(Control::Scale)],
            form: SHAPES[prefs.shape(seed)],
            mist,
            dust,
            grit: [0.0, 0.64, 1.0][prefs.get(Control::Dust)],
            lean: [0.0, 0.24, 0.53][prefs.get(Control::Wind)],
            budget: [84.0, 168.0, 248.0][prefs.get(Control::Detail)],
        }
    }
    fn blend(self, b: Self, t: f64) -> Self {
        Self {
            level: lerp(self.level, b.level, t),
            scale: lerp(self.scale, b.scale, t),
            form: std::array::from_fn(|i| lerp(self.form[i], b.form[i], t)),
            mist: std::array::from_fn(|i| lerp(self.mist[i], b.mist[i], t)),
            dust: std::array::from_fn(|i| lerp(self.dust[i], b.dust[i], t)),
            grit: lerp(self.grit, b.grit, t),
            lean: lerp(self.lean, b.lean, t),
            budget: lerp(self.budget, b.budget, t),
        }
    }
    fn profile(self) -> Profile {
        let n = self.level.clamp(0.0, 5.0);
        let i = n as usize;
        let v = |k| lerp(INTENSITIES[i][k], INTENSITIES[(i + 1).min(5)][k], n.fract());
        Profile {
            height: v(0) * self.form[0] * self.scale,
            crown: v(1) * self.form[1] * self.scale,
            reference_width: v(1) * self.scale,
            spin: v(2),
        }
    }
}

#[derive(Clone, Copy, Debug)]
struct Profile {
    height: f64,
    crown: f64,
    reference_width: f64,
    spin: f64,
}

#[derive(Clone, Debug)]
pub struct Storm {
    base: [f64; 3],
    seed: u32,
    selected: Preferences,
    look: Look,
    previous: Look,
    target: Look,
    age: u32,
    duration: u32,
    phase: f64,
    angular_step: f64,
    ascent: f64,
    ascent_step: f64,
    direction: f64,
}

impl Storm {
    pub fn new(base: [f64; 3], prefs: Preferences, seed: u32) -> Option<Self> {
        if !base
            .iter()
            .all(|v| v.is_finite() && v.abs() <= 30_000_000.0)
        {
            return None;
        }
        let look = Look::new(prefs, seed);
        Some(Self {
            base,
            seed,
            selected: prefs,
            look,
            previous: look,
            target: look,
            age: 0,
            duration: prefs.seconds() * TPS,
            phase: noise(seed ^ 0x4870_e309) * TAU,
            angular_step: 0.0,
            ascent: 0.0,
            ascent_step: 0.0,
            direction: if seed & 1 == 0 { 1.0 } else { -1.0 },
        })
    }
    pub fn base(&self) -> [f64; 3] {
        self.base
    }
    pub fn height(&self) -> f64 {
        self.look.profile().height
    }
    pub fn intensity(&self) -> usize {
        self.selected.intensity(self.seed)
    }
    pub fn shape_name(&self) -> &'static str {
        self.selected.shape_name(self.seed)
    }
    pub fn seconds_left(&self) -> u32 {
        self.duration.saturating_sub(self.age).div_ceil(TPS)
    }
    pub fn tune(&mut self, prefs: Preferences) {
        self.selected = prefs;
        self.target = Look::new(prefs, self.seed);
        // Placement, seed and expiry never reset on a setting change.
    }
    pub fn advance(&mut self) -> bool {
        self.age = self.age.saturating_add(1);
        if self.age >= self.duration {
            return false;
        }
        self.previous = self.look;
        self.look = self.look.blend(self.target, 0.20);
        self.angular_step = self.direction * self.look.profile().spin * TAU / f64::from(TPS);
        self.phase += self.angular_step;
        self.ascent_step = 0.0052 + self.look.level * 0.00064;
        self.ascent += self.ascent_step;
        true
    }
    pub fn frame(&self, partial: f32, particles: u8, lod: f64) -> Frame {
        let f = if partial.is_finite() {
            f64::from(partial.clamp(0.0, 1.0))
        } else {
            0.0
        };
        let lod = if lod.is_finite() {
            lod.clamp(0.0, 1.0)
        } else {
            0.0
        };
        let time = if self.age == 0 {
            0.0
        } else {
            f64::from(self.age - 1) + f
        };
        let look = self.previous.blend(self.look, f);
        let quality = match particles {
            0 => 1.0,
            1 => 0.67,
            _ => 0.40,
        };
        let budget = look.budget * quality * (0.80 + 0.04 * look.level) * lod;
        Frame {
            look,
            profile: look.profile(),
            budgets: [0.34, 0.45, 0.11, 0.10 * look.grit].map(|w| w * budget),
            growth: 0.67 + 0.33 * smooth(0.0, 35.0, time),
            opacity: smooth(0.0, 20.0, time + 4.0)
                * smooth(0.0, 28.0, f64::from(self.duration) - time),
            base: self.base,
            phase: self.phase - (1.0 - f) * self.angular_step,
            ascent: self.ascent - (1.0 - f) * self.ascent_step,
            time,
            seed: self.seed,
        }
    }
    pub fn ultra(&self) -> bool {
        self.selected.get(Control::Detail) == 2
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Sprite {
    Cloud = 0,
    Mist = 1,
    Dust = 2,
}

#[derive(Clone, Copy, Debug)]
pub struct Puff {
    pub at: [f64; 3],
    pub half_width: f32,
    pub half_height: f32,
    pub roll: f32,
    pub color: [f32; 4],
    pub sprite: Sprite,
    pub tile: usize,
}

#[derive(Clone, Copy, Debug)]
pub struct Frame {
    look: Look,
    profile: Profile,
    budgets: [f64; 4],
    growth: f64,
    opacity: f64,
    base: [f64; 3],
    phase: f64,
    ascent: f64,
    time: f64,
    seed: u32,
}

impl Frame {
    pub fn puffs(&self) -> impl Iterator<Item = Puff> + '_ {
        self.budgets
            .iter()
            .enumerate()
            .flat_map(move |(group, &n)| {
                (0..n.ceil() as u32)
                    .map(move |i| self.puff(group, i, (n - f64::from(i)).clamp(0.0, 1.0)))
            })
            .take(MAX_PUFFS)
    }

    fn puff(&self, group: usize, i: u32, weight: f64) -> Puff {
        let key = self.seed ^ (i + 1 + group as u32 * 307).wrapping_mul(0x9e37_79b9);
        let u = noise(key);
        let v = noise(key ^ 0x2c97_e4b1);
        let w = noise(key ^ 0x85eb_ca6b);
        let [bx, by, bz] = self.base;
        let grow = self.growth;
        let a = self.look;
        let p = self.profile;
        let turn =
            (f64::from(i) * 0.618_033_988_749_894_8 + u * 0.14 + f64::from(group as u32) * 0.32)
                .fract();
        let (at, rx, ry, roll, tint, shade, alpha, sprite) = if group == 3 {
            // Finite dust skirt, with streaks that rise and thin rather than emit entities.
            let trail = (turn + self.ascent * (2.3 + 0.6 * w)).rem_euclid(1.0);
            let theta = self.phase * 1.44 + turn * TAU + trail * 0.92;
            let (s, c) = theta.sin_cos();
            let spread = p.reference_width * grow * (0.46 + 0.79 * u + 0.44 * a.form[5]);
            let lift = a.scale * (0.23 + trail * (0.9 + 0.25 * a.level) + 0.2 * v);
            let fade = smooth(0.0, 0.10, trail) * (1.0 - smooth(0.70, 1.0, trail));
            (
                [bx + c * spread, by + lift, bz + s * spread],
                0.53 * a.scale + 0.32 * spread + 0.45 * v,
                a.scale * (0.29 + 0.51 * trail + 0.18 * u),
                0.31 * (s + 0.55 * (w - 0.5)),
                a.dust,
                0.80 + 0.25 * v,
                fade * (0.43 + 0.29 * u) * (0.45 + 0.55 * a.grit),
                Sprite::Dust,
            )
        } else {
            let core = group == 0;
            let veil = group == 2;
            let scroll = (turn + self.ascent * (1.0 + 0.26 * v)).rem_euclid(1.0);
            let h = if veil { 0.28 + 0.72 * scroll } else { scroll };
            let theta = self.phase * (0.79 + 0.21 * group as f64)
                + (h * (1.84 + 0.35 * v) + f64::from(i % 5) / 5.0) * TAU
                + (u - 0.5) * 1.23;
            let (s, c) = theta.sin_cos();
            let radius = p.crown * grow * lerp(a.form[2], 1.0, h.powf(a.form[3]));
            let orbit_radius = radius
                * if core {
                    0.17 + 0.39 * u
                } else if veil {
                    0.91 + 0.44 * u
                } else {
                    0.65 + 0.31 * u
                };
            let gust = (self.time * 0.031 + noise(self.seed ^ 0x8361_5acb) * TAU).sin();
            let lean = (a.lean * (0.74 + 0.26 * gust)) * p.reference_width * h * h;
            let heading = noise(self.seed ^ 0x1538_b5cb) * TAU + self.time * 0.007;
            let (lz, lx) = heading.sin_cos();
            let snake = a.form[4] * p.reference_width * h * (self.time * 0.028 + h * 8.5).sin();
            let (tz, tx) =
                (self.phase * 0.39 + h * 2.2 + if i % 2 == 0 { 0.0 } else { TAU / 2.0 }).sin_cos();
            let split = a.form[5] * p.reference_width * grow * (0.56 - 0.28 * h);
            let taper_fade = smooth(0.0, 0.085, scroll) * (1.0 - smooth(0.87, 1.0, scroll));
            let rgb = if veil {
                a.mist.map(|x| lerp(x, 1.0, 0.23))
            } else {
                a.mist
            };
            let shade = 0.79 + 0.15 * w + 0.19 * h + 0.10 * (c * 0.65 + s * 0.35) - 0.019 * a.level;
            let rx = if core {
                0.36 + 0.67 * radius
            } else if veil {
                0.68 + 0.72 * radius
            } else {
                0.39 + 0.50 * radius
            };
            let ry = p.height
                * if core {
                    0.060 + 0.026 * v
                } else if veil {
                    0.043 + 0.023 * v
                } else {
                    0.050 + 0.024 * v
                };
            (
                [
                    bx + c * orbit_radius + lx * lean + lz * snake + tx * split,
                    by + 0.26 + h * p.height * grow,
                    bz + s * orbit_radius + lz * lean - lx * snake + tz * split,
                ],
                rx * (0.77 + 0.38 * v),
                (ry + 0.16 * a.scale) * grow,
                (if veil { 0.62 } else { 0.38 }) * s + 0.38 * (u - 0.5),
                rgb,
                shade,
                taper_fade
                    * if core {
                        0.61 + 0.18 * v
                    } else if veil {
                        0.29 + 0.20 * u
                    } else {
                        0.48 + 0.20 * w
                    },
                if veil { Sprite::Mist } else { Sprite::Cloud },
            )
        };
        Puff {
            at,
            half_width: rx as f32,
            half_height: ry as f32,
            roll: roll as f32,
            color: [
                (tint[0] * shade).clamp(0.0, 1.0) as f32,
                (tint[1] * shade).clamp(0.0, 1.0) as f32,
                (tint[2] * shade).clamp(0.0, 1.0) as f32,
                (alpha * self.opacity * weight).clamp(0.0, 1.0) as f32,
            ],
            sprite,
            tile: (hash(key ^ 0x6afd_2edf) & 3) as usize,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn only_one_command_and_no_external_match() {
        assert_eq!(parse("tornado"), Some(Ok(())));
        assert_eq!(parse("  tornado  "), Some(Ok(())));
        for text in [
            "tornado help",
            "tornado stop",
            "tornado EF3",
            "tornado spawn 5 20",
        ] {
            assert!(parse(text).is_some_and(|r| r.is_err()));
        }
        for text in [
            "",
            "weather clear",
            "tornadoes",
            "server:tornado",
            "say tornado",
        ] {
            assert_eq!(parse(text), None);
        }
    }

    #[test]
    fn every_setting_cycles_and_round_trips() {
        let begin = Preferences::default();
        let mut p = begin;
        for c in CONTROLS {
            for _ in c.choices() {
                p.cycle(c);
                assert_eq!(Some(p), Preferences::decode(&p.encode()));
            }
        }
        assert_eq!(p, begin);
        assert_eq!(p.seconds(), 45);
        for invalid in [
            "",
            "studio-1 5 2 1 0 1 1 2 1",
            "studio-1 1 2 1 0 1 1 2",
            "studio-1 1 2 1 0 1 1 2 1 extra",
            "studio-2 1 2 1 0 1 1 2 1",
        ] {
            assert_eq!(Preferences::decode(invalid), None);
        }
    }

    #[test]
    fn shuffle_varies_between_seeds_and_is_stable_for_a_storm() {
        let p = Preferences([4, 6, 1, 0, 1, 1, 2, 1]);
        let mut shapes = [false; 4];
        let mut levels = [false; 6];
        for seed in 1..180 {
            shapes[p.shape(seed)] = true;
            levels[p.intensity(seed)] = true;
            let mut storm = Storm::new([0.0; 3], p, seed).unwrap();
            let name = storm.shape_name();
            for _ in 0..8 {
                storm.advance();
            }
            storm.tune(p);
            assert_eq!(storm.shape_name(), name);
            assert_eq!(storm.intensity(), p.intensity(seed));
        }
        assert!(shapes.into_iter().all(|x| x) && levels.into_iter().all(|x| x));
    }

    #[test]
    fn distinct_silhouettes_and_ef_sizes() {
        let get = |shape, intensity| {
            Look::new(Preferences([shape, intensity, 1, 0, 1, 1, 2, 1]), 1).profile()
        };
        assert!(get(0, 3).height > get(1, 3).height);
        assert!(get(0, 3).crown < get(1, 3).crown);
        assert!(get(2, 3).crown > get(1, 3).crown);
        for n in 1..=5 {
            assert!(get(1, n).height > get(1, n - 1).height);
            assert!(get(1, n).crown > get(1, n - 1).crown);
            assert!(get(1, n).spin > get(1, n - 1).spin);
        }
    }

    #[test]
    fn retune_eases_without_moving_reseeding_or_resetting_expiry() {
        let p = Preferences::default();
        let q = Preferences([2, 5, 3, 3, 2, 2, 5, 2]);
        let base = [14.5, 73.0, -17.5];
        let mut storm = Storm::new(base, p, 777).unwrap();
        for _ in 0..50 {
            storm.advance();
        }
        let before = storm.height();
        let expires = storm.seconds_left();
        storm.tune(q);
        assert_eq!(storm.height(), before);
        assert_eq!(storm.seconds_left(), expires);
        storm.advance();
        assert!(storm.height() > before && storm.height() < Look::new(q, 777).profile().height);
        for _ in 0..40 {
            storm.advance();
        }
        assert!((storm.height() - Look::new(q, 777).profile().height).abs() < 0.01);
        assert_eq!(storm.base(), base);
        assert_eq!(storm.duration, p.seconds() * TPS);
        assert_eq!(storm.seed, 777);
    }

    #[test]
    fn expires_exactly_and_rejects_nonfinite_placement() {
        assert!(Storm::new([0.0, f64::INFINITY, 0.0], Preferences::default(), 0).is_none());
        assert!(Storm::new([30_000_010.0, 0.0, 0.0], Preferences::default(), 0).is_none());
        let mut s = Storm::new([0.0; 3], Preferences([1, 2, 1, 0, 1, 1, 0, 1]), 0).unwrap();
        for _ in 1..15 * TPS {
            assert!(s.advance());
        }
        assert!(s.frame(1.0, 0, 1.0).opacity < 0.01);
        assert!(!s.advance());
        assert_eq!(s.seconds_left(), 0);
    }

    #[test]
    fn render_budget_stays_bounded_at_all_details_and_particle_levels() {
        for form in 0..5 {
            for ef in 0..7 {
                for detail in 0..3 {
                    let prefs = Preferences([form, ef, 3, 3, 2, 2, 5, detail]);
                    let mut s =
                        Storm::new([17.0, -61.0, -900.0], prefs, 0x1234 + u32::from(ef)).unwrap();
                    for _ in 0..80 {
                        s.advance();
                    }
                    let mut limit = MAX_PUFFS + 1;
                    for particles in 0..3 {
                        let puffs: Vec<_> = s.frame(f32::NAN, particles, 1.0).puffs().collect();
                        assert!(
                            (20..limit).contains(&puffs.len()),
                            "{form}, {ef}, {detail}, {particles}: {}",
                            puffs.len()
                        );
                        limit = puffs.len();
                        for puff in puffs {
                            assert!(puff.at.into_iter().all(f64::is_finite));
                            assert!(puff.color.into_iter().all(|v| (0.0..=1.0).contains(&v)));
                            assert!((0.2..=12.0).contains(&puff.half_width));
                            assert!((0.15..=6.0).contains(&puff.half_height));
                            assert!((0.0..=55.0).contains(&(puff.at[1] + 61.0)));
                            assert!((puff.at[0] - 17.0).hypot(puff.at[2] + 900.0) < 28.0);
                            assert!(puff.roll.abs() <= 1.0 && puff.tile < 4);
                        }
                    }
                }
            }
        }
    }

    #[test]
    fn motion_stitches_between_ticks_when_settings_change() {
        let mut s = Storm::new([10.0, 56.0, 9.0], Preferences::default(), 124).unwrap();
        for t in 0..95 {
            s.advance();
            if t == 14 {
                s.tune(Preferences([3, 5, 3, 1, 2, 0, 0, 2]));
            }
            let a: Vec<_> = s.frame(1.0, 0, 1.0).puffs().collect();
            s.advance();
            let b: Vec<_> = s.frame(0.0, 0, 1.0).puffs().collect();
            assert_eq!(a.len(), b.len());
            for (a, b) in a.into_iter().zip(b) {
                assert!(
                    a.at.into_iter()
                        .zip(b.at)
                        .all(|(x, y)| (x - y).abs() < 1e-9)
                );
                assert_eq!(a.sprite, b.sprite);
                assert_eq!(a.tile, b.tile);
            }
        }
    }

    #[test]
    fn dust_off_drops_only_the_skirt_and_lod_saves_quads() {
        let p = Preferences::default();
        let mut s = Storm::new([0.0; 3], p, 1234).unwrap();
        for _ in 0..25 {
            s.advance();
        }
        let dense = s.frame(0.5, 0, 1.0);
        assert!(dense.puffs().any(|x| x.sprite == Sprite::Dust));
        let mut off = p;
        off.cycle(Control::Dust);
        off.cycle(Control::Dust);
        s.tune(off);
        // Settle the control: the dust eases out over several ticks.
        for _ in 0..64 {
            s.advance();
        }
        let settled = s.frame(0.5, 0, 1.0);
        assert!(
            settled
                .puffs()
                .filter(|x| x.sprite == Sprite::Dust)
                .all(|x| x.color[3] < 0.005)
        );
        assert!(s.frame(0.5, 0, 0.55).puffs().count() < settled.puffs().count());
    }
}
