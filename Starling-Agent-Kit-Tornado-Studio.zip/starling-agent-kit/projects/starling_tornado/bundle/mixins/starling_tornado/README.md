# Tornado Studio 2.0.0

Visual-only tornadoes for Starling v0.8.0 / Minecraft Java 26.3 / Android ARM64. Select this version **instead of** Tornado 1.x, not alongside it. Keep the `.hnmod` zipped and build it in **Starling Mod Builder Plus Fix**. Open the resulting **Starling Modded Plus** game.

- **`/tornado`** starts the funnel ahead of you. **`/tornado` again** stops it. This is the only command. The same start/stop control is on the settings page, so typing is optional inside a local world.
- **Options → Mods → Tornado Studio → Settings**: tap a row to cycle it. Choose Rope, Cone, Wedge, Twin vortex or Shuffle; EF0–EF5 or Random; 75–145% scale; Storm blue, Pale mist, Dry earth or Sunset; dust; wind lean; duration; or Lite/Balanced/Ultra detail. The visual controls blend into an active funnel; duration sets the next start. The spawn position stays fixed. Reset restores the defaults.
- **Optional but recommended for the new look:** import the separate **Tornado Studio Textures** ZIP into the **game** (or its `resourcepacks/` folder) and enable it under **Options → Resource Packs**. Do not add it to the builder. It supplies 12 original 224×224 translucent smoke, mist and dust tiles unique to this mod. Without it, the effect uses stock textures. No `.hmod` is required.

Face a flat clearing in a local world for the first test. Use the Balanced default or Lite if frame rate drops; the game's Particles setting also reduces the number of quads. Back up or look upward to frame large funnels. EF is a visual label, not real wind speed. The rendering uses composited billboards with volume-baked textures, not live volumetric/ray-traced weather.

No block edits, entity damage, weather changes, new permissions, network calls, or command interception on external servers. The storm is not saved and is cleared with the client particle engine when leaving or changing worlds. Only settings are saved in the mod's own folder. LAN guests do not see the host's effect.
