// Chat, the native settings page and read-only placement in the player's local world.
use super::Game;
use horizon_client::blocks::Fluid;
use horizon_client::particles::starling_tornado_model::{
    self as model, CONTROLS, Preferences, Storm,
};

pub(super) use model::{COMMAND, ID, VERSION};
const PREFS_KEY: &str = "studio_settings";

pub(super) fn available(game: &Game<'_>) -> bool {
    // The effect is client-local; an external server or LAN host you joined owns its commands.
    game.native_window() && game.has_singleplayer_server()
}

fn preferences(game: &Game<'_>) -> Preferences {
    game.native_setting(ID, PREFS_KEY)
        .as_deref()
        .and_then(Preferences::decode)
        .unwrap_or_default()
}

pub(super) fn command(game: &mut Game<'_>, line: &str) -> bool {
    let Some(result) = model::parse(line) else {
        return false;
    };
    match result {
        Ok(()) => toggle(game),
        Err(text) => game.native_chat(&format!("[Tornado] {text}")),
    }
    true
}

pub(super) fn settings(game: &Game<'_>, out: &mut Vec<String>) {
    let prefs = preferences(game);
    let primary = if !available(game) {
        "Open a local world to preview".to_owned()
    } else if let Some(storm) = game.particles.starling_tornado() {
        format!(
            "Stop {} (EF{}, {} s)",
            storm.shape_name(),
            storm.intensity(),
            storm.seconds_left()
        )
    } else {
        "Start tornado ahead of you".to_owned()
    };
    out.push(primary);
    out.extend(CONTROLS.map(|control| prefs.label(control)));
    out.push("Reset Studio settings".to_owned());
}

pub(super) fn settings_click(game: &mut Game<'_>, button: usize) {
    if !game.native_window() {
        return;
    }
    if button == 0 {
        if available(game) {
            toggle(game);
        }
        return;
    }
    let mut prefs = preferences(game);
    if let Some(&control) = CONTROLS.get(button - 1) {
        prefs.cycle(control);
    } else if button == CONTROLS.len() + 1 {
        prefs = Preferences::default();
    } else {
        return;
    }
    game.native_set_setting(ID, PREFS_KEY, &prefs.encode());
    if let Some(storm) = game.particles.starling_tornado_mut() {
        storm.tune(prefs);
    }
}

fn toggle(game: &mut Game<'_>) {
    let message = if game.particles.starling_tornado_stop() {
        "Stopped the tornado.".to_owned()
    } else {
        spawn(game)
    };
    game.native_chat(&format!("[Tornado] {message}"));
}

fn spawn(game: &mut Game<'_>) -> String {
    let Some(player) = game.native_player() else {
        return "Open your own world first.".into();
    };
    let at = [player.x, player.y, player.z];
    let yaw = player.yaw;
    let prefs = preferences(game);
    let Some(hd) = game.particles.starling_tornado_texture_mode() else {
        return "No particle sprites loaded. Enable Tornado Studio Textures or use the default pack.".into();
    };
    // Separate local counter, even if the menu is paused. Never borrow the world's RNG.
    let salt = (game.ticks as u32).wrapping_mul(0x85eb_ca6b)
        ^ (at[0].floor() as i32 as u32).wrapping_mul(0x9e37_79b9)
        ^ (at[2].floor() as i32 as u32).rotate_left(13);
    let seed = game.particles.starling_tornado_seed(salt);
    let Some(at) = placement(game, at, yaw, prefs.focus_distance(seed)) else {
        return "No clear ground ahead. Face a nearby open area and try again.".into();
    };
    let Some(storm) = Storm::new(at, prefs, seed) else {
        return "The target is outside the supported world bounds.".into();
    };
    let art = if hd {
        "Studio textures."
    } else {
        "Stock texture fallback; enable the Studio texture pack for the new look."
    };
    let result = format!(
        "{} · EF{} · {} s. {art}",
        storm.shape_name(),
        storm.intensity(),
        storm.seconds_left()
    );
    game.particles.starling_tornado_start(storm);
    result
}

fn placement(game: &Game<'_>, player: [f64; 3], yaw: f32, focus: f64) -> Option<[f64; 3]> {
    if !yaw.is_finite()
        || !player
            .into_iter()
            .all(|v| v.is_finite() && v.abs() <= 30_000_000.0)
    {
        return None;
    }
    let world = &game.world;
    let facts = game.res.facts();
    let loaded = |x: i32, z: i32| world.chunks.contains_key(&(x >> 4, z >> 4));
    let open_above = |x: i32, y: i32, z: i32| {
        (1..=4).all(|dy| {
            let b = facts.get(world.block(x, y + dy, z));
            !b.full_collision && !b.legacy_solid && b.fluid == Fluid::None
        })
    };
    let min_y = world.bottom_y();
    let max_y = world.top_y();
    // Aim placement is optional. Require a loaded surface outside the viewer's near range.
    if let Some(hit) = game
        .aim()
        .and_then(|(from, dir)| game.clip_ray(from, dir, 45.0))
    {
        let [x, y, z] = hit.pos;
        let [hx, hy, hz] = hit.point;
        let distance = (hx - player[0]).hypot(hz - player[2]);
        if hit.face == [0, 1, 0]
            && y >= min_y
            && y < max_y
            && (12.0..=45.0).contains(&distance)
            && loaded(x, z)
            && open_above(x, y, z)
        {
            return Some([hx, hy + 0.06, hz]);
        }
    }
    // Default EF2 starts roughly 31 blocks out on an open flat. Shorter fallbacks
    // work with low render distances. Never request a chunk or modify the world.
    let (sin, cos) = f64::from(yaw).to_radians().sin_cos();
    let feet = player[1].floor() as i32;
    let top = (feet + 9).min(max_y - 1);
    let bottom = (feet - 26).max(min_y);
    for distance in [focus, focus * 0.78, (focus * 1.12).min(45.0), 14.0, 11.0] {
        let x = (player[0] - sin * distance).floor() as i32;
        let z = (player[2] + cos * distance).floor() as i32;
        if !loaded(x, z) {
            continue;
        }
        for y in (bottom..=top).rev() {
            let state = world.block(x, y, z);
            let b = facts.get(state);
            if facts.is_air(state)
                || !(b.full_collision || b.legacy_solid || b.fluid != Fluid::None)
            {
                continue;
            }
            if open_above(x, y, z) {
                let height = if b.full_collision || b.fluid != Fluid::None {
                    1.0
                } else {
                    b.outline
                        .iter()
                        .map(|bb| bb[4])
                        .fold(0.0, f64::max)
                        .clamp(0.0, 1.0)
                };
                return Some([
                    f64::from(x) + 0.5,
                    f64::from(y) + height + 0.06,
                    f64::from(z) + 0.5,
                ]);
            }
        }
    }
    None
}
