fn tornado_click(game: &mut crate::game::Game<'_>, mod_id: &str, button: usize) {
    use crate::game::starling_tornado as studio;
    if mod_id == studio::ID {
        studio::settings_click(game, button);
    }
}
