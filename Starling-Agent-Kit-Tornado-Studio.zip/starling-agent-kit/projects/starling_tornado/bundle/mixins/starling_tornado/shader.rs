// Reuse the pinned entity.wgsl from its original module. The weaver preserves
// include_str! only at a boundary HEAD, not an expression/RETURN site.
fn tornado_soft_entity_shader() -> core::ops::ControlFlow<String> {
    let original = crate::overlay::wgsl_constants() + include_str!("entity.wgsl");
    core::ops::ControlFlow::Break(crate::gfx::starling_tornado_shader_source::patch(original))
}
