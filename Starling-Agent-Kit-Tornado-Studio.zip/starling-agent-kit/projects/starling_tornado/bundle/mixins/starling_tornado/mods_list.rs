fn list_tornado(mods: &mut Vec<crate::game::native_hooks::NativeMod>) {
    use crate::game::starling_tornado as studio;
    mods.push(crate::game::native_hooks::NativeMod {
        id: studio::ID.into(),
        title: "Tornado Studio".into(),
        description: format!(
            "Visual-only tornadoes · v{}. Open Settings to shape the funnel, or use /tornado to start/stop in a local world.",
            studio::VERSION
        ),
        keys: Vec::new(),
    });
}
