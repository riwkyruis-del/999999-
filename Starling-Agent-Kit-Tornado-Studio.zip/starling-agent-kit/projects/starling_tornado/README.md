# Tornado Studio 2.0.0

**Starling v0.8.0 · Minecraft Java 26.3 · Android ARM64**

Tornado Studio replaces Tornado 1.x with a single start/stop command and a settings page. It renders a layered, non-destructive vortex with original translucent smoke, mist, and dust. The new textures are baked offline from small 3D volumes. In-game rendering uses depth-sorted quads, the game's fog/lightmap, and soft edges for the tornado only; it isn't live ray tracing or a real weather simulation.

| Download | Where to use it |
|---|---|
| [**Tornado Studio `.hnmod`**](releases/Starling-Tornado-Studio-2.0.0-starling-0.8.0.hnmod) | **Starling Mod Builder Plus Fix**; build and install **Starling Modded Plus**. Select this **instead of** any 1.x Tornado. |
| [**Studio Textures `.zip`**](releases/Starling-Tornado-Studio-Textures-2.0.0-java-26.3.zip) | **Starling Modded Plus → Options → Resource Packs**. Recommended for the new look. Without it, the mod uses stock sprites. No `.hmod` is needed. |

[Offline art preview](art-preview.png) · [Checks and hashes](VERIFICATION.md) · [Plus Fix install and recovery](../../docs/INSTALL.md)

## Install and use

1. In Plus Fix, unselect Tornado 1.x if present. Tap **Add .hnmod files** and choose the intact `.hnmod`. Use your **private build repo** and existing Plus workflow; build and install the result. A first smoke test works best with one mod. Do not choose the texture ZIP in Plus Fix.
2. In Android Files, open the intact **Studio Textures ZIP** with **Starling Modded Plus** if offered, or copy it to that game's `resourcepacks/`. If you've enabled shared storage, the relevant folder is `StarlingModdedPlus/resourcepacks/`; the folder in the official Starling app is separate. Enable the pack under **Options → Resource Packs** and apply the change. The pack only adds `starling_tornado:` sprites and a pack icon; it replaces no vanilla assets.
3. In a local test world, face a clearing. Type **`/tornado`** once to start; type it again to stop. A chat message identifies the current shape, EF preset, lifetime and whether **Studio textures** loaded. If it says stock texture fallback, confirm the pack is enabled in **the game you launched**. You can also start/stop with the first button in **Options → Mods → Tornado Studio → Settings** while in a local world.

### Tap a setting to cycle it

| Setting | Choices |
|---|---|
| **Shape** | Rope, Cone, Wedge, Twin vortex, or Shuffle (selects one at each start) |
| **Intensity** | EF0–EF5 or Random; visual size/rotation presets, not real wind speeds |
| **Scale** | 75%, 100%, 125%, 145% |
| **Palette** | Storm blue, Pale mist, Dry earth, Sunset |
| **Ground dust** | Off, Light, Heavy |
| **Wind lean** | Calm, Breeze, Strong (the funnel bends, its base stays put) |
| **Duration** | 15, 30, 45, 60, 90, 120 seconds of active game time; applies at the next start |
| **Detail** | Lite, Balanced, Ultra. Start with Balanced. Lite reduces fill and quad count; Ultra also filters nearby Studio tiles. |

Changes to the look blend into an active funnel when play resumes. They don't move it or reset its timer. The selected controls persist to the mod's own settings file. **Reset Studio settings** restores Cone, EF2, 100%, Storm blue, Light dust, Breeze, 45 s, Balanced. Do not use `/tornado EF5`, `set`, `spawn`, or `stop` from Tornado 1.x; change visuals on the page and toggle the same command to stop.

## Device smoke test · not yet run here

- Start in an open flat world with the Studio pack enabled. Verify the texture message says **Studio textures**. Look up or step back if the top is out of frame. Check a low and high quality setting and the game's **Particles** toggle for frame rate.
- Change Cone to Wedge, choose EF4, switch the palette and dust, and resume. Check the silhouette and color change in place. Try Twin vortex and Shuffle on repeat starts. Try 15 s on the next start and confirm the effect fades out. Toggle `/tornado` twice to confirm spawn and stop.
- Disable the Studio pack and start the effect again to test the vanilla fallback. Spawn one more, leave the world (or switch dimensions), and confirm no old funnel remains. Terrain, items, weather and mobs should not change.

The effect runs in the window for locally hosted worlds only. No external-server interception or LAN guest mirroring. No world edits, damage, weather changes, sound, extra permissions or network calls. Storm state isn't saved. If you have an older game with a different signer, don't uninstall or clear data to bypass the install warning.

## Editable source and rebuild

From the kit root with Python 3.11+:

```sh
P=projects/starling_tornado
mkdir -p work
# The 12 rendered PNGs are checked in; rebaking is only needed to edit the art.
python3 tools/kit.py pack native "$P/bundle" work/Starling-Tornado-Studio-2.0.0-starling-0.8.0.hnmod
python3 tools/kit.py pack resource "$P/pack" work/Starling-Tornado-Studio-Textures-2.0.0-java-26.3.zip
rustc --edition 2024 --test "$P/bundle/mixins/starling_tornado/model.rs" -o work/studio-tests
work/studio-tests
```

`tools/bake_textures.py` uses NumPy and Pillow to render the original RGBA tiles. `tools/frame_sample.rs` and `tools/preview_art.py` create the pack icon and offline art preview from a Rust snapshot of the actual effect geometry. Using the checked-in PNGs does not require NumPy, Pillow or any assets from Minecraft. See [verification](VERIFICATION.md) for the exact pins and Android check.
