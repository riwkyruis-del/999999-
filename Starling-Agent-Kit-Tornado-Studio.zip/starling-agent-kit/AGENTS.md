# Agent instructions · Starling

Read this file and [HANDOFF.md](HANDOFF.md) before changing anything. [`TARGETS.json`](TARGETS.json) defines the supported target. This is a **mod authoring kit**, not the Starling engine, Plus Fix APK source, or a GitHub build service.

## Standing rules

1. **Use the pinned sources.** Minecraft Java 26.3 on Starling v0.8.0, Android ARM64 (`arm64-v8a`). Match the full Starling and horizon-mixins commits in `TARGETS.json`. Don't quietly retarget to a new tag, Horizon `main`, or a different Java version. Read the pinned code for hook signatures and resource paths rather than guessing from Fabric/Forge docs.
2. **Choose the smallest format that does the job.** Native Rust behavior → code-only `.hnmod` for **Starling Mod Builder Plus Fix 2.0.1**. Declarative registries → `.hmod` for the game. Texture/model/sound overrides → resource pack ZIP for the game. If both code and assets are needed, keep them separate; don't relabel a Java JAR, old WASM package, or hybrid archive as a Plus input. See [format rules](docs/FORMATS.md).
3. **Keep mods scoped.** Use a unique lowercase ID with underscores for native examples and one owned namespace for content. Decide whether features are client-local, locally hosted, or server-authoritative before choosing hooks. Keep per-world/per-instance state bounded, clean it up on reload/exit, and avoid hidden network, permission, save, or world changes. Document expected side effects, co-mod conflicts and required packs. Use original or permitted assets and retain notices.
4. **Keep the user's installations and builds safe.** Do not change the production workflow, dispatch/retry a private run, push, alter repo visibility, install/uninstall an app, or touch saves unless explicitly asked. The kit repo may be shared; **the Plus build repo must be private**. Never request tokens or signing keys in chat. Native mods execute with the game's permissions, so review and compile only trusted sources. Test on a disposable world or verified backup copy.
5. **Separate evidence levels.** Packaging, pinned parse/Plus staging, weaving, Android ARM64 type checking, linked output, phone delivery and gameplay are distinct. Pass/fail/not run must refer to the current artifact hash and mod set. Do not equate a host build, a `cargo check`, or a successful runner log with an installed or played game. Use [the validation guide](docs/VALIDATE.md).

## For every new task

- Confirm requested behavior, target side and acceptance check. Read the matching example and inspect the precise upstream files ([source map](docs/SOURCES.md)). Ask only about consequential unknowns.
- Keep new source under `projects/<id>/` and scratch/tests under `work/`. Preserve immutable pins and prior releases unless re-targeting is explicitly approved; version any changed bundle. Do not use a previous artifact's test claims for modified files.
- Deliver original archives (not a nested ZIP renamed as a mod), editable source, build instructions, SHA-256, user-facing install/disable steps, and a short smoke test. If you cannot create files, return complete source and state what the user must run.
- Update `HANDOFF.md` or return a ready-to-merge [handoff entry](templates/HANDOFF-ENTRY.md), even if blocked. Include the first actionable error and next step. No private run links or raw sensitive logs in a shareable handoff.
