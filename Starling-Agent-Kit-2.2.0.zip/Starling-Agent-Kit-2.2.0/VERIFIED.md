# Verification · Starling Agent Kit 2.2.0

This is a new **kit**, not a new APK or a change to the compiler/workflow/signer. Previous releases were left intact.

| Check | Result |
|---|---|
| Modern local pair | `tools/horizon.py doctor` matched the exact published workspace APKs. Their earlier signed release audit's SHA-256s and shared signer are pinned in the modern profile; the kit only re-hashes them. |
| Real native `.hmod` routing | Downloaded only the exact published Accelerated Decay and Cloud Glass **0.2.1 source fixtures** to temporary storage. Checked size and full SHA-256, then routed both as native-source candidates. Verified the source's Horizon pin differs from the Starling APK commit. No mod code ran. Fixture files are not in this ZIP. |
| Automated suite | **31 passed, 1 skipped**: 8 new Horizon tests plus the 23 legacy checks, including unchanged Fast Workflow validator replay with the matching SHA-pinned parser. Optional old `cargo-horizon-mod` binary test was skipped. Kit Probe `.hnmod` and `.hmod` bytes still match the 2.1.0 examples. |
| Legacy `doctor` | Matched the Library 2.3.0 APK and its embedded Fast Workflow 1.1.0 YAML to the pinned standalone workflow; also matched the optional Compiler 2.2.0 APK. This doesn't prove that a phone still holds its original private signing key. |
| Obsidian research | Checked the project repo, beta.1/beta.2 primary release notes, APK release listing and README-only tagged tree. Numbers are publisher-reported observations, not a controlled Starling comparison. No Obsidian APK was installed, retained, or tested. |

Run checks from the kit root:

```sh
python3 -B -m unittest discover -s tests -v
python3 -B tools/horizon.py doctor
python3 -B tools/kit.py doctor
```

The exact legacy workflow tests need `STARLING_TEST_SOURCE` pointing to the pinned source containing `packaging/android/mod_build_server.py`; the script verifies the file hash before running the local replay. Set `STARLING_TEST_YAML` if the original YAML is not in the expected sibling release folder. `STARLING_TEST_VALIDATOR` enables the optional pinned CLI check. The modern `doctor` accepts paths to the separately downloaded APKs. Missing release files are **not** a reason to wipe an installed app.

## Known evidence and limits

- The earlier **Compiler 2.3.0 Horizon Edition** delivery verified APK Signature v2/v3, preserved the 16 upstream ARM64 libraries and five release assets, and completed 25 host checks, including exact A+B → B-only → empty with saves untouched in the host layout. Its 10-check live-catalog exercise was GET-only. This kit does not rerun the full APK audit or execute any native library.
- No live custom source submission, modern native compilation from kit-authored source, Android installation, paired-runtime gameplay, or Obsidian head-to-head benchmark was run. There is no Obsidian build profile and no port of the legacy Kit Probe included. `route` is not the full Compiler validator or a safety/trust assessment.
- Historical evidence for Plus is preserved in [legacy verification](guides/00-legacy-verification.md), and [phone acceptance](guides/06-horizon-090.md#phone-acceptance-not-yet-run) covers the current path.
