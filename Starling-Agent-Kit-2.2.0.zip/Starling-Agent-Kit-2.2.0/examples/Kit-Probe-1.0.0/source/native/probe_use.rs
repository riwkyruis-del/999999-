// Keep the return type spelling in sync with the pinned target (Result<()>).
fn probe_use(
    game: &mut crate::game::Game<'_>,
    button: winit::event::MouseButton,
    pressed: bool,
) -> core::ops::ControlFlow<Result<()>> {
    use core::ops::ControlFlow::{Break, Continue};
    if !pressed || button != winit::event::MouseButton::Right
        || game.integrated.is_none() || game.is_published()
        || !game.native_playing() || game.spectator() || game.using.is_some()
        || game.dialog_open()
        || game.remote.as_ref().is_none_or(|remote| !remote.loaded_sent)
    {
        return Continue(());
    }
    #[cfg(target_os = "android")]
    if game.mobile.touch_shield {
        return Continue(());
    }
    let slot = game.hotbar_presses.last().copied().unwrap_or(game.selected);
    if !game.stack_in(slot).is_some_and(|stack| &*stack.item == "kit_probe_items:probe") {
        return Continue(());
    }
    game.select_queued_hotbar();
    // Only local feedback: no block writes, game packets, or external I/O.
    game.native_chat("Kit probe OK: native code and content item are both active.");
    Break(Ok(()))
}
