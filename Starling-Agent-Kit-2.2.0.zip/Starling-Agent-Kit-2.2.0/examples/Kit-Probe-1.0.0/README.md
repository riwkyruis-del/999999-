# Kit Probe 1.0.0

A small two-file check for Starling Modded Plus. It is meant to confirm both delivery paths in a new test world, not to add gameplay rules. No custom textures or network services; the item points to a vanilla texture. The native code gives **local chat feedback only**.

| File | ID | Where it goes |
|---|---|---|
| `kit_probe_native-1.0.0.hnmod` | `kit_probe_native` | Compiler Library 2.3.0 → Mod Library → Only this, via Fast 1.1.0 |
| `kit_probe_items-1.0.0.hmod` | `kit_probe_items` | The installed Starling Modded Plus game, enabled for the test world |

See [compiler and phone](../../guides/03-compiler-and-phone.md) to install. Craft one stick + one redstone dust, or use the Kit Probe Items creative tab. Main-hand **Use** in a private single-player world should show: `Kit probe OK: native code and content item are both active.` A vanilla stick should not. The exact packages passed local archive, input and ARM64 type checks; this in-game check remains for the phone.

The editable sources are in [`source/`](source/). From the kit root, run:

```sh
python3 tools/kit.py pack examples/Kit-Probe-1.0.0/source --out local-runs/rebuilt-probe
```

The packer won't overwrite the example archives. To make a variant with new IDs, use `kit.py new` and change the behavior/content from that scaffold. To upgrade this example, bump the version in all three source manifests and keep `kit_probe_items:probe` stable unless you are intentionally migrating worlds.
