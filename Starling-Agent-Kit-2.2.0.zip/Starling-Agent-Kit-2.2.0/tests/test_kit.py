import contextlib
import io
import json
import os
from pathlib import Path
import struct
import sys
import tempfile
import unittest
import warnings
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
import kit
import replay_workflow as workflow

EXAMPLE = kit.BASE / "examples/Kit-Probe-1.0.0"
NATIVE = EXAMPLE / "kit_probe_native-1.0.0.hnmod"
CONTENT = EXAMPLE / "kit_probe_items-1.0.0.hmod"
PREFIX = "mixins/kit_probe_native/"
STARLING = os.environ.get("STARLING_TEST_SOURCE")
YAML = Path(os.environ.get("STARLING_TEST_YAML", workflow.DEFAULT_WORKFLOW))
VALIDATOR = os.environ.get("STARLING_TEST_VALIDATOR")


def members(path):
    with zipfile.ZipFile(path) as z:
        return {n: z.read(n) for n in z.namelist()}


class KitTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(prefix="kit-test-")
        self.addCleanup(self.directory.cleanup)
        self.tmp = Path(self.directory.name)

    def write(self, name, entries):
        p = self.tmp / name
        kit.zipout(p, entries)
        return p

    def delivery(self, name="fixture.zip", **changes):
        """Synthetic receipt/digest fixture, not an installable or real GitHub APK."""
        n = kit.native(NATIVE)
        fake = io.BytesIO()
        with zipfile.ZipFile(fake, "w") as z:
            z.writestr("note.txt", "This is a ZIP test payload, not an Android app.")
        data = fake.getvalue()
        import hashlib
        fields = {"schema": 2, "job": "9" * 32, "input_sha256": "7" * 64,
                  **{key: kit.T[key] for key in ("package", "starling", "abi", "mixins")},
                  "commit": kit.T["horizon"], "apk_sha256": hashlib.sha256(data).hexdigest(),
                  "apk_bytes": len(data), "mods": [{k: n[k] for k in ("id", "version", "sha256")}], **changes}
        return self.write(name, {kit.W["output_files"][0]: data, "receipt.json": json.dumps(fields).encode()})

    def test_shipped_pair(self):
        r = kit.check([NATIVE, CONTENT], EXAMPLE / "source")
        self.assertEqual(r["native_upload_bytes"], 8 + NATIVE.stat().st_size)
        self.assertEqual(r["pair"]["required_items"], ["kit_probe_items:probe"])
        self.assertIn("kit_probe_items:probe", r["content"][0]["recipe_results"])

    def test_example_rebuild_deterministic(self):
        dirs = [self.tmp / name for name in ("one", "two")]
        for build in dirs:
            kit.pack(EXAMPLE / "source", build)
        for path in NATIVE, CONTENT:
            self.assertEqual(members(path), members(dirs[0] / path.name))
            self.assertEqual(kit.sha(dirs[0] / path.name), kit.sha(dirs[1] / path.name))

    def test_standalone_packers(self):
        for track, path in (("native", NATIVE), ("content", CONTENT)):
            out = self.tmp / path.name
            kit.pack_one(EXAMPLE / "source" / track, out, None, track == "native")
            self.assertEqual(members(path), members(out))

    def test_scaffold_enforces_new_unique_id_and_packs(self):
        out = self.tmp / "new"
        kit.create("amber", 'Amber "Probe"', out)
        report = kit.pack(out, self.tmp / "out")
        self.assertEqual(report["native"][0]["id"], "amber_native")
        self.assertEqual(report["pair"]["required_items"], ["amber_items:probe"])
        with self.assertRaisesRegex(kit.KitError, "overwrite"):
            kit.create("amber", "Amber", out)
        with self.assertRaisesRegex(kit.KitError, "project ID"):
            kit.create("invalid-id", "Not portable", self.tmp / "bad")

    def test_pack_refuses_overwrite(self):
        (self.tmp / NATIVE.name).write_bytes(b"keep original")
        with self.assertRaisesRegex(kit.KitError, "output exists"):
            kit.pack(EXAMPLE / "source", self.tmp)
        self.assertEqual((self.tmp / NATIVE.name).read_bytes(), b"keep original")
        self.assertFalse((self.tmp / CONTENT.name).exists())

    def test_manifest_mismatch_and_missing_helper(self):
        patch = members(NATIVE)
        name = PREFIX + "horizon-mixin.toml"
        patch[name] = patch[name].replace(b'version = "1.0.0"', b'version = "1.1.0"')
        with self.assertRaisesRegex(kit.KitError, "disagree"):
            kit.native(self.write("mismatch.hnmod", patch))
        patch = members(NATIVE)
        del patch[PREFIX + "probe_use.rs"]
        with self.assertRaisesRegex(kit.KitError, "missing injection helper"):
            kit.native(self.write("missing.hnmod", patch))

    def test_old_pins_are_not_compatibility(self):
        patch = members(NATIVE)
        m = json.loads(patch["horizon-native.json"])
        m["mixins"] = "a" * 40
        patch["horizon-native.json"] = json.dumps(m).encode()
        with self.assertRaisesRegex(kit.KitError, "pins differ"):
            kit.native(self.write("wrong.hnmod", patch))

    def test_mixed_native_content_and_wrapper(self):
        patch = members(NATIVE)
        patch["horizon-mod.toml"] = members(CONTENT)["horizon-mod.toml"]
        with self.assertRaisesRegex(kit.KitError, "code-only"):
            kit.native(self.write("hybrid.hnmod", patch))
        with self.assertRaisesRegex(kit.KitError, "horizon-mod.toml"):
            kit.content(self.write("wrapper.hmod", {"extra/" + k: v for k, v in members(CONTENT).items()}))

    def test_zip_metadata_is_safe(self):
        path = self.tmp / "bad.hnmod"
        with zipfile.ZipFile(path, "w") as z:
            z.writestr("../outside", "not extracted")
        with self.assertRaisesRegex(kit.KitError, "invalid ZIP path"):
            kit.native(path)
        with zipfile.ZipFile(path, "w") as z:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", UserWarning)
                z.writestr("horizon-native.json", "{}")
                z.writestr("horizon-native.json", "{}")
        with self.assertRaisesRegex(kit.KitError, "duplicate paths"):
            kit.native(path)

    def test_native_set_limits_and_module_conflict(self):
        rec = kit.native(NATIVE)
        with self.assertRaisesRegex(kit.KitError, "one version"):
            kit.native_set([rec, rec])
        with self.assertRaisesRegex(kit.KitError, "most 10"):
            kit.native_set([{**rec, "id": f"m{i}"} for i in range(11)])
        with self.assertRaisesRegex(kit.KitError, "framing"):
            kit.native_set([{**rec, "id": f"m{i}", "bytes": 16 << 20} for i in range(2)])
        with self.assertRaisesRegex(kit.KitError, "expansion"):
            kit.native_set([{**rec, "id": f"m{i}", "expanded": 64 << 20} for i in range(3)])
        with self.assertRaisesRegex(kit.KitError, "duplicate Rust module"):
            kit.native_set([{**rec, "id": f"m{i}", "modules": [["game.rs", "shared"]]} for i in range(2)])
        self.assertTrue(kit.native_set([rec, {**rec, "id": "second"}])[1])

    def test_world_item_missing_from_pair(self):
        patch = members(CONTENT)
        del patch["data/kit_probe_items/horizon/item/probe.json"]
        with self.assertRaisesRegex(kit.KitError, "expected registry item"):
            kit.check([NATIVE, self.write("empty-item.hmod", patch)], EXAMPLE / "source")

    def test_receipt_consistency_and_expected_mod(self):
        r = kit.inspect_delivery(self.delivery(), "9" * 32, "7" * 64, [NATIVE])
        self.assertTrue(r["consistent"] and r["original_mods_checked"])

    def test_receipt_wrong_job_input_or_size(self):
        item = self.delivery()
        with self.assertRaisesRegex(kit.KitError, "different request"):
            kit.inspect_delivery(item, "1" * 32)
        with self.assertRaisesRegex(kit.KitError, "different upload"):
            kit.inspect_delivery(item, input_sha="2" * 64)
        with self.assertRaisesRegex(kit.KitError, "length"):
            kit.inspect_delivery(self.delivery("cut.zip", apk_bytes=1))

    def test_receipt_bad_digest_invalid_set_or_extra(self):
        with self.assertRaisesRegex(kit.KitError, "APK SHA-256"):
            kit.inspect_delivery(self.delivery(apk_sha256="1" * 64))
        fake_mod = {"id": "other", "version": "1.0.0", "sha256": "1" * 64}
        with self.assertRaisesRegex(kit.KitError, "doesn't match"):
            kit.inspect_delivery(self.delivery("wrong.zip", mods=[fake_mod]), expected_native=[NATIVE])
        patch = members(self.tmp / "fixture.zip")
        patch["summary.txt"] = b"wrong artifact"
        with self.assertRaisesRegex(kit.KitError, "too many ZIP entries"):
            kit.inspect_delivery(self.write("extra.zip", patch))

    def test_embedded_workflow_matches_and_rejects_changed_bytes(self):
        name = kit.PROFILE["compiler"]["embedded_workflow"]
        yaml = self.tmp / "example.yml"
        yaml.write_bytes(b"exact-copy\n")
        apk = self.write("example.apk", {name: yaml.read_bytes()})
        kit.embedded_workflow(apk, yaml)
        yaml.write_bytes(b"wrong-copy\n")
        with self.assertRaisesRegex(kit.KitError, "Copy workflow differs"):
            kit.embedded_workflow(apk, yaml)
        with self.assertRaisesRegex(kit.KitError, "Copy workflow differs"):
            kit.embedded_workflow(self.write("missing.apk", {"readme.txt": b"test"}), yaml)

    def test_existing_smb_copied_without_reframing(self):
        first = self.tmp / "original.smb"
        copied = self.tmp / "copied.smb"
        checksum = workflow.frame([NATIVE], first)
        self.assertEqual(workflow.copy_frame(first, copied), checksum)
        self.assertEqual(first.read_bytes(), copied.read_bytes())
        with self.assertRaisesRegex(kit.KitError, "original .smb"):
            workflow.copy_frame(NATIVE, self.tmp / "no.smb")
        with self.assertRaises(FileExistsError):
            workflow.copy_frame(first, copied)

    def test_framing_and_content_rejection(self):
        out = self.tmp / "mods.smb"
        checksum = workflow.frame([NATIVE], out)
        data = NATIVE.read_bytes()
        self.assertEqual(out.read_bytes(), b"SMB2" + struct.pack(">I", len(data)) + data)
        self.assertEqual(checksum, kit.sha(out))
        with self.assertRaisesRegex(kit.KitError, "only .hnmod"):
            workflow.frame([CONTENT], self.tmp / "content.smb")

    @unittest.skipUnless(VALIDATOR, "set STARLING_TEST_VALIDATOR to pinned cargo-horizon-mod")
    def test_pinned_validator(self):
        r = kit.check([NATIVE, CONTENT], EXAMPLE / "source", Path(VALIDATOR))
        self.assertEqual(r["native"][0]["official"]["kind"], "native-mod")
        self.assertEqual(r["content"][0]["official"]["api"], "0.2")


@unittest.skipUnless(STARLING and YAML.is_file(), "set STARLING_TEST_SOURCE and point at the Fast Workflow YAML")
class ExactReplayTests(unittest.TestCase):
    def run_frame(self, picks=None, *, raw=None, bad_sha=False):
        with tempfile.TemporaryDirectory(prefix="workflow-test-") as tmp:
            t = Path(tmp)
            if raw is not None:
                (t / "input.smb").write_bytes(raw)
            else:
                workflow.frame(picks, t / "input.smb")
            with contextlib.redirect_stderr(io.StringIO()) as log:
                r = workflow.replay(YAML, Path(STARLING), t, "8" * 64 if bad_sha else None)
            return r, log.getvalue()

    def test_exact_yaml_accepts_starter(self):
        r, log = self.run_frame([NATIVE])
        self.assertIn("Validated 1 selected mod(s)", log)
        self.assertEqual(r["mod_set"], [{"id": "kit_probe_native", "version": "1.0.0", "sha256": kit.sha(NATIVE)}])

    def test_exact_yaml_blocks_duplicate_id(self):
        with self.assertRaisesRegex(kit.KitError, "Two mods use the ID"):
            self.run_frame([NATIVE, NATIVE])

    def test_exact_yaml_checks_magic_length_and_sha(self):
        with self.assertRaisesRegex(kit.KitError, "Not a Plus mod set"):
            self.run_frame(raw=NATIVE.read_bytes())
        with self.assertRaisesRegex(kit.KitError, "cut short"):
            self.run_frame(raw=b"SMB2" + struct.pack(">I", 5) + b"one")
        with self.assertRaisesRegex(kit.KitError, "SHA-256"):
            self.run_frame([NATIVE], bad_sha=True)

    def test_exact_yaml_rejects_hybrid(self):
        with tempfile.TemporaryDirectory(prefix="mixed-archive-") as tmp:
            hybrid = Path(tmp) / "mixed.hnmod"
            patch = members(NATIVE)
            patch["horizon-mod.toml"] = members(CONTENT)["horizon-mod.toml"]
            kit.zipout(hybrid, patch)
            with self.assertRaisesRegex(kit.KitError, "Choose code-only"):
                self.run_frame([hybrid])

    def test_exact_yaml_warns_on_shared_cancellable_head(self):
        with tempfile.TemporaryDirectory(prefix="second-archive-") as tmp:
            t = Path(tmp)
            kit.create("other", "Second Probe", t / "second")
            out = t / "other_native.hnmod"
            kit.pack_one(t / "second/native", out, None, True)
            r, log = self.run_frame([out, NATIVE])
            self.assertEqual([m["id"] for m in r["mod_set"]], ["kit_probe_native", "other_native"])
            self.assertIn("can both cancel the same HEAD hook", log)

    def test_modified_workflow_is_not_executed(self):
        with tempfile.TemporaryDirectory(prefix="unmatched-workflow-") as tmp:
            p = Path(tmp) / "no.yml"
            p.write_text("name: Not the Fast Workflow\n", encoding="utf-8")
            with self.assertRaisesRegex(kit.KitError, "does not match"):
                workflow.script(p, "Validate the mods and check for conflicts", "PYTHON")


if __name__ == "__main__":
    unittest.main()
