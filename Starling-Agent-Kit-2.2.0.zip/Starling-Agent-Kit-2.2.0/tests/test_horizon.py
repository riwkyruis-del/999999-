"""Tests for the offline Horizon-profile doctor and routing hints."""
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
import horizon
import kit

ROOT = b'id = "test_mod"\nname = "Test Mod"\nversion = "0.1.0"\napi = "0.2"\ncapabilities = ["registries"]\n'
PINS = (b'[native]\ngame = "26.3"\nhorizon = "' + b'1' * 40 + b'"\nmixins = "' + b'2' * 40 + b'"\n')
CARGO = (b'[package]\nname = "test-mod"\nversion = "0.1.0"\nedition = "2024"\n[dependencies]\n'
         b'horizon-mod-api = { path = ".horizon/sdk/api/crates/horizon-mod-api" }\n')


class HorizonRoutingTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory(prefix="kit-horizon-test-")
        self.addCleanup(directory.cleanup)
        self.tmp = Path(directory.name)

    def make(self, pairs, name="test.hmod"):
        p = self.tmp / name
        with zipfile.ZipFile(p, "w", compression=zipfile.ZIP_DEFLATED) as z:
            for k, v in pairs.items():
                z.writestr(k, v)
        return p

    def raw(self, config=ROOT + PINS, cargo=CARGO):
        return {"horizon-mod.toml": config, "Cargo.toml": cargo, "src/lib.rs": b"// Shape fixture; not a runnable mod."}

    def test_candidate_binds_source_and_preserves_author_pins(self):
        p = self.make({**self.raw(), "data/c/tags/block/a.json": b"{}"})
        r = horizon.route(p)
        self.assertEqual(r["kind"], "native-source")
        self.assertTrue(r["compiler_candidate"])
        self.assertEqual(r["sha256"], kit.sha(p))
        self.assertEqual(r["author_pins"]["horizon"], "1" * 40)
        self.assertNotEqual(r["author_pins"]["horizon"], horizon.TARGET["starling_commit"])
        self.assertIn("not all payloads", r["note"])

    def test_content_does_not_go_to_compiler(self):
        p = self.make({"horizon-mod.toml": ROOT})
        r = horizon.route(p)
        self.assertEqual(r["kind"], "content")
        self.assertFalse(r["compiler_candidate"])

    def test_wasm_not_native(self):
        p = self.make({"horizon-mod.toml": ROOT + b'[wasm]\nfile = "mod.wasm"\n', "mod.wasm": b"\0asm"})
        self.assertEqual(horizon.route(p)["kind"], "wasm")
        self.assertFalse(horizon.route(p)["compiler_candidate"])

    def test_type_confusion_is_rejected(self):
        p = self.make(self.raw(ROOT + PINS + b"[wasm]\n"))
        with self.assertRaisesRegex(kit.KitError, "ambiguous manifest"):
            horizon.route(p)
        p = self.make({"horizon-mod.toml": ROOT, "Cargo.toml": CARGO})
        with self.assertRaisesRegex(kit.KitError, "requires a \\[native\\] table"):
            horizon.route(p)

    def test_legacy_example_cannot_be_made_modern_by_rename(self):
        old = kit.BASE / "examples/Kit-Probe-1.0.0/kit_probe_native-1.0.0.hnmod"
        renamed = self.tmp / "renamed.hmod"
        renamed.write_bytes(old.read_bytes())
        for p in (old, renamed):
            with self.subTest(file=p.suffix):
                self.assertEqual(horizon.route(p)["kind"], "legacy")
                self.assertFalse(horizon.route(p)["compiler_candidate"])

    def test_whole_game_and_crate_extensions_are_not_candidates(self):
        for kind, config, cargo, extras in (
            ("mixin", ROOT+PINS+b'[[native.mixin]]\nfile = "src/mixin.rs"\n', CARGO, {}),
            ("extra-dependency", ROOT+PINS, CARGO+b'external = "1"\n', {}),
            ("wrong-pin", ROOT+PINS.replace(b'26.3', b'1.21'), CARGO, {}),
            ("build-script", ROOT+PINS, CARGO, {"build.rs": b"// Script, not run."}),
        ):
            with self.subTest(kind=kind):
                r = horizon.route(self.make({**self.raw(config, cargo), **extras}, kind+".hmod"))
                self.assertFalse(r["compiler_candidate"])
                self.assertTrue(r["blockers"])

    def test_zip_paths_and_wrapper(self):
        for pairs, error in (
            ({**self.raw(), "../missing": b"x"}, "invalid ZIP path"),
            ({**self.raw(), "Data/a": b"x", "data/b": b"x"}, "case-colliding"),
            ({"wrapper/horizon-mod.toml": ROOT}, "missing.*horizon-mod.toml"),
        ):
            with self.subTest(error=error), self.assertRaisesRegex(kit.KitError, error):
                horizon.route(self.make(pairs))

    def test_doctor_requires_exact_both_files(self):
        compiler = self.tmp / "compiler.apk"
        runtime = self.tmp / "runtime.apk"
        compiler.write_bytes(b"Fixture: fake versioned compiler")
        runtime.write_bytes(b"Fixture: fake versioned runtime")
        pins = {**horizon.PROFILE, "compiler": {**horizon.PROFILE["compiler"], "sha256": kit.sha(compiler)},
                "runtime": {**horizon.PROFILE["runtime"], "sha256": kit.sha(runtime)}}
        with patch.object(horizon, "PROFILE", pins):
            self.assertEqual(horizon.doctor(self.tmp, compiler, runtime)["runtime"]["apk"], str(runtime.resolve()))
            runtime.write_bytes(b"Different bytes")
            with self.assertRaisesRegex(kit.KitError, "does not match"):
                horizon.doctor(self.tmp, compiler, runtime)
            runtime.unlink()
            with self.assertRaisesRegex(kit.KitError, "Missing runtime APK"):
                horizon.doctor(self.tmp, compiler, runtime)


if __name__ == "__main__":
    unittest.main()
