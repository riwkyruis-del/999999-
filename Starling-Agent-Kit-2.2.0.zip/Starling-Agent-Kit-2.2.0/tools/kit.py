#!/usr/bin/env python3
"""Legacy authoring for Starling Plus 0.8.0. For Horizon 0.9.0, use horizon.py. Python 3.11+."""
import argparse
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import tomllib
import zipfile

BASE = Path(__file__).resolve().parent.parent
PROFILE = json.loads((BASE / "profiles/fast-plus-1.1.0.json").read_text(encoding="utf-8"))
T, W, L = (PROFILE[k] for k in ("target", "workflow", "limits"))
MiB = 1 << 20
IDENT = re.compile(r"[a-z0-9][a-z0-9_]{0,63}\Z", re.ASCII)
RECEIPT_ID = re.compile(r"[a-z0-9][a-z0-9_-]{0,63}\Z", re.ASCII)
CONTROL = re.compile(r"[\x00-\x1f\x7f]")
NO_PATH = re.compile(r"[:\\\x00-\x1f\x7f]")
HEX256 = re.compile(r"[a-f0-9]{64}\Z", re.ASCII)
HEX128 = re.compile(r"[a-f0-9]{32}\Z", re.ASCII)


class KitError(ValueError):
    pass


def need(ok, msg):
    if not ok:
        raise KitError(msg)


def sha(path):
    with Path(path).open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def exact(path, digest, title):
    path = Path(path).resolve(strict=True)
    need(path.is_file() and sha(path) == digest, f"{title} does not match this profile: {path}")
    return path


def identifier(x):
    return isinstance(x, str) and IDENT.fullmatch(x) is not None


def version(x):
    return isinstance(x, str) and 1 <= len(x) <= 128 and not CONTROL.search(x)


def json_strict(b):
    def obj(items):
        out = {}
        for k, v in items:
            need(k not in out, f"duplicate JSON key: {k!r}")
            out[k] = v
        return out

    def const(val):
        raise KitError(f"non-finite JSON value: {val}")

    return json.loads(b, object_pairs_hook=obj, parse_constant=const)


def path_ok(name):
    parts = name.split("/")
    return (name and len(name) <= L["native_path_chars"] and not NO_PATH.search(name)
            and all(p not in ("", ".", "..") for p in parts))


@contextmanager
def opened(path, *, packed, expanded, entries, files):
    path = Path(path)
    need(path.is_file(), f"not a regular archive: {path}")
    need(0 < path.stat().st_size <= packed, f"archive is empty or exceeds {packed} bytes: {path.name}")
    with zipfile.ZipFile(path) as z:
        infos = z.infolist()
        names = [i.filename for i in infos]
        need(len(names) == len(set(names)) and len(names) <= entries, "duplicate paths or too many ZIP entries")
        members = {i.filename: i for i in infos if not i.is_dir()}
        total = sum(i.file_size for i in members.values())
        need(len(members) <= files and total <= expanded, "too many files or too much expanded ZIP data")
        for i in infos:
            trimmed = i.filename[:-1] if i.is_dir() else i.filename
            parts = trimmed.split("/")
            need(i.orig_filename == i.filename and path_ok(trimmed), f"invalid ZIP path: {i.orig_filename!r}")
            need(not any("/".join(parts[:k]) in members for k in range(1, len(parts)))
                 and not (i.is_dir() and trimmed in members), f"file/folder path conflict: {trimmed}")
            kind = stat.S_IFMT(i.external_attr >> 16)
            need(i.flag_bits & 1 == 0 and kind in (0, stat.S_IFDIR if i.is_dir() else stat.S_IFREG),
                 f"encrypted entry, link or special file: {trimmed}")
            need(i.compress_type in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED), f"use ZIP Store/Deflate: {trimmed}")
        yield z, members, total


def member(z, files, name, limit):
    info = files.get(name)
    need(info is not None and 0 < info.file_size <= limit, f"missing, empty or oversized {name}")
    return z.read(info)


def native_allowed(rel):
    p = rel.split("/")
    return (rel.endswith((".rs", ".toml")) or p[0] == "data" and len(p) >= 2
            or len(p) >= 3 and p[1] == "data"
            or len(p) <= 2 and (p[-1].startswith(("README", "LICENSE", "LICENCE", "COPYING", "NOTICE"))
                               or p[-1] == ".gitignore"))


def native(path):
    with opened(path, packed=L["native_archive_bytes"], expanded=L["native_expanded_bytes"],
                entries=L["native_entries"], files=L["native_files"]) as (z, items, total):
        meta = json_strict(member(z, items, "horizon-native.json", L["native_manifest_bytes"]))
        need(isinstance(meta, dict) and type(meta.get("schema")) is int and meta["schema"] == 1,
             "native manifest must be a schema 1 object")
        need(set(meta) <= {"schema", "id", "version", "game", "horizon", "mixins", "hooks"}, "unknown native manifest keys")
        need(identifier(meta.get("id")) and version(meta.get("version")), "invalid native ID or version")
        need(all(meta.get(key) == T[key] for key in ("game", "horizon", "mixins")),
             "game/revision pins differ from the kit; don't just relabel an old bundle")
        need("hooks" not in meta or (type(meta["hooks"]) is int and 1 <= meta["hooks"] <= 2**32 - 1),
             "hooks must be a positive API level when used")
        prefix = f"mixins/{meta['id']}/"
        for n in items:
            if n == "horizon-native.json":
                continue
            need(n.startswith(prefix) and native_allowed(n[len(prefix):]),
                 f"unexpected {n}: .hnmod must be code-only and inside {prefix}; put gameplay content in .hmod")
        b = tomllib.loads(member(z, items, prefix + "horizon-mixin.toml", L["mixin_manifest_bytes"]).decode("utf-8"))
        identity = b.get("mod")
        need(isinstance(identity, dict) and all(identity.get(k) == meta[k] for k in ("id", "version")),
             "native JSON and inner mixin TOML disagree on ID/version")
        compat = b.get("compatibility", {})
        need(isinstance(compat, dict) and compat.get("horizon_revision", T["horizon"]) == T["horizon"],
             "inner compatibility.horizon_revision is not the pinned Starling commit")
        parts = {k: b.get(k, []) for k in ("module", "injection", "state", "bridge", "crate")}
        need(all(isinstance(arr, list) and all(isinstance(e, dict) for e in arr) for arr in parts.values()),
             "manifest entries must be TOML array tables")
        need(any(parts.values()), "declare at least one real mixin operation, module, or crate")
        for key, field in (("injection", "helper"), ("module", "source")):
            for e in parts[key]:
                rel = e.get(field)
                need(isinstance(rel, str) and path_ok(rel) and prefix + rel in items,
                     f"missing {key} {field}: {rel!r}")
        heads = []
        modules = []
        for hook in parts["injection"]:
            if hook.get("kind") == "HEAD" and hook.get("cancellable") is True:
                need(isinstance(hook.get("target"), str), "cancellable HEAD target must be a string")
                heads.append(hook["target"])
        for e in parts["module"]:
            need(all(isinstance(e.get(k), str) and e[k] for k in ("file", "name")), "module needs file and name")
            modules.append([e["file"], e["name"]])
        # Read all member bytes to detect CRC/truncation, without extracting them.
        need(z.testzip() is None, "native archive CRC failed")
    return {"file": str(path), "id": meta["id"], "version": meta["version"], "sha256": sha(path),
            "bytes": Path(path).stat().st_size, "expanded": total, "bundled_crates": bool(parts["crate"]),
            "cancellable_heads": heads, "modules": modules}


def content(path):
    with opened(path, packed=64*MiB, expanded=512*MiB, entries=65536, files=65536) as (z, items, _):
        m = tomllib.loads(member(z, items, "horizon-mod.toml", MiB).decode("utf-8"))
        need(identifier(m.get("id")) and version(m.get("version")) and isinstance(m.get("name"), str)
             and m["name"].strip(), "invalid content ID/name/version")
        caps = m.get("capabilities")
        need(m.get("api") == "0.2" and m.get("side") == "both" and isinstance(caps, list) and "registries" in caps,
             "kit supports paired registry content: API 0.2, side both, capability registries")
        registered = []
        recipe_results = []
        for n, info in items.items():
            if n == "horizon-mod.toml":
                continue
            p = n.split("/")
            need(len(p) >= 3 and p[0] in ("assets", "data") and info.file_size <= 16*MiB,
                 f"content-only .hmod expected, with bounded files in assets/ or data/: {n}")
            if n.endswith(".json"):
                value = json_strict(z.read(info))
                if p[0] == "data" and p[2:4] == ["horizon", "item"]:
                    need(isinstance(value, dict), f"item definition must be an object: {n}")
                    registered.append(f"{p[1]}:{'/'.join(p[4:])[:-5]}")
                if p[0] == "data" and p[2] == "recipe" and isinstance(value, dict):
                    result = value.get("result")
                    if isinstance(result, dict) and isinstance(result.get("id"), str):
                        recipe_results.append(result["id"])
            elif n.endswith(".png"):
                with z.open(info) as image:
                    need(image.read(8) == b"\x89PNG\r\n\x1a\n", f"not a PNG: {n}")
        need(z.testzip() is None, "content archive CRC failed")
    return {"file": str(path), "id": m["id"], "version": m["version"], "sha256": sha(path),
            "bytes": Path(path).stat().st_size, "items": sorted(registered), "recipe_results": sorted(recipe_results)}


def native_set(picks):
    if not picks:
        return None, []
    ids = [x["id"] for x in picks]
    need(len(ids) <= L["selected_native_mods"], "Plus selects at most 10 native mods")
    need(len(set(ids)) == len(ids), "choose one version of each native ID")
    size = 4 + 4*len(picks) + sum(x["bytes"] for x in picks)
    need(size <= L["framed_upload_bytes"], "combined SMB2 upload including framing exceeds 32 MiB")
    need(sum(x["expanded"] for x in picks) <= L["native_set_expanded_bytes"], "combined native ZIP expansion exceeds 128 MiB")
    seen_modules, seen_heads, notes = {}, {}, set()
    for m in picks:
        for mod in map(tuple, m["modules"]):
            need(mod not in seen_modules, f"duplicate Rust module {mod}: {seen_modules.get(mod)} and {m['id']}")
            seen_modules[mod] = m["id"]
        for head in m["cancellable_heads"]:
            prior = seen_heads.setdefault(head, m["id"])
            if prior != m["id"]:
                notes.add(f"{prior} and {m['id']} can cancel the same HEAD target {head}; test separately and together")
    return size, sorted(notes)


def pair(project, n, c):
    cfg = json_strict((project / "project.json").read_bytes())
    need(isinstance(cfg, dict) and type(cfg.get("schema")) is int and cfg["schema"] == 1 and identifier(cfg.get("slug")),
         "project.json needs schema 1 and a valid slug")
    need(n["id"] == cfg.get("native_id") and c["id"] == cfg.get("content_id") != n["id"]
         and n["version"] == c["version"] == cfg.get("version"), "project IDs/version do not match the two packages")
    required = cfg.get("required_items")
    need(isinstance(required, list) and bool(required) and all(isinstance(i, str) for i in required),
         "project.json needs required_items")
    for item in required:
        need(item.startswith(c["id"] + ":") and item in c["items"], f"expected registry item not packaged: {item}")
    # The manifest checks identity and item presence, not what your Rust does.
    return {"project": cfg["slug"], "required_items": required}


def official(path, validator):
    result = subprocess.run([str(validator.resolve(strict=True)), "horizon-mod", "check", str(path.resolve()), "--json"],
                            check=False, text=True, capture_output=True)
    need(result.returncode == 0, f"pinned cargo-horizon-mod rejected {path.name}: {result.stdout.strip()} {result.stderr.strip()}")
    report = json_strict(result.stdout)
    need(isinstance(report, dict) and report.get("ok") is True, "validator did not report success")
    return report["report"]


def check(paths, project=None, validator=None):
    need(bool(paths), "select at least one archive")
    ns, cs = [], []
    for p in paths:
        need(p.suffix in (".hnmod", ".hmod"), f"choose .hnmod or .hmod, not {p.name}")
        n = p.suffix == ".hnmod"
        record = native(p) if n else content(p)
        if validator:
            record["official"] = official(p, validator)
        (ns if n else cs).append(record)
    size, notes = native_set(ns)
    need(len({c["id"] for c in cs}) == len(cs), "duplicate content mod ID")
    report = {"profile": PROFILE["profile"], "native": ns, "content": cs,
              "native_upload_bytes": size, "notes": notes, "typechecked": False, "phone_tested": False}
    if project:
        need(len(ns) == len(cs) == 1, "--project checks exactly one native and one content archive")
        report["pair"] = pair(project, ns[0], cs[0])
    return report


def create(slug, title, dest):
    need(identifier(slug) and len(slug) <= 54, "project ID: 1–54 lowercase letters/digits/underscore, starting with a letter or digit")
    need(0 < len(title.strip()) <= 70 and not CONTROL.search(title) and "@@" not in title,
         "title must be 1–70 visible characters")
    keys = {"SLUG": slug, "NATIVE": slug + "_native", "CONTENT": slug + "_items", "HORIZON": T["horizon"],
            "NAME_JSON": json.dumps(title, ensure_ascii=False), "ITEMS_JSON": json.dumps(title + " Items", ensure_ascii=False)}
    def render(s):
        return re.sub(r"@@([A-Z_]+)@@", lambda m: keys[m[1]], s)
    template = BASE / "templates/paired"
    need(not dest.exists() and not dest.is_symlink(), f"refusing to overwrite project: {dest}")
    dest.mkdir(parents=True, exist_ok=False)
    for f in sorted(template.rglob("*")):
        if f.is_file():
            out = dest / render(f.relative_to(template).as_posix())
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(render(f.read_text(encoding="utf-8")), encoding="utf-8", newline="\n")
    return {"project": str(dest), "native_id": keys["NATIVE"], "content_id": keys["CONTENT"],
            "item": keys["CONTENT"] + ":probe"}


def tree(root):
    need(root.is_dir() and not root.is_symlink(), f"missing real source directory: {root}")
    for p in sorted(root.rglob("*")):
        mode = p.lstat().st_mode
        need(stat.S_ISREG(mode) or stat.S_ISDIR(mode), f"no symbolic links or special files: {p}")
        if stat.S_ISREG(mode):
            yield p.relative_to(root).as_posix(), p


def zipout(path, payload):
    with zipfile.ZipFile(path, "x") as z:
        for name, data in sorted(payload.items()):
            need(path_ok(name), f"invalid output path: {name}")
            zi = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            zi.create_system, zi.external_attr = 3, (stat.S_IFREG | 0o644) << 16
            z.writestr(zi, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


def require_release(v):
    need(version(v) and re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+(?:-[A-Za-z0-9.-]+)?", v),
         "use a release version such as 1.0.0")


def native_payload(root, mid, v):
    need(identifier(mid), "native ID must start with a lowercase letter or digit and use [a-z0-9_]")
    require_release(v)
    native_meta = {"schema": 1, "id": mid, "version": v, **{k: T[k] for k in ("game", "horizon", "mixins")}}
    payload = {"horizon-native.json": (json.dumps(native_meta, indent=2) + "\n").encode()}
    total = len(payload["horizon-native.json"])
    for rel, f in tree(root):
        need(native_allowed(rel), f"unexpected native source file: {rel}")
        total += f.stat().st_size
        need(total <= L["native_expanded_bytes"] and len(payload) < L["native_files"], "native source too large")
        payload[f"mixins/{mid}/{rel}"] = f.read_bytes()
    return payload


def content_payload(root):
    payload, total = {}, 0
    for rel, f in tree(root):
        need(rel not in ("Cargo.toml", "horizon-native.json", "mod.wasm") and not rel.startswith("mixins/"),
             f"move native code out of content/: {rel}")
        if rel == "horizon-mod.toml" or rel.startswith(("assets/", "data/")):
            size = f.stat().st_size
            total += size
            need(size <= 16*MiB and total <= 64*MiB, "content source exceeds the kit packer's 64 MiB budget")
            payload[rel] = f.read_bytes()
    return payload


def publish(sources, out):
    # Exclusive creation prevents a concurrent release from being overwritten.
    published = []
    try:
        for path in sources:
            final = out / path.name
            with path.open("rb") as src, final.open("xb") as target:
                published.append(final)
                shutil.copyfileobj(src, target)
    except OSError:
        for path in published:
            path.unlink(missing_ok=True)
        raise
    return published


def outputs(out, *names):
    out.mkdir(parents=True, exist_ok=True)
    need(all(not (out/n).exists() and not (out/n).is_symlink() for n in names),
         "output exists; choose a new release folder or version")


def pack(project, out, validator=None):
    cfg = json_strict((project / "project.json").read_bytes())
    need(isinstance(cfg, dict) and type(cfg.get("schema")) is int and cfg["schema"] == 1 and
         all(identifier(cfg.get(k)) for k in ("slug", "native_id", "content_id")),
         "project.json needs schema 1 and valid IDs")
    mid, v = cfg["native_id"], cfg.get("version")
    require_release(v)
    nname, cname = f"{mid}-{v}.hnmod", f"{cfg['content_id']}-{v}.hmod"
    outputs(out, nname, cname)
    with tempfile.TemporaryDirectory(prefix=".kit-pack-", dir=out) as tmp:
        release = Path(tmp)
        archives = [release/nname, release/cname]
        zipout(archives[0], native_payload(project / "native", mid, v))
        zipout(archives[1], content_payload(project / "content"))
        report = check(archives, project, validator)
        built = publish(archives, out)
        for lane, path in zip(("native", "content"), built):
            report[lane][0]["file"] = str(path)
    return report


def pack_one(folder, out, validator, code):
    need(out.suffix == (".hnmod" if code else ".hmod"), "wrong output filename extension")
    outputs(out.parent, out.name)
    with tempfile.TemporaryDirectory(prefix=".kit-pack-", dir=out.parent) as tmp:
        p = Path(tmp) / out.name
        if code:
            manifest = tomllib.loads((folder / "horizon-mixin.toml").read_text(encoding="utf-8"))
            m = manifest.get("mod")
            need(isinstance(m, dict), "horizon-mixin.toml needs [mod]")
            payload = native_payload(folder, m.get("id"), m.get("version"))
        else:
            payload = content_payload(folder)
        zipout(p, payload)
        report = check([p], validator=validator)
        report["native" if code else "content"][0]["file"] = str(publish([p], out.parent)[0])
    return report


def embedded_workflow(app, workflow):
    with zipfile.ZipFile(app) as z:
        embedded = PROFILE["compiler"]["embedded_workflow"]
        entries = [i for i in z.infolist() if i.filename == embedded]
        expected = workflow.read_bytes()
        need(len(entries) == 1 and entries[0].file_size == len(expected)
             and z.read(entries[0]) == expected, "Library Copy workflow differs from the pinned YAML")


def doctor(workspace, workflow=None, app=None, legacy_app=None):
    use_w = exact(workflow or workspace/W["workspace_file"], W["sha256"], "Fast Workflow 1.1.0")
    c = PROFILE["compiler"]
    use_a = exact(app or workspace/c["workspace_file"], c["sha256"], f"{c['name']} {c['version']} APK")
    embedded_workflow(use_a, use_w)
    verified = {"kit_version": PROFILE["kit_version"], "profile": PROFILE["profile"], "workflow": str(use_w),
                "compiler": str(use_a), "compiler_version": c["version"], "embedded_workflow_matches": True,
                "install_path": W["install_path"], "target": T,
                "note": "local file checks only; no dispatch, key access or installation attempted"}
    if legacy_app is not None:
        legacy = PROFILE["legacy_signer_app"]
        verified["legacy_signer_app"] = str(exact(legacy_app, legacy["sha256"], "Original Compiler 2.2.0 APK"))
        verified["legacy_note"] = "The APK hash does not prove the installed app instance still has the game signing key."
    return verified


def inspect_delivery(path, job=None, input_sha=None, expected_native=None):
    apk, receipt = W["output_files"]
    cap = L["output_apk_bytes"]
    with opened(path, packed=cap + MiB, expanded=cap + 32768, entries=2, files=2) as (z, files, _):
        need(set(files) == {apk, receipt}, "choose the unmodified starling-plus-apk ZIP, not the log/input")
        r = json_strict(member(z, files, receipt, 32768))
        need(isinstance(r, dict) and type(r.get("schema")) is int and r["schema"] == W["receipt_schema"], "receipt schema mismatch")
        for field in ("package", "starling", "abi", "mixins"):
            need(r.get(field) == T[field], f"receipt {field} mismatch")
        need(r.get("commit") == T["horizon"], "receipt commit mismatch")
        for field, regex in (("job", HEX128), ("input_sha256", HEX256), ("apk_sha256", HEX256)):
            need(isinstance(r.get(field), str) and regex.fullmatch(r[field]), f"invalid receipt {field}")
        need(job is None or r["job"] == job, "artifact belongs to a different request job")
        need(input_sha is None or r["input_sha256"] == input_sha, "artifact belongs to a different upload")
        mods = r.get("mods")
        need(isinstance(mods, list) and 1 <= len(mods) <= L["selected_native_mods"], "invalid receipt mod set")
        ids = []
        for rec in mods:
            need(isinstance(rec, dict) and isinstance(rec.get("id"), str) and RECEIPT_ID.fullmatch(rec["id"])
                 and version(rec.get("version"))
                 and isinstance(rec.get("sha256"), str) and HEX256.fullmatch(rec["sha256"]), "invalid receipt mod entry")
            ids.append(rec["id"])
        need(ids == sorted(set(ids)), "receipt mod IDs are not sorted and distinct")
        if expected_native:
            picks = [native(path) for path in expected_native]
            native_set(picks)
            identity = lambda m: (m["id"], m["version"], m["sha256"])
            need(sorted(map(identity, picks)) == list(map(identity, mods)),
                 "the receipt mod set doesn't match the expected original .hnmods")
        need(type(r.get("apk_bytes")) is int and r["apk_bytes"] == files[apk].file_size and 0 < r["apk_bytes"] <= cap,
             "APK length differs from the receipt")
        with z.open(apk) as f:
            header = f.read(4)
            need(header == b"PK\x03\x04", "payload doesn't begin with a ZIP/APK header")
            h = hashlib.sha256(header)
            while part := f.read(MiB):
                h.update(part)
        need(h.hexdigest() == r["apk_sha256"], "APK SHA-256 differs from the receipt")
    return {"consistent": True, "receipt": r, "request_fields_checked": bool(job or input_sha),
            "original_mods_checked": bool(expected_native),
            "note": "local consistency only; not a GitHub authenticity, APK-signature or install check"}


def cli():
    p = argparse.ArgumentParser(description=__doc__)
    subs = p.add_subparsers(dest="command", required=True)
    d = subs.add_parser("doctor", help="match the app and workflow by exact SHA-256")
    d.add_argument("--workspace", type=Path, default=BASE.parent)
    d.add_argument("--workflow", type=Path)
    d.add_argument("--app", type=Path, help="Library 2.3.0 APK")
    d.add_argument("--legacy-app", type=Path, help="optionally match the separate original Compiler 2.2.0 APK")
    n = subs.add_parser("new", help="scaffold an editable paired item probe")
    n.add_argument("slug")
    n.add_argument("--name", required=True)
    n.add_argument("--out", required=True, type=Path)
    b = subs.add_parser("pack", help="make both native and content archives from one project")
    b.add_argument("project", type=Path)
    b.add_argument("--out", required=True, type=Path)
    b.add_argument("--validator", type=Path)
    for command, ext in (("pack-native", ".hnmod"), ("pack-content", ".hmod")):
        single = subs.add_parser(command, help="package one source folder as " + ext)
        single.add_argument("source", type=Path)
        single.add_argument("--out", required=True, type=Path)
        single.add_argument("--validator", type=Path)
    c = subs.add_parser("check", help="preflight archives without executing mod code")
    c.add_argument("archive", nargs="+", type=Path)
    c.add_argument("--project", type=Path)
    c.add_argument("--validator", type=Path)
    a = subs.add_parser("inspect-delivery", help="read and hash a downloaded unmodified APK artifact")
    a.add_argument("artifact", type=Path)
    a.add_argument("--job")
    a.add_argument("--input-sha")
    a.add_argument("--native", action="append", type=Path, help="expected original .hnmod; repeat for each mod")
    x = p.parse_args()
    if x.command == "doctor": return doctor(x.workspace, x.workflow, x.app, x.legacy_app)
    if x.command == "new": return create(x.slug, x.name, x.out)
    if x.command == "pack": return pack(x.project, x.out, x.validator)
    if x.command in ("pack-native", "pack-content"):
        return pack_one(x.source, x.out, x.validator, x.command == "pack-native")
    if x.command == "check": return check(x.archive, x.project, x.validator)
    return inspect_delivery(x.artifact, x.job, x.input_sha, x.native)


if __name__ == "__main__":
    try:
        print(json.dumps(cli(), indent=2, ensure_ascii=False))
    except (OSError, ValueError, KeyError, zipfile.BadZipFile, RuntimeError, TypeError) as e:
        print(f"Legacy Plus check failed: {e}", file=sys.stderr)
        sys.exit(1)
