#!/usr/bin/env python3
"""Replay the shipped Fast Workflow's native input validator, locally and offline."""
import argparse
import hashlib
import os
from pathlib import Path
import re
import struct
import subprocess
import sys
import tempfile
import textwrap

from kit import L, T, W, exact, json_strict, need, sha

DEFAULT_WORKFLOW = Path(__file__).resolve().parents[2] / W["workspace_file"]
PARSER = Path("packaging/android/mod_build_server.py")


def script(workflow, step, marker):
    raw = workflow.read_bytes()
    need(hashlib.sha256(raw).hexdigest() == W["sha256"], f"Fast Workflow 1.1.0 does not match this profile: {workflow}")
    source = raw.decode("utf-8")
    begin, sep, after = source.partition(f"      - name: {step}\n")
    need(sep and begin, f"workflow step not found: {step}")
    body = after.split("\n      - name: ", 1)[0]
    line = re.search(rf"<<'{re.escape(marker)}'[^\n]*\n", body)
    need(line, f"workflow script not found: {marker}")
    term = f"\n          {marker}\n"
    text, sep, _ = (body[line.end():] + "\n").partition(term)
    need(sep, f"unterminated workflow script: {marker}")
    return textwrap.dedent(text) + "\n"


def frame(bundles, path):
    need(1 <= len(bundles) <= L["selected_native_mods"], "choose 1–10 code-only .hnmod files")
    total = 4
    with path.open("xb") as f:
        f.write(W["input_magic"].encode("ascii"))
        for b in bundles:
            need(b.is_file() and b.suffix == ".hnmod", f"only .hnmod goes in SMB2: {b}")
            with b.open("rb") as src:
                data = src.read(L["native_archive_bytes"] + 1)
            need(0 < len(data) <= L["native_archive_bytes"], f"archive empty or exceeds 16 MiB: {b}")
            total += 4 + len(data)
            need(total <= L["framed_upload_bytes"], "upload with framing exceeds 32 MiB")
            f.write(struct.pack(">I", len(data)))
            f.write(data)
    return sha(path)


def python_script(code, root, **env):
    return subprocess.run([sys.executable, "-I", "-B", "-"], input=code, text=True,
                          capture_output=True, cwd=root,
                          env={**os.environ, "SBUILD_ROOT": str(root), "SBUILD_COMMIT": T["horizon"], **env})


def replay(workflow, source, root, expected_sha=None):
    root = root.resolve(strict=True)
    code = script(workflow, "Validate the mods and check for conflicts", "PYTHON")
    parser = (source / PARSER).read_bytes()
    need(hashlib.sha256(parser).hexdigest() == T["bundle_parser_sha256"], "upstream bundle parser differs from the pinned file")
    dest = root / "source" / PARSER
    if not dest.exists():
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(parser)
    else:
        exact(dest, T["bundle_parser_sha256"], "staged upstream bundle parser")
    checksum = sha(root / "input.smb") if expected_sha is None else expected_sha
    p = python_script(code, root, SBUILD_SHA=checksum)
    if p.stdout:
        print(p.stdout.rstrip(), file=sys.stderr, flush=True)
    need(p.returncode == 0, (p.stderr or p.stdout or "workflow validator exited without a report").strip())
    return {"input_sha256": checksum, "input_bytes": (root / "input.smb").stat().st_size,
            "mod_set": json_strict((root / "mod-set.json").read_bytes()),
            "validator": "exact Fast Workflow 1.1.0 input step; no hooks compiled"}


def copy_frame(src, dst):
    need(src.is_file() and src.suffix == ".smb", "choose an original .smb frame, not an APK or the enclosing ZIP")
    with src.open("rb") as f:
        blob = f.read(L["framed_upload_bytes"] + 1)
    need(0 < len(blob) <= L["framed_upload_bytes"], "SMB2 frame is empty or exceeds 32 MiB")
    with dst.open("xb") as f:
        f.write(blob)
    return hashlib.sha256(blob).hexdigest()


def cli():
    import json
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--workflow", type=Path, default=DEFAULT_WORKFLOW)
    p.add_argument("--starling", type=Path, required=True, help="pinned Starling source directory")
    p.add_argument("--input-smb", type=Path, help="replay an existing original SMB2 frame without reframing")
    p.add_argument("--input-sha", help="optional expected dispatch input SHA-256")
    p.add_argument("archives", nargs="*", type=Path)
    a = p.parse_args()
    if bool(a.input_smb) == bool(a.archives):
        p.error("use either --input-smb or a list of original .hnmods, not both")
    if a.input_sha is not None and not re.fullmatch(r"[a-f0-9]{64}", a.input_sha):
        p.error("--input-sha must be a lowercase SHA-256")
    with tempfile.TemporaryDirectory(prefix="starling-replay-") as tmp:
        root = Path(tmp)
        if a.input_smb:
            copy_frame(a.input_smb, root / "input.smb")
        else:
            frame(a.archives, root / "input.smb")
        print(json.dumps(replay(a.workflow, a.starling, root, a.input_sha), indent=2))


if __name__ == "__main__":
    try:
        cli()
    except (OSError, ValueError) as e:
        print(f"Workflow replay failed: {e}", file=sys.stderr)
        sys.exit(1)
