#!/usr/bin/env python3
"""Weave trusted .hnmods and run a locked, offline Linux-to-Android ARM64 check."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import tomllib

from kit import T, exact, native, native_set, need, sha
from replay_workflow import DEFAULT_WORKFLOW, frame, python_script, replay, script

MANIFEST = Path("crates/horizon-android/Cargo.toml")
STUB = Path("crates/horizon-android/plan-stub.rs")
NO_PLAN_ATTR = '#![cfg_attr(not(target_os = "android"), forbid(unsafe_code))]\n'
ADAPT = Path("packaging/android/native_mod_adapt.py")
OVERLAY = Path("packaging/android/plus-apk-status")


def run(args, env, cwd):
    print("+ " + " ".join(map(str, args)), flush=True)
    subprocess.run(args, check=True, env=env, cwd=cwd)


def publish_overlay(root, workflow, checksum):
    code = script(workflow, "Bind the Plus Mods page to the selected APK recipe", "PLUS_STATUS_PY")
    result = python_script(code, root, SBUILD_JOB="0" * 32, SBUILD_SHA=checksum)
    need(result.returncode == 0, "Plus status overlay failed: " + result.stderr)
    print(result.stdout.rstrip(), flush=True)
    source = root / "source"
    for file in sorted((source / OVERLAY).rglob("*")):
        if file.is_file():
            shutil.copyfile(file, source / file.relative_to(source / OVERLAY))


def arm(args):
    workflow, starling = args.workflow.resolve(strict=True), args.starling.resolve(strict=True)
    mixins = args.mixins_bin.resolve(strict=True)
    ndk, cargo_home = args.ndk.resolve(strict=True), args.cargo_home.resolve(strict=True)
    exact(starling / "Cargo.lock", T["horizon_lock_sha256"], "Starling Cargo.lock")
    exact(starling / ADAPT, T["adapt_script_sha256"], "upstream native adapter")
    need(args.trusted, "add --trusted only for code you control or reviewed; offline is not a sandbox")
    need(1 <= args.jobs <= 4, "choose 1–4 Cargo jobs")
    ndk_props = (ndk / "source.properties").read_text(encoding="utf-8")
    need(f"Pkg.Revision = {T['ndk']}" in ndk_props, "use the pinned Linux NDK r28c (28.2.13676358)")
    llvm = ndk / "toolchains/llvm/prebuilt/linux-x86_64/bin"
    need((llvm / "aarch64-linux-android26-clang").is_file(), "NDK API 26 ARM64 compiler is missing")
    records = [native(path) for path in args.archives]
    _, notes = native_set(records)
    need(not any(m["bundled_crates"] for m in records), "this local helper covers mixin-only bundles, not [[crate]]; use the full workflow for crates")
    for note in notes:
        print("NOTE: " + note, flush=True)
    scratch = args.scratch.resolve()
    need(scratch != starling and not scratch.is_relative_to(starling), "keep scratch outside the source directory")
    scratch.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, RUSTUP_TOOLCHAIN=T["rust"], CARGO_HOME=str(cargo_home), CARGO_INCREMENTAL="0",
               CARGO_BUILD_JOBS=str(args.jobs), CARGO_TARGET_DIR=str(scratch / "target"),
               ANDROID_NDK_HOME=str(ndk), CARGO_NET_OFFLINE="true", PYTHONDONTWRITEBYTECODE="1",
               RUSTFLAGS="-C link-arg=-Wl,-z,max-page-size=16384")
    with tempfile.TemporaryDirectory(prefix="woven-", dir=scratch) as tmp:
        root = Path(tmp)
        source = root / "source"
        shutil.copytree(starling, source, symlinks=True, ignore=shutil.ignore_patterns(".git", "target", "__pycache__"))
        # The same temporary-source transformation as upstream native_build.sh.
        for p in source.rglob("*"):
            if p.is_symlink():
                p.unlink()
        checksum = frame(args.archives, root / "input.smb")
        report = replay(workflow, starling, root, checksum)
        publish_overlay(root, workflow, checksum)
        (source / ".horizon-revision").write_text(T["horizon"] + "\n", encoding="utf-8")
        android = (source / MANIFEST).read_bytes()
        real_path = b'path = "../horizon-client/src/android_lib.rs"\n'
        need(android.count(real_path) == 1, "unexpected Android manifest in pinned tree")
        (source / MANIFEST).write_bytes(android.replace(real_path, b'path = "plan-stub.rs"\n'))
        (source / STUB).touch()
        lib = source / "crates/horizon-client/src/lib.rs"
        text = lib.read_text(encoding="utf-8")
        need(text.count(NO_PLAN_ATTR) == 1, "unexpected horizon-client root in pinned tree")
        lib.write_text(text.replace(NO_PLAN_ATTR, ""), encoding="utf-8")
        mods = root / "job/mods"
        for f in mods.glob("*/horizon-mixin.toml"):
            b = tomllib.loads(f.read_text(encoding="utf-8"))
            need(not b.get("crate"), "bundled crates require the full workflow")
        run([sys.executable, "-B", str(source / ADAPT), str(source), str(mods)], env, root)
        stage = root / "stage"
        run([str(mixins), "apply", "--workspace", str(source), "--mods", str(mods), "--out", str(stage)], env, root)
        (stage / MANIFEST).write_bytes(android)
        (stage / STUB).unlink(missing_ok=True)
        exact(stage / "Cargo.lock", T["horizon_lock_sha256"], "woven Cargo.lock")
        arm_script = script(workflow, "Prepare the pinned fast-build adapters", "ARM64_SH")
        if args.link:
            apk_builder = (starling / "packaging/android/build_apk.py").read_text(encoding="utf-8")
            need(env["RUSTFLAGS"] in apk_builder, "wait: pinned 16 KiB linker flags changed")
        else:
            need(arm_script.count("exec cargo build --locked --offline") == 1, "unexpected ARM64 script")
            arm_script = arm_script.replace("exec cargo build --locked --offline", "exec cargo check --locked --offline")
        runner = root / "arm64.sh"
        runner.write_text(arm_script, encoding="utf-8")
        run(["bash", str(runner), "arm64-v8a", str(T["android_min"]), T["cargo_profile"]], env, stage)
        exact(stage / "Cargo.lock", T["horizon_lock_sha256"], "checked Cargo.lock")
        report.update({"weave": "passed", "arm64": "linked" if args.link else "type-checked",
                       "target": T["triple"], "android_api": T["android_min"], "rust": T["rust"],
                       "ndk": T["ndk"], "cargo_lock_sha256": sha(stage / "Cargo.lock"),
                       "apk_packaged": False, "phone_tested": False, "github_dispatched": False})
        if args.link:
            libpath = Path(env["CARGO_TARGET_DIR"]) / T["triple"] / T["cargo_profile"] / "libhorizon_android.so"
            with libpath.open("rb") as f:
                ident = f.read(20)
            need(ident[:6] == b"\x7fELF\x02\x01" and ident[16:20] == b"\x03\x00\xb7\x00",
                 "linked library is not ARM64 ELF ET_DYN")
            report["arm64_library"] = {"bytes": libpath.stat().st_size, "sha256": sha(libpath)}
        print(json.dumps(report, indent=2), flush=True)


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--trusted", action="store_true")
    cli.add_argument("--workflow", type=Path, default=DEFAULT_WORKFLOW)
    cli.add_argument("--starling", type=Path, required=True, help="pristine pinned source tree (not installed app)")
    cli.add_argument("--mixins-bin", type=Path, required=True, help="horizon-mixins built at profile pin")
    cli.add_argument("--ndk", type=Path, required=True)
    cli.add_argument("--cargo-home", type=Path, default=Path(os.environ.get("CARGO_HOME", Path.home()/".cargo")))
    cli.add_argument("--scratch", type=Path, required=True, help="separate Linux scratch drive/folder with room for Cargo")
    cli.add_argument("--jobs", type=int, default=1)
    cli.add_argument("--link", action="store_true", help="also link the ARM64 library; substantially heavier, no APK")
    cli.add_argument("archives", nargs="+", type=Path)
    arm(cli.parse_args())


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, subprocess.CalledProcessError) as e:
        print(f"ARM64 check failed: {e}", file=sys.stderr)
        sys.exit(1)
