#!/usr/bin/env python3
"""Offline profile and package routing for the Starling 0.9.0 ARM64 pair (Python 3.11+)."""
import argparse
import json
from pathlib import Path
import re
import sys
import tomllib
import zipfile

from kit import BASE, KitError, exact, identifier, member, need, opened, sha

PROFILE = json.loads((BASE / "profiles/horizon-0.9.0-arm64.json").read_text(encoding="utf-8"))
TARGET, NATIVE = PROFILE["target"], PROFILE["native_route"]
MAX_TOML = 96 * 1024
PIN = re.compile(r"[a-f0-9]{40}")
VERSION = re.compile(r"[a-zA-Z0-9][a-zA-Z0-9_.+\-]{0,59}")
PART = re.compile(r"[a-zA-Z0-9_.+@\-]{1,160}")
MANIFEST_KEYS = set("id name version description authors license license_url credits homepage issues api side capabilities namespaces native properties".split())


def doctor(workspace, compiler=None, runtime=None):
    report = {"profile": PROFILE["profile"], "target": TARGET}
    for role, supplied in (("compiler", compiler), ("runtime", runtime)):
        ref = PROFILE[role]
        p = supplied if supplied is not None else workspace / ref["workspace_file"]
        need(p.is_file(), f"Missing {role} APK: {p}. Pass the matching release download with --{role}.")
        pinned = exact(p, ref["sha256"], f"{ref['name']} {ref['version']}")
        report[role] = {"apk": str(pinned), "sha256": ref["sha256"], "package": ref["package"]}
    report["note"] = "Both files match the pinned, previously audited APK bytes. No fresh signature or installation check."
    return report


def part_sanity(z):
    names = {}
    # Check shared parent paths as well as leaves, without extracting anything.
    for info in z.infolist():
        parts = info.filename.rstrip("/").split("/")
        need(len(parts) <= 30 and all(PART.fullmatch(p) for p in parts), "unsupported ZIP path")
        for i in range(1, len(parts) + 1):
            key = "/".join(parts[:i])
            need(names.setdefault(key.lower(), key) == key, "case-colliding ZIP paths")


def native_blockers(m, z, files):
    reasons = []
    if set(m).difference(MANIFEST_KEYS):
        reasons.append("Manifest uses a feature outside the app's API-only path (e.g. injections, internals or dependencies).")
    pins = m["native"]
    if set(pins) != {"game", "horizon", "mixins"}:
        reasons.append("Only the three native build pins are supported; mixin/module/whole-game declarations are excluded.")
    if pins.get("game") != TARGET["game"] or not all(isinstance(pins.get(k), str) and PIN.fullmatch(pins[k])
                                                      for k in ("horizon", "mixins")):
        reasons.append("Declare Java 26.3 and full lowercase Horizon and Mixins commit pins.")
    if m.get("api") != TARGET["mod_api"] or m.get("capabilities") != ["registries"]:
        reasons.append('The API-only path expects api = "0.2" and capabilities = ["registries"].')
    if m.get("side", "both") not in ("both", "server", "client"):
        reasons.append("Unsupported side.")
    if "src/lib.rs" not in files or not 0 < files["src/lib.rs"].file_size <= 4 * 1024 * 1024:
        reasons.append("Expected a non-empty src/lib.rs within the API-only path's size limit.")
    if any(n == "mod.wasm" or n.lower().endswith("/build.rs") or n.lower() == "build.rs" for n in files):
        reasons.append("Native source must not contain a build script or a root Wasm binary.")
    c = tomllib.loads(member(z, files, "Cargo.toml", MAX_TOML).decode("utf-8"))
    pkg, dep = c.get("package"), c.get("dependencies")
    if set(c).difference({"package", "dependencies", "lib"}) or not isinstance(pkg, dict):
        reasons.append("Use a single Cargo library crate without features, workspace or extra dependency sections.")
    elif pkg.get("edition", "2024") != "2024" or ("build" in pkg and pkg["build"] is not False):
        reasons.append("Use edition 2024 with no build script.")
    if not isinstance(dep, dict) or len(dep) != 1:
        reasons.append("The sole dependency must be the Horizon SDK API.")
    else:
        name, spec = next(iter(dep.items()))
        if not isinstance(spec, dict) or set(spec).difference({"path", "package"}) or \
           spec.get("package", name) != "horizon-mod-api" or spec.get("path") != NATIVE["api_dependency_path"]:
            reasons.append("Depend on the pinned SDK API path, with no features or external packages.")
    return reasons


def route(path):
    """Recommend an intake path, not complete validation of package payloads or ABI."""
    suffix = path.suffix.lower()
    need(suffix in (".hmod", ".hnmod"), "choose a .hmod or .hnmod archive; a .jar/.so/.apk is not mod source")
    with opened(path, packed=NATIVE["archive_bytes"], expanded=NATIVE["expanded_archive_bytes"],
                entries=NATIVE["max_archive_entries"], files=NATIVE["max_archive_entries"]) as (z, files, expanded):
        part_sanity(z)
        report = {"profile": PROFILE["profile"], "archive": str(path), "sha256": sha(path),
                  "expanded_bytes": expanded, "compiler_candidate": False,
                  "note": "Routing only: checks ZIP metadata and manifests, not all payloads, trust, Rust or runtime fit."}
        legacy = "horizon-native.json" in files or "horizon-mixin.toml" in files
        if legacy:
            return dict(report, kind="legacy", destination="Plus 0.8.0 only if its legacy checks pass; otherwise port the original source",
                        reason="Old .hnmod layout is not accepted on 0.9.0, even when renamed.")
        need(suffix == ".hmod", "modern .hmod requires that extension and a flat manifest; this is not a legacy native archive")
        m = tomllib.loads(member(z, files, "horizon-mod.toml", MAX_TOML).decode("utf-8"))
        ver, mod_id = m.get("version"), m.get("id")
        need(identifier(mod_id) and isinstance(ver, str) and VERSION.fullmatch(ver), "invalid or missing mod ID or version")
        report.update(id=mod_id, version=ver)
        native, wasm = "native" in m, "wasm" in m
        need(not (native and wasm), "ambiguous manifest: both native and Wasm declarations")
        if native:
            need(isinstance(m["native"], dict), "invalid [native] table")
            blocks = native_blockers(m, z, files)
            return dict(report, kind="native-source", compiler_candidate=not blocks, blockers=blocks,
                        author_pins=m["native"] if not blocks else None,
                        destination="Horizon Compiler -> Library" if not blocks else "Not supported by this ARM64 Compiler")
        need("Cargo.toml" not in files or wasm, "native Cargo.toml requires a [native] table")
        return dict(report, kind="wasm" if wasm else "content",
                    destination="Use a verified Wasm-capable target, not this Compiler" if wasm else "Import into the intended game, not this Compiler")


def cli():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="cmd", required=True)
    d = sub.add_parser("doctor", help="match both downloaded APKs to the exact released pair")
    d.add_argument("--workspace", type=Path, default=BASE.parent)
    d.add_argument("--compiler", type=Path)
    d.add_argument("--runtime", type=Path)
    r = sub.add_parser("route", help="identify the package family and the intended intake path")
    r.add_argument("archives", nargs="+", type=Path)
    args = p.parse_args()
    return (doctor(args.workspace, args.compiler, args.runtime) if args.cmd == "doctor"
            else [route(path) for path in args.archives])


if __name__ == "__main__":
    try:
        print(json.dumps(cli(), indent=2, ensure_ascii=True))
    except (KitError, OSError, ValueError, RuntimeError, zipfile.BadZipFile) as e:
        print(f"Horizon check failed: {e}", file=sys.stderr)
        sys.exit(1)
