# 02 · Author a `.hmod` for Java 26.3

> **Legacy · Plus 0.8.0.** For Starling 0.9.0, start with the [Horizon native `.hmod` guide](06-horizon-090.md).

This guide covers the **content-only `.hmod`** used in the legacy Kit Probe. Modern Horizon native and Wasm packages can also use `.hmod`; extension alone does not identify the type. It extends the game’s registries and carries its assets, recipes, and other Java-format data. Import it into the game; **do not add it to Starling Compiler**. A content-only release needs no new native build if the installed game already provides everything it uses. For a paired release, build/install its `.hnmod` and import its `.hmod` separately.

## 1. Start with a root manifest

```toml
id = "my_mod_items"
name = "My Mod Items"
version = "1.0.0"
description = "Items and recipes for My Mod."
authors = ["Your Name"]
api = "0.2"
side = "both"
capabilities = ["registries"]
```

Save as `horizon-mod.toml` in the content source. The kit covers the API `0.2` registry-content pattern (not arbitrary catalog mod types). The Java 26.3 target comes from the tested game/asset format; do not add a native-style `game` or revision field to this manifest. Unknown manifest keys can be rejected. Put this pack’s content in its own ID namespace; `namespaces` is only for extra namespaces you explicitly own. Two enabled mods claiming one namespace can cause one to be skipped. `side = "both"` is correct for items/blocks with registries used by both halves of the game; it does **not** certify multiplayer compatibility. For custom registries in multiplayer, server and clients need compatible sets; the pinned game checks ID/version and archive SHA-256 for `both` content. Kit Probe’s behavior is intentionally private single-player.

## 2. Give an item a single canonical ID

Here `my_mod_items:probe` is the identity shared by native code, item definition, recipe result, creative tab and assets. Copy this shape from the [example source](../examples/Kit-Probe-1.0.0/source/content/):

```text
horizon-mod.toml
assets/my_mod_items/
  items/probe.json               # item display -> my_mod_items:item/probe
  models/item/probe.json         # model -> minecraft:item/amethyst_shard or your texture
  lang/en_us.json                 # item.my_mod_items.probe and itemGroup.my_mod_items.probes
  textures/item/probe.png        # optional, only if your model points to my_mod_items:item/probe
data/my_mod_items/
  horizon/item/probe.json        # declares my_mod_items:probe
  horizon/creative_tab/probes.json
  recipe/probe.json              # Java 26.3, "recipe" singular
```

- **Registry** (`data/my_mod_items/horizon/item/probe.json`): `{"template":"minecraft:stick","max_stack_size":1,"rarity":"uncommon"}`. The item copies known components from its vanilla template. Don't choose a template whose built-in use behavior you don't want. To change a component use the 26.3 JSON component schema. `cargo-horizon-mod check` cannot prove that a component supplied by companion native code will actually be registered before game content loads.
- **Display** (`assets/my_mod_items/items/probe.json`): `{"model":{"type":"minecraft:model","model":"my_mod_items:item/probe"}}`. The `models/item/probe.json` points to a texture via `textures.layer0`. When you provide a PNG, use the ID `my_mod_items:item/probe` for `textures/item/probe.png` (no `.png` in the model’s key value). Without that layer, a valid registry item can exist yet render missing-texture colors.
- **Name and creative tab:** `assets/my_mod_items/lang/en_us.json` maps `item.my_mod_items.probe` and `itemGroup.my_mod_items.probes` to visible names. The tab’s `title`, `icon`, `items` reference the language key and full item ID. Check both in-game appearance and a lookup in the creative inventory.
- **Recipe** (`data/my_mod_items/recipe/probe.json`): use 26.3 ingredient syntax and `result.id`. That file gives `my_mod_items:probe` for one stick and one redstone dust:

```json
{
  "type": "minecraft:crafting_shapeless",
  "category": "equipment",
  "ingredients": ["minecraft:stick", "minecraft:redstone"],
  "result": {"id": "my_mod_items:probe", "count": 1}
}
```

For blocks, effects, entity types or menus, use the specific `data/<id>/horizon/<kind>/` layout in the pinned docs. Register an ID once; use it consistently in loot, tags, recipes, model references and Rust. New item/recipe JSON may pass parsing with a typo in a reference, so craft/use it in the game. Do not put block/item registry declarations in a resource-only ZIP, and do not treat a Fabric/NeoForge jar or Bedrock addon as a Horizon package.

## 3. Pack and validate independently

Run from the kit root; the source folder should contain `horizon-mod.toml`, `assets/`, and `data/` directly. Keep code, Cargo outputs, and generated release archives out of the tree. The ZIP case/path spelling matters.

```sh
python3 tools/kit.py pack-content projects/my_mod/content --out releases/my_mod_items-1.0.0.hmod
python3 tools/kit.py check releases/my_mod_items-1.0.0.hmod --validator "$VALIDATOR"
```

Or use Starling’s pinned CLI (set `VALIDATOR` to the absolute `cargo-horizon-mod` from [local validation](04-local-validation.md)):

```sh
(cd projects/my_mod/content && "$VALIDATOR" horizon-mod build)
"$VALIDATOR" horizon-mod check projects/my_mod/content/target/horizon-mod/my_mod_items.hmod --json
```

The kit packer keeps content sources to 64 MiB expanded so it can build them in memory with Python. The pinned game reader’s limits are different: 16 MiB per content file, 512 MiB expanded across content, at most 65,536 content files. The native workflow size limits are **not** allowances for a content pack. For larger packages or an advanced manifest, use the pinned CLI and test the actual Android import; don't use the kit’s local profile as a general-purpose registry validator.

## 4. Install and test in the right world

1. Open/import the `.hmod` with **Starling Modded Plus**, not the Compiler or another Starling installation. The installed pack belongs in the active game root’s `horizon-mods/`. Verify **Options → Mods** lists it and shows no load error. Use **Open Folder** on the Plus Mods page to locate the active root if you have several instances.
2. Registry content is bound to world creation/loading. In a new test world select the pack in **Create New World → More → Mods & Data Packs** and allow a restart/reload if prompted. **Options → Mods** sets global defaults; turning it on there is not a reliable way to retrofit registries into an existing save with a recorded set.
3. Check name/model/texture, recipe output, stack behavior, and (if paired) the native action. Save, exit, reopen and verify the registry items persist. Test an unaffected vanilla item too. The new registry’s `.hmod` can install and craft without the native action; the reverse can compile yet never see the needed item.
4. A world records its content IDs in `saves/<world>/horizon-content.json`. If an old world complains about a missing mod, restore the original content release before retrying. Back up the world and test changes on a copy; do not delete/edit its recorded set to force it open. Registry changes can make saved blocks/items unload or lose meaning.

**Updates:** Retain IDs for existing blocks/items unless you provide a migration. Ship matching versions of a paired release and keep the previous files and save backup. Importing a newer `.hmod` may leave the older file in the folder. With the game closed and a verified backup, keep only the intended active file for the same mod ID in the active `horizon-mods/`; don't remove content needed by other worlds. A native-only APK update does not bundle or migrate your `.hmod`. Re-import only if it is missing or you intend to replace its version.

## Pinned source references

[Content mods and manifest](https://github.com/starling-client/starling/blob/ac874422ed8f892505ff73d67ae486ecfee7a516/docs/mods.md) · [Registry data format](https://github.com/starling-client/starling/blob/ac874422ed8f892505ff73d67ae486ecfee7a516/docs/modpacks.md) · [Importer](https://github.com/starling-client/starling/blob/ac874422ed8f892505ff73d67ae486ecfee7a516/crates/horizon-client/src/import.rs) · [Per-world content](https://github.com/starling-client/starling/blob/ac874422ed8f892505ff73d67ae486ecfee7a516/crates/horizon-client/src/game/world_content.rs)
