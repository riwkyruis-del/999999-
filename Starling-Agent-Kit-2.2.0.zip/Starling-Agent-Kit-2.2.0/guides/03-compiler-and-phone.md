# 03 · Build from Mod Library and install safely

> **Legacy · Plus 0.8.0.** For Starling 0.9.0, start with the [Horizon native `.hmod` guide](06-horizon-090.md).

Use **Starling Compiler Library 2.3.0** on Android 8.0 (API 26) or newer with **arm64-v8a** support. The game target remains **Starling Modded Plus 0.8.0 / Java 26.3**. You need a private GitHub repo with enabled Actions. The kit is not an app installer or a game APK.

## 1 · Set up the workflow once

1. Use an initialized **private** repo you control. On its default branch put **Fast Workflow 1.1.0** at **`.github/workflows/starling-compile-10.yml`**. Library 2.3.0’s **Workflow setup → Copy workflow** supplies the exact YAML; the separate Fast Workflow download is identical. If it is already installed correctly, change nothing. In GitHub Actions the workflow is called **Starling Compiler 10**. The original Compiler 2.2.0’s copy is older and should not replace it.
2. Open **Workspace → Connect repo**. Use a **fine-grained GitHub token** scoped only to that private repo: **Actions: Read and write**, **Contents: Read and write**; Metadata read is automatic. Enter it only in your trusted Compiler app. Do not paste the token into an author chat, diagnostics, workflow file, repo secret, or the kit. The receive job uses the workflow's scoped token to fetch input; the build job has no repo permissions.
3. Private runner quotas, org policy or token approvals can affect dispatch. **Experimental setup reuse** is optional. It can reuse verified public dependency downloads, never a different native set or a previously built APK.

## 2 · Import and choose the exact native set

1. In **Workspace → Mod Library**, tap **Import .hnmods** and select original, trusted archives. Do not select `.hmod`, `.jar`, a project ZIP, `.smb`, a compiled `.so`, or an `.apk`. New archives are saved **OFF**. The library holds up to **64** archives / **256 MiB**, one archive per native ID. Re-importing identical bytes preserves the choice; importing different bytes for that ID replaces its entry and sets it **OFF**. Keep your original downloads separately.
2. Use **Only this** for one mod, or switch on the exact set you want. **Deselect all** clears only the choices. Disabled archives stay available across launches, builds and history pruning. **Forget** removes the library entry and disables it; it does not delete your Downloads or installed game. History’s **Save archives to library** adds available original files **OFF**, without overwriting existing versions or selections. A recovered APK cannot supply its original `.hnmod`s.
3. Tap **Review exact build**. Check IDs, versions and short SHA-256 fingerprints. The workflow requires **1–10** enabled IDs and a framed upload of at most **32 MiB**. If nothing is enabled, no build runs. There is no Keep switch or implicit merge. If a file is missing, changed or incompatible, the app refuses that selection rather than substituting an older or different mod. Confirm only when the reviewed set is correct.
4. The approved job retains that exact set even if you change switches later. The workflow compiles from pinned source, not from the installed APK. A successful delivery replaces the **entire compiled native set** when you install and relaunch it. It does not erase worlds, `.hmod`s, packs or settings. Back up important saves anyway, especially if an older mod changed world state or added content.

## 3 · Install with the right signer

**Keep the original game and its signing app intact.** Library 2.3.0 has a new app ID and installs next to 2.2.0. The former app’s release signing key is unavailable for an in-place companion update. Separately, the local signing key for your **game** lives in the Android Keystore of the app instance that prepared the game. Installing a second copy of that app or using the same GitHub token cannot recreate that key. Copy or export your worlds, `horizon-mods/`, resource packs and any game backup files you need, and verify those backups before changing the installed build. Android auto-backup is not a substitute.

| When | What to do |
|---|---|
| **Fresh Plus install, or existing Plus already signed by this Library app** | When **Ready to install**, tap **Install Starling Modded Plus**, grant permission to install unknown apps to this trusted app if necessary, then approve the Android installer. Preserve this Library app and its data for subsequent updates. |
| **Installed Plus was signed by the original Compiler** | After the result passes receipt and APK checks, Library shows **Install with original signer**. Tap **Copy GitHub run link**. Open the **original** Compiler (usually 2.2.0); make sure it is connected to the same private repo and has no active job blocking recovery. Open **History → Recover successful run**, paste the link, and tap **Recover APK**. When it shows **Ready to install**, install through that app. Recovery downloads the same successful run, signs with that instance’s original key and does **not** build or add any mods. Don’t use the old Workspace to rebuild. |
| **Original app or key missing, or Android rejects the update** | Stop. No signing bypass or forced downgrade is supported. An APK signed with a different key cannot update the installed same-package game. Check the original signer, installer permission, version, ARM64, storage and correct Android user/profile. Keep the existing game installed until you have verified backups and a migration plan. |

The old app can only recover a run while GitHub can serve its artifact (normally up to three days). It still checks package and signatures. A recovery record does not know the original Library selection, so compare the run ID and reviewed list in Library before handing off. Do not choose a different or older run to install unless you want its compiled set.

## 4 · Phone acceptance: replace A with B, keep the saves

Do this on a test phone or on a backed-up game with a disposable world. Use trusted, compatible originals.

1. **Record A:** In **Plus → Options → Mods**, note the installed APK ID and compiled native IDs/versions. For an existing install with `starling_orbital_laser`, that can be A; you do **not** need the Orbital Laser archive to exclude it. Otherwise build a known test mod A first.
2. **Select B:** Import `kit_probe_native-1.0.0.hnmod` as B, tap its **Only this**, close/reopen Library, and check it still has B ON. If A is saved too, it should stay OFF. Check the old game still shows A before installing a replacement.
3. **Build and install:** Review **B only**. Check Library’s job has that same set; use the signer route above. Force a clean relaunch of **Starling Modded Plus** after Android reports installation success. The new **compiled native mods** list must say B only: A must be absent. An `.hmod` content row is separate and should not be interpreted as an extra compiled native mod.
4. **Check saved data:** Verify the disposable world and its original content entries still exist. For the Kit Probe gameplay check, import `kit_probe_items-1.0.0.hmod` in Plus (not in the Compiler), then make a fresh single-player world with **More → Mods & Data Packs → Kit Probe Items** selected. Craft the item with stick + redstone, use it in the main hand at empty space, and verify the local message. Check a regular stick as a negative control. Do not remove required content from an existing world just to run this test.
5. **Optional stronger test:** With two compatible native originals, build A+B → both should show. Then disable A and build again → only B. Test **Deselect all** separately; review should be unavailable, not a vanilla rebuild. Record each run ID, selection, observed compiled list and signer route.

## If something fails

| Symptom | Next action |
|---|---|
| No run or workflow not found | Check private repo, default-branch filename, workflow enabled, token scope/expiry, and Actions job name. Don’t dispatch a duplicate while the first run might be queued. |
| Archive rejected or Rust/weave error | Check Java 26.3, original archive kind, manifest pins/size, and first workflow error. Try the smallest exact set using **Only this**. Use [local validation](04-local-validation.md); shared hook warnings still require behavior tests. |
| Run succeeded but no APK yet | Check Wi-Fi-only settings and available space. Use **History → Retry download**. If necessary get the matching `starling-plus-apk-<job>` ZIP from GitHub’s run summary and use **Import GitHub ZIP**. Keep it unmodified. If GitHub lists no ZIP digest, use the authenticated in-app download. |
| No history, or artifact expiring | Connect to the same repo and use **Recover successful run** with the run page URL. APK and log artifacts request three days’ retention; input artifacts request one day. If the artifact expired, use a valid cached signed APK or rebuild the exact set while you still have the originals. |
| Mod listed but feature missing | Check the actual game APK ID, native version, `.hmod` import and per-world registry selection, item ID, controls, private-world guard and competing hooks. A status line is not a behavior test. |

## Build contract

- Dispatch: `job_id`, `release_id`, `asset_id`, `input_sha256`, optional `experimental` (default false). Draft `smb-plus-job-<job_id>` contains `mods.smb`: `SMB2` + repeated 4-byte big-endian length and unchanged `.hnmod` bytes.
- Delivery: `Starling-Modded-Plus-unsigned.apk` + schema-2 `receipt.json`. Job, input digest, pins, sorted native IDs/versions/archive hashes, and APK hash/size all matter. For a normal Library job, the app checks the receipt against its approved mod list before signing or presenting the safe handoff. `.hmod`s never appear in the receipt.
- Share privately: run URL, first useful error, reviewed IDs/versions, exact file digests, and relevant receipt fields. Redact tokens, personal paths and any logs you don’t intend to share.
