# Agent instructions · Starling Plus mods

The target is the `fast-plus-1.1.0` profile in [`profiles/fast-plus-1.1.0.json`](../profiles/fast-plus-1.1.0.json). Always distinguish the **Compiler Library companion (2.3.0)**, **Fast Workflow YAML (1.1.0)**, and **game APK (Starling Modded Plus 0.8.0 / Java 26.3)**. Leave the companion and workflow bytes alone when building mods. Library 2.3.0 embeds Fast 1.1.0. Do not use the old 2.2.0 Copy workflow template or refer users to a retired status-fix folder.

## Decide what to ship

- Data and visuals only → `.hmod` for the game. Behavior only → `.hnmod` for the Compiler. New behavior **and** new registries/assets → two separate files with distinct mod IDs. Never rename a `.jar` or pack into either format and never put root `assets/`, `data/` or `horizon-mod.toml` in a Plus `.hnmod`.
- Agree on the target mode before adding behavior that changes saves, inventory, entities, or blocks. Default to a disposable private single-player test when the user did not request multiplayer. Keep it opt-in by item/action; no unnecessary permissions, remote services, install secrets, or unrelated world changes.
- Pick durable, unique lowercase IDs with underscores. Keep the shared fully qualified content IDs in a single code constant/table and in `project.json`’s `required_items`; the checker can confirm the JSON definitions exist, **not** that Rust references them correctly. Do not rename persisted IDs as a casual version bump.

## Build in small steps

1. Read [native](../guides/01-native-authoring.md) and/or [content](../guides/02-content-authoring.md). Use `kit.py new` for a new paired project, or the standalone pack commands. Use editable source folders; do not edit an archive in place. Keep generated files outside `native/` and `content/`.
2. For a native hook, inspect the **pinned Starling** declaration, call sites, exact scope/type, Android input path, ownership/state and activation conditions. Prefer a stable hook where it fits; no blanket overwrite for a simple feature. If an internal hook is needed, document why, what returns normally, and the narrow condition that cancels it. Keep game decisions authoritative: do not let a UI message or a client-supplied target directly change world state.
3. Validate package structures and identities; run pinned `cargo-horizon-mod check ... --json` on each archive. Replay the real YAML validator on the **exact** chosen `.hnmod` bytes. Weave and type-check for ARM64; report linkage, GitHub dispatch, install and gameplay separately. Test each native mod alone before testing the full set. A shared cancellable hook can pass validation yet block the other mod’s behavior.
4. Include archives, editable source, SHA-256s, player instructions, and known limitations. Follow the [release checklist](../guides/05-release-checklist.md). Redact tokens and private repo details in shared logs. A local pass is not a GitHub/phone pass; mark unrun checks explicitly.

## Select and install without carrying mods over

- Import original `.hnmod` files into **Mod Library**. New/changed bytes are OFF by default. Use **Only this** to build one archive; otherwise check each switch. Review native IDs, versions and hashes. Only 1–10 enabled IDs are dispatched. Never include a mod based on the old APK, saved library membership, a History record or loose game files alone.
- Treat “reset” as **replace compiled native code with the reviewed set**, not delete saves, content or app data. The running game changes only after Android installs the replacement. Avoid telling users to turn off compiled code through the game’s content selector.
- If Android requires the original game signer, use Library’s verified run link and recover **the same run** in the still-installed original Compiler. Never re-sign a different artifact, bypass Android checks, ask for a private key, or suggest clearing data as a normal upgrade step. If the key is gone, stop and discuss verified backups/migration rather than promising in-place installation.

## Where to look

- The [Kit Probe source](../examples/Kit-Probe-1.0.0/source/) is the smallest included paired example. The separately delivered **Elemental Magic 1.0.0** is a larger pattern: `.hnmod` implementation plus `.hmod` items, assets and recipes. Do not edit or repackage a previously delivered release as part of authoring a new one.
- For upstream behavior, follow the exact commit links in the native/content guides. The Plus workflow adds an APK-bound native status overlay and ships an **APK**, not the upstream launcher’s separate native library. Use the Plus phone guide, not upstream phone build instructions.
