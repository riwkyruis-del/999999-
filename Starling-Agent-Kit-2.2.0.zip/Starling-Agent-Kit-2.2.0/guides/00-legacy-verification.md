# Verification · Agent Kit 2.1.0

The target is unchanged: **Fast Workflow 1.1.0 → Starling Modded Plus 0.8.0 / Java 26.3 / ARM64**. This release adds the **Compiler Library 2.3.0** profile and exact-build phone flow. The Kit Probe source and archives did not change from 2.0.0.

## Checks run for this release

| Check | Result |
|---|---|
| Pairing with the new Compiler | `doctor` matched the exact Library 2.3.0 APK, its embedded YAML, and the separate Fast 1.1.0 download. The old 2.2.0 installer passed the optional `--legacy-app` check and was correctly rejected as the primary Library APK. |
| Kit tests | **23 passed, 1 skipped** with the pinned workflow parser and exact YAML. The skip was the optional external `cargo-horizon-mod` executable, not rebuilt for this kit update. The suite included the new embedded workflow and exact SMB2 copy checks. |
| APK-library and workflow integration | **15 host scenarios** passed against translated code from the signed Library APK. Exact YAML intake accepted the app-produced A-only, A+B and B-only frames. B-only matched one unmodified Kit Probe archive. Receipt tests rejected an extra mod, a substituted mod and a wrong input digest. |
| Existing input replay | `replay_workflow.py --input-smb … --input-sha …` accepted the exact 1,536-byte Kit Probe frame. No Rust was run in this step. |
| Not run | Live dispatch/download, Android UI/Keystore/installation, original-signer handoff on a phone, linked Kit Probe native library, installed-game or save tests. Use [the phone acceptance checklist](../guides/03-compiler-and-phone.md). |

## Carried forward for unchanged Kit Probe bytes

In Kit 2.0.0, the exact archives below passed pinned `cargo-horizon-mod check … --json`; the standalone packers reproduced the shipped bytes. The Android adapter, Plus status overlay, pinned Mixins weave and locked/offline ARM64 `cargo check` (`quick`, Rust 1.100.0, NDK r28c/API 26) passed for the exact shipped native bundle. That result is a type-check, not linkage, APK packaging or phone smoke. The prior kit’s 22-test run included the external package validator. Those prior checks were not rerun as part of the Library APK release.

| Exact example | Bytes | SHA-256 |
|---|---:|---|
| `kit_probe_native-1.0.0.hnmod` | 1,528 | `73ddd123aba1a91df8060a8c1effc1db64809133918da036f353c56e1b285077` |
| `kit_probe_items-1.0.0.hmod` | 1,764 | `9edbfedd9f456b8845e7c6cb885295599656c877f8e7030adf166865e5564c2d` |

The single-mod frame SHA-256 is `0b1169bb14f1ff3ae5dcf645b9ba08c56ff3305b09269761f6df41467753162e`. The frame is a test input, not a deliverable. App/workflow and upstream pins are in [`profiles/fast-plus-1.1.0.json`](../profiles/fast-plus-1.1.0.json). From the kit root, use `sha256sum -c SHA256SUMS.txt` and [the local validation guide](../guides/04-local-validation.md). Local artifact consistency checks do not replace authentic GitHub delivery or Android signing checks.
