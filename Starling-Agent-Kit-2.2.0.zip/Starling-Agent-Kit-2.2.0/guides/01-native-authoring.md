# 01 · Author a `.hnmod` for Fast Workflow 1.1.0

> **Legacy · Plus 0.8.0.** For Starling 0.9.0, start with the [Horizon native `.hmod` guide](06-horizon-090.md).

A Plus `.hnmod` is a **ZIP of Rust source and mixin instructions**. It is an input to Starling Compiler, not an APK, plugin binary, or resource pack. The code is woven into the pinned Starling source, then built for Android. Once installed it runs with the game’s access; only build code you trust.

## 1. Choose the right code boundary

- For HUD, key presses, and local feedback, work on the client path and return early when a screen, spectator mode, or unsupported game mode is active.
- For saved state, damage, inventory, blocks or entities, inspect the **authoritative** path. Check the owner, held item, active world, cooldown and target in that path. Keep policy/math in a small testable Rust module; keep the injection narrow. Do not add a global mutable singleton just to avoid finding the right game/world state.
- Prefer a suitable stable entry in the pinned game’s `native-hooks.json`: use `hook = "…"` with its exact `hook_version` and no `target`. Use a raw `target` only after finding the actual function and declaring module in that checkout. `horizon-native.json`’s optional `hooks` is the overall API level for bundles relying on stable hooks; it is **not** an injection’s `hook_version` and does not make the Plus build select a different commit. Omit it for the raw-target starter.

## 2. Use this archive layout

```text
my_mod_native-1.0.0.hnmod
├── horizon-native.json
└── mixins/
    └── my_mod_native/
        ├── horizon-mixin.toml
        └── probe_use.rs
```

The ZIP opens directly to `horizon-native.json` and `mixins/`. No extra enclosing directory. Example root JSON:

```json
{
  "schema": 1,
  "id": "my_mod_native",
  "version": "1.0.0",
  "game": "26.3",
  "horizon": "ac874422ed8f892505ff73d67ae486ecfee7a516",
  "mixins": "ddd9700b21997c95d95ac6ee5ecafe3830cf622a"
}
```

Use IDs no longer than 64 characters, starting with a lowercase letter or digit and using `[a-z0-9_]`. The YAML’s lexical check also accepts hyphens, but the pinned Starling CLI’s mod-ID rule does not; use the intersection. Keep the same ID and version in the JSON, bundle folder (ID only), and TOML `[mod]`. In the TOML, `horizon_revision` belongs under `[compatibility]`. The YAML can print a revision-mismatch **note** and proceed on its fixed checkout; that does **not** mean the code is compatible. The kit preflight treats mismatched pins as a release error. Port and retest; do not just rewrite hashes on a legacy mod.

Store/Deflate ZIP; regular files and simple relative `/` paths only. No symlinks, encryption, embedded build outputs, `.so`, `.jar`, directories named `..`, or duplicate/conflicting paths. The pinned parser accepts `.rs`, `.toml`, bundle-local `data/` (and `<crate>/data/`), and standard README/LICENSE/notice-style text in the bundle or its immediate crate folder. **Do not** include top-level `horizon-mod.toml`, `assets/` or `data/`; use a separate `.hmod`. Bundle-local `mixins/<id>/data/` is for compiled-in bytes, not game registries.

### Limits for the native build set

| Limit | Bytes/count |
|---|---:|
| Unique selected native IDs, including Keep | 1–10 |
| One compressed `.hnmod` | 16 MiB |
| Entire framed upload | 32 MiB |
| Expanded files in one `.hnmod` | 64 MiB |
| Expanded files across the set | 128 MiB |
| Files / total entries in one ZIP | 512 files / 768 entries including directories |
| Root JSON / inner TOML | 64 KiB / 256 KiB |
| ZIP entry path length | 360 characters |

`SMB2` takes 4 bytes, plus 4 bytes per archive for its length. Do not aim for the limits; smaller bundles leave room for other mods.

## 3. Implement and verify the hook

This is the declaration used by the [Kit Probe](../examples/Kit-Probe-1.0.0/source/native/horizon-mixin.toml) with its ID changed:

```toml
[mod]
id = "my_mod_native"
version = "1.0.0"

[compatibility]
horizon_revision = "ac874422ed8f892505ff73d67ae486ecfee7a516"

[[injection]]
id = "probe_use"
kind = "HEAD"
target = "horizon_client::game::remote::Game<'_>::remote_mouse"
cancellable = true
helper = "probe_use.rs"
bindings = [
  { name = "game", ty = "&mut crate::game::Game<'_>", value = "&mut *self" },
  { name = "button", ty = "winit::event::MouseButton", value = "button" },
  { name = "pressed", ty = "bool", value = "pressed" },
]
```

- The helper is a plain Rust function in the named source file. Its parameters match `bindings` in order. Here a cancellable HEAD returns `core::ops::ControlFlow<Result<()>>`, matching the target’s return spelling. `Continue(())` lets the original code run; `Break(Ok(()))` handles the event without running it. Return `Continue(())` on unrelated clicks or when the paired content is absent; a non-cancellable hook does not return `ControlFlow`. A type alias that Cargo considers equivalent can still fail the mixin helper signature check.
- The probe handles only a main-hand/right-Use press in a loaded, unpublished integrated world with the matching item. It emits a client chat line, not a broadcast or server command. Use on Android must reach the game’s **Use** input; testing a UI tap, an alternate control that never calls this hook, or a remote server is not a probe test.
- For a support module, add `[[module]]` with a unique `id`, `name`, indexed `file`, and bundle-relative `source`. Put the module’s items in that file, **without** an outer `mod` wrapper, file attributes, shebang, or leading `//!`. Scope/visibility still follow Rust rules. Namespace the Rust module (e.g. `ruby_probe_runtime`), not just the mod ID.
- Inspect bind types and privacy before adding `[[bridge]]`. A bridge targets a supported indexed owner in its declaring module; it is not a way to bypass arbitrary generic/qualified owners. If a bridge rejects a `Game<'_>` owner, use a supported hook or API/path instead of making visibility broader. For `[[state]]`, document construction/reset, default and serialization behavior; test world switches and reopen before shipping.
- Two mods declaring the same module `name` in the same `file` fail validation. Two mods with cancellable HEAD hooks on a common target can both compile and still interfere; an earlier cancellation may stop the other. The YAML warns for explicit shared `target` strings, not every semantic conflict or named hook. Test alone, then together. Do not fix compatibility by blindly increasing priority.

## 4. Keep Android building predictable

Start with only injected helpers and support modules. No Android Java source, desktop-only APIs, downloaded dependencies or custom build steps in a simple mod. ARM64 is not x86 desktop: test `cfg(target_os = "android")`, available APIs, the actual method shape on mobile, and audio/input fallback. The renderer, touch controls and simulators are different paths. The workflow detects **microphone** needs from native source; disclose needed permissions and avoid requesting them for unrelated functionality. A permission declaration is not a runtime grant.

**Advanced `[[crate]]` bundles:** the pinned tool can stage a crate under a bundle, but registry dependencies must already be in the pinned workspace `Cargo.lock` with compatible versions/features. No arbitrary git/path deps, nested lockfile, own workspace, targets/profiles/patches or on-build downloads. Follow the pinned crate docs. Plus does a locked/offline native build after preparation; it does not execute launcher `[[post_build]]` steps. The kit’s ARM64 helper is intentionally mixin-only; validate crate bundles through the full workflow. Do not ship build hooks just to generate files you can make during authoring.

## 5. Pack and hand off

```sh
# From the kit root; path holds horizon-mixin.toml and the referenced .rs files.
python3 tools/kit.py pack-native projects/my_mod/native --out releases/my_mod_native-1.0.0.hnmod
python3 tools/kit.py check releases/my_mod_native-1.0.0.hnmod --validator "$VALIDATOR"
python3 tools/replay_workflow.py --starling "$STARLING" --workflow "$WORKFLOW" \
  releases/my_mod_native-1.0.0.hnmod
```

See [local validation](04-local-validation.md) to set those paths and run ARM64 checking. On a behavior-only mod, remove the kit’s dependency on `*_items:probe` and document what activates your implementation; copying the example without its registry item won’t trigger the example hook. When updating a paired project, bump all three source versions (`project.json`, native TOML, content TOML); the packer writes the corresponding root native JSON. Publish the original `.hnmod`, not the `.smb` upload or the APK artifact.

## Pinned source references

- [Starling native mod guide](https://github.com/starling-client/starling/blob/ac874422ed8f892505ff73d67ae486ecfee7a516/docs/native-mods.md), [hook catalog](https://github.com/starling-client/starling/blob/ac874422ed8f892505ff73d67ae486ecfee7a516/native-hooks.json), [Android builder](https://github.com/starling-client/starling/blob/ac874422ed8f892505ff73d67ae486ecfee7a516/packaging/android/native_build.sh)
- Mixins: [HEAD and modules](https://github.com/horizon-rust/horizon-mixins/blob/ddd9700b21997c95d95ac6ee5ecafe3830cf622a/docs/boundary-head-and-modules.md), [scopes and bridges](https://github.com/horizon-rust/horizon-mixins/blob/ddd9700b21997c95d95ac6ee5ecafe3830cf622a/docs/scopes-and-bridges.md), [effects and state](https://github.com/horizon-rust/horizon-mixins/blob/ddd9700b21997c95d95ac6ee5ecafe3830cf622a/docs/effects-and-state.md), [crates, data and named hooks](https://github.com/horizon-rust/horizon-mixins/blob/ddd9700b21997c95d95ac6ee5ecafe3830cf622a/docs/crates-data-and-named-hooks.md)
