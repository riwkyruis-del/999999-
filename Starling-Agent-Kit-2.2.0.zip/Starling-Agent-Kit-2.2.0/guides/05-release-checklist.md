# 05 · Release checklist and handoff

> **Legacy · Plus 0.8.0.** For Starling 0.9.0, start with the [Horizon native `.hmod` guide](06-horizon-090.md).

Use this checklist with the [release card template](../templates/release-card.md). Keep `.hnmod` and `.hmod` separate and label their destinations. A paired release ships both files, not a single ZIP renamed to one of the two extensions.

## Author checklist

- [ ] Target says **Starling 0.8.0 / Java 26.3 / Android ARM64**, with native packages tested for **Fast Workflow 1.1.0 + Compiler Library 2.3.0**. Neither tool nor the workflow is silently upgraded in the project.
- [ ] Source has persistent unique mod and item IDs. Each manifest, `project.json`, archive name and release notes describes the intended version. A variant that registers the same ID does not ship accidentally in the same selection.
- [ ] Native `.hnmod` has no content package at its root. Content `.hmod` declares API 0.2, `side = "both"`, `registries` for new IDs. Shared IDs match language/model data, recipes and code. The native hook is a no-op without its required content; no unrelated inputs are taken over.
- [ ] The exact deliverables pass the pinned archive validator. Exact native set passes SMB2 workflow replay. Verify all intended sets, starting with one archive via **Only this**. Treat shared hook warnings as a reason to test behavior together, not as proof of failure or success.
- [ ] Native changes applied to the pinned source; real ARM64 checks run where feasible. Record whether it was only `cargo check`, a linked library, or a complete APK. Log any unrun stage.
- [ ] Publish original archives, editable sources, SHA-256s, content import/build instructions, first-use instructions and limitations. Leave PATs, private build logs, GitHub raw delivery ZIPs, signing keys, runner/source caches, and worlds out of the release.

## Phone acceptance matrix for a paired item

| Test | Expected result |
|---|---|
| Correct build, no `.hmod` in this world | Native ID appears in the APK’s Mods summary; the custom registry item is not present. Existing vanilla input still works. |
| Content enabled in a fresh world, different APK without the native pack | Item/recipe available if the release uses only vanilla definitions/components; native-only action absent. Don't use this test on saves with native-specific data. |
| Matching APK + content in a fresh private world | Correct item can be found or crafted, displays correctly, and native behavior triggers on its documented input. |
| Wrong item, UI open, unsupported sessions | No custom action; vanilla input intact according to the mod’s declared scope. |
| Save, close, reopen | Required mod set is loaded; test item persists. No existing world used for first test. |
| Optional: intended multi-mod set and update | Review set/hash matches, installs with same signer, rejects unintended carryover, world backup intact, both behaviors exercised. |

## Triage by boundary

**Cannot select** → file kind/manifest/limits. **GitHub queued or receive failed** → workflow/repo/branch/token/upload. **Validator refused** → archive layout/ID/conflict. **Weave failed** → target/catalog/mixin declaration. **Rust or link failed** → actual types/dependencies/Android environment. **Artifact failed** → matching run/ZIP/receipt/provenance; do not rebuild blindly. **APK installs but outcome missing** → the running APK, the active instance’s content, the world registry set, input gates, and other hooks. Record the earliest failing step.

For a selection change, also verify **A → B** or **A+B → B** on the phone: leave A in the library OFF, install the B-only result with the correct signer, and check the compiled list no longer includes A. Check that the test world and content imports still exist.
