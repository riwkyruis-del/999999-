# 07 · Obsidian — Better Together vs Starling

**Conclusion: promising Android performance work, but no reliable overall winner.** The project that matches this comparison is [Gruktoolz/obsidian-better-together](https://github.com/Gruktoolz/obsidian-better-together), a separate native Horizon/Rust Android client. Other “Obsidian Launcher” repos are not evidence for this APK. [v0.6.0-beta.2](https://github.com/Gruktoolz/obsidian-better-together/releases/tag/v0.6.0-beta.2), published November 16, 2026, is the newest prerelease found on the project's release list. It ships an Android ARM64 APK (minimum Android 8; notes say aimed at Android 10+). The main README’s initial “no APK” statement predates the beta APKs. The checked beta.2 tag contains only `README.md`; the auto-generated “Source code” download from that tag is not the full current game implementation. No APK was downloaded or run in this review.

## What the developers report

| Evidence | What it does and does not establish |
|---|---|
| [Obsidian beta.1 release notes](https://github.com/Gruktoolz/obsidian-better-together/releases/tag/v0.6.0-beta.1) | Full link-time optimization, render-thread scheduling hints on supported devices, opaque-first terrain rendering on eligible devices, shadow update controls, and low-memory safeguards. VSync and the FPS cap are **off by default** in these notes. Different defaults can inflate a comparison or increase heat/power use. These are beta features/settings, not all-device performance results. |
| [Obsidian beta.2 release notes](https://github.com/Gruktoolz/obsidian-better-together/releases/tag/v0.6.0-beta.2) | Frees unused allocator memory after Android low-memory notices and adds optional GPU pass timing. The authors report **83 FPS while stationary, p95 frame time 16 ms**, on a POCO F6 Pro at moderate settings. A separate **simulated 2 GiB memory setting** on that phone, with no shaders, yielded ~61 FPS and ~1.16 GB RSS. That's not a result on a real 2 GB phone. Neither test provides a matched Starling run. |
| [Starling v0.9.0 release notes](https://github.com/starling-client/starling/releases/tag/v0.9.0) | The pinned modern target has its own Android terrain, pause-menu and shadow work, plus faster startup with mods, per upstream. Do not compare an Obsidian unshaded FPS result with a Starling shader result or a different GPU/Starling version. |

I found no reproducible same-device, same-world, settings-matched Obsidian-vs-Starling result establishing that either is faster overall. FPS caps and adaptive resolution can change the workload, not just the speed. A short stationary FPS number says little about chunk loading, sustained heat, or stability. Treat Obsidian as a side experiment, **not** an officially supported kit target or a reason to replace a working install. Use developer releases, keep a backup, and do not attempt to install a different signer over a working app. Do not use Starling’s `.sset` or exact ARM64 store `.so` as if they were portable to Obsidian. Test content on disposable copies only after confirming support.

## A/B on your own phone

1. Record phone model, GPU/driver, Android version, RAM, both APK versions, power mode and screen refresh. Use separate installs/profiles where the packages allow it. Back up your worlds; start from two disposable copies of the same pregenerated seed/world and Java version.
2. Set both to the same renderer where available, **actual** render resolution, render/simulation distances, detail and graphics settings, same FPS cap and VSync, and no mods, shaders or auto quality first. If a setting or renderer cannot be matched, label that run as a real-world preset comparison instead of a controlled engine comparison.
3. Warm up, then sample the same stationary view and the same traversal for several minutes. Do at least three runs per app, alternating order and starting at a similar temperature. Add a separate longer run to expose thermal throttling and, if wanted, a matched shader run. Use the same measurement method on both; turn optional profiling off for the headline scores.
4. Compare median FPS, **p95 frame time** (lower is smoother), visible stutter, temperature/throttling, RAM and crashes. A better launcher on your phone is the one that sustains the result at the quality you actually use, not the one with the largest uncapped peak FPS.

| App/build | GPU & API | Scene/route | Resolution, distances, cap | Median FPS | p95 frame ms | Peak temp / RAM | Stutter/crash notes |
|---|---|---|---|---:|---:|---|---|
| Starling | | | | | | | |
| Obsidian | | | | | | | |
