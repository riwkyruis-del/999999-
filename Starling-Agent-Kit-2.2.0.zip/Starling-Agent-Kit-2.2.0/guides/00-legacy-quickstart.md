# Legacy quickstart · Starling Plus 0.8.0

**Target: Compiler Library 2.3.0 + Fast Workflow 1.1.0 → Starling Modded Plus 0.8.0, Minecraft Java 26.3, Android ARM64.**

This historical path is **only for modding Plus 0.8.0**; for Horizon native `.hmod` go to the [0.9.0 guide](06-horizon-090.md).

This kit contains editable sources, a ready-to-test pair of mods, and validation tools. The Compiler Library APK and Fast Workflow YAML are separate downloads. This kit does not install anything, connect to a repo or change a game instance.

| File | Where it goes | What it does |
|---|---|---|
| **`.hnmod`** | **Compiler Library → Workspace → Mod Library** | Original Rust source archive. Import once, then switch it **ON** for the next APK. **Only this** selects one archive and turns the others off. |
| **`.hmod`** | **Starling Modded Plus**, not the Compiler | Registers content and loads assets and recipes. It is not compiled into the APK and is not listed in the build receipt. |
| **Fast Workflow 1.1.0** | Your private repo’s **default branch**, at `.github/workflows/starling-compile-10.yml` | Same workflow as before. Library 2.3.0’s **Copy workflow** contains the exact Fast 1.1.0 YAML. The original Compiler 2.2.0’s copy is older; don’t paste it over the Fast workflow. |

## Build just one native mod

1. In **Mod Library**, import `kit_probe_native-1.0.0.hnmod` from [`examples/Kit-Probe-1.0.0/`](../examples/Kit-Probe-1.0.0/). New imports start **OFF**. Tap **Only this** on Kit Probe. The review should list only `kit_probe_native 1.0.0`. Nothing carries over from an older Plus APK, even if its native archive is still saved in the library.
2. Tap **Review exact build** and confirm the run. Switches affect future builds; they do not change the run you already approved, or the installed game. Install the resulting Plus APK and relaunch the game. The compiled native list should show only Kit Probe.
3. In Plus, import `kit_probe_items-1.0.0.hmod`. Make a disposable world: **Create New World → More → Mods & Data Packs → Kit Probe Items**. Allow the game to reload registries.
4. Craft a **Kit Probe** from one stick and one redstone dust (shapeless), or use its creative tab. Hold it in the main hand and use it while aiming at empty space. Expected in local chat: `Kit probe OK: native code and content item are both active.` A regular stick should not show it. Test in private single-player, not LAN or a remote server.

**If Plus is already installed:** Keep both the game and the exact app instance that originally signed it. Library 2.3.0 installs **alongside** Compiler 2.2.0, not over it. When Library shows **Install with original signer**, copy the run link and recover it in **the original Compiler → History → Recover successful run**. That app can use its existing game key to install the verified output without a second build. Back up worlds and content first; never uninstall or clear app data as part of this flow. If that key is missing, Android cannot install the update in place. See the [detailed phone guide](../guides/03-compiler-and-phone.md).

## Make a new paired mod

From the kit directory, with **Python 3.11+**:

```sh
python3 tools/kit.py new ruby_probe --name "Ruby Probe" --out projects/ruby_probe
python3 tools/kit.py pack projects/ruby_probe --out projects/ruby_probe/release
python3 tools/kit.py check --project projects/ruby_probe \
  projects/ruby_probe/release/ruby_probe_native-1.0.0.hnmod \
  projects/ruby_probe/release/ruby_probe_items-1.0.0.hmod
```

Edit `native/` for behavior and `content/` for data and assets. The scaffold gives the two packages distinct mod IDs and the same fully qualified item reference, `ruby_probe_items:probe`. To package only one side, use `pack-native` or `pack-content`. These local checks require no account or token. Before release, check the pinned package tool and replay the actual YAML input validator, then check ARM64 and test on a phone.

## Guides and verification

| File | What it covers |
|---|---|
| [01 · Native authoring](../guides/01-native-authoring.md) | Archive layout, revision pins, hook signatures, conflicts and Android constraints |
| [02 · Content authoring](../guides/02-content-authoring.md) | Registries, item/model/recipe IDs, world selection and updates |
| [03 · Compiler and phone](../guides/03-compiler-and-phone.md) | Library choices, exact builds, safe signer handoff, A → B smoke test |
| [04 · Local validation](../guides/04-local-validation.md) | Exact input replay, receipt comparison, ARM64 weave/type-check |
| [05 · Release checklist](../guides/05-release-checklist.md) | Package, test and document the outcome |
| [AGENTS.md](../AGENTS.md) | Instructions for agents writing Starling mods |
| [Compatibility profile](../profiles/fast-plus-1.1.0.json) | Machine-readable app, workflow and target pins |
| [Legacy verification](00-legacy-verification.md) | What was tested locally, and what still needs a phone |
