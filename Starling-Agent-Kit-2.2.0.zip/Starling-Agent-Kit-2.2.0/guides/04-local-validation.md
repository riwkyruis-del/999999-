# 04 · Run local compatibility checks

> **Legacy · Plus 0.8.0.** For Starling 0.9.0, start with the [Horizon native `.hmod` guide](06-horizon-090.md).

Use the same archive bytes you intend to give the player. Run the checks in increasing cost; keep the results separate. None of these local commands connects to a private repo, dispatches a job or installs on Android.

| Check | What a pass establishes | What it doesn't establish |
|---|---|---|
| `kit.py doctor` | APK and workflow match this profile’s exact file hashes | Remote workflow is installed or API access works |
| `kit.py check` | ZIP layout, IDs/pins, budgets, selected-set limits and basic pair identity | Native target exists or recipe works in a game |
| Pinned `cargo-horizon-mod … check … --json` | Starling package/parser validation, hash and reported metadata | The Rust compiles, or all installed game assets/registries resolve |
| `replay_workflow.py` | Actual Fast 1.1.0 validator accepts these exact `.hnmod`s framed with `SMB2` | Companion UI behavior, GitHub transport, or weave/compile |
| `check_arm64.py` | Actual pinned adaptation/weave and offline Rust type-check with the ARM64/API 26 target and Plus status sources | APK linked, packaged, signed, installed, or played |
| Actual app build + phone smoke test | This run installed and passed the specified behavior tests | Every mod combination, device, world, or network mode works |

## 1. Fast checks (Python 3.11+, no Rust required)

From the kit root, in a Bash shell:

```sh
EX=examples/Kit-Probe-1.0.0
N="$EX/kit_probe_native-1.0.0.hnmod"
C="$EX/kit_probe_items-1.0.0.hmod"
python3 tools/kit.py doctor
python3 tools/kit.py check --project "$EX/source" "$N" "$C"
python3 -m unittest discover -s tests -v
```

`doctor` defaults to the Library 2.3.0 APK and Fast 1.1.0 YAML next to the kit. It checks the actual embedded **Copy workflow** bytes as well. With releases elsewhere, set `WORKFLOW` and `APP` to their **absolute paths** and pass `--workflow "$WORKFLOW" --app "$APP"`. Optionally add `--legacy-app /path/to/starling-compiler-2.2.0.apk` to match the old installer file. This cannot test whether its already-installed instance still has your game key. Use the same workflow path for replay and weave. The tests needing pinned external tools are skipped until you set the environment variables below. For an arbitrary mod set, pass all archives to `check` without `--project`; the project option is for exactly one paired release and checks `project.json` and listed item definitions. Running `pack` does this preflight before it publishes the pair. Fixed entry order/timestamps make repack deterministic within the same zip toolchain; keep release hashes tied to the original output.

## 2. Build the pinned tools once (Linux x86-64 / WSL2)

You need Python 3.11+, `curl`, `tar`, `sha256sum`, `rustup`, a host C/C++ toolchain and `pkg-config`, network access for preparation, and several GiB of free space. Use an empty tool folder outside the project. The Bash block assumes it is run from the kit root. For archive-only tests you can skip the NDK and ARM64 build; for a real APK the GitHub workflow also provisions build-tools **35.0.0**, SDK platform **36**, JDK **25**, and the Java 26.3 exporter inputs. The APK’s Android target SDK is **35** and minimum is **26**; the Android platform and the Minecraft Java version are different numbers.

```sh
H=ac874422ed8f892505ff73d67ae486ecfee7a516
M=ddd9700b21997c95d95ac6ee5ecafe3830cf622a
TOOLS="$HOME/starling-fast-plus-tools"
STARLING="$TOOLS/starling-$H"
MIXINS="$TOOLS/mixins-$M"
mkdir -p "$TOOLS"
mkdir "$STARLING" "$MIXINS"   # both should be new, not reused modified trees
curl -fsSL --retry 3 "https://codeload.github.com/starling-client/starling/tar.gz/$H" -o "$TOOLS/starling.tar.gz"
curl -fsSL --retry 3 "https://codeload.github.com/horizon-rust/horizon-mixins/tar.gz/$M" -o "$TOOLS/mixins.tar.gz"
tar -xzf "$TOOLS/starling.tar.gz" --strip-components=1 -C "$STARLING"
tar -xzf "$TOOLS/mixins.tar.gz" --strip-components=1 -C "$MIXINS"
printf '%s  %s\n' '2d06e736125451a8199ae0c730bb982fa58f5715a31cd5b5521e7738f94187bd' "$STARLING/Cargo.lock" | sha256sum -c -
printf '%s  %s\n' '35846f4a621cf8e1e54f6f0f7e13ac848db590d4ec401620501c107954eae6ca' "$MIXINS/Cargo.lock" | sha256sum -c -
rustup toolchain install 1.100.0 --profile minimal --target aarch64-linux-android --no-self-update
cargo +1.100.0 build --locked --manifest-path "$MIXINS/Cargo.toml" \
  -p horizon-mixins-cli --target-dir "$TOOLS/host"
cargo +1.100.0 build --locked --manifest-path "$STARLING/Cargo.toml" \
  -p cargo-horizon-mod --target-dir "$TOOLS/host"
MIXINS_BIN="$TOOLS/host/debug/horizon-mixins"
VALIDATOR="$TOOLS/host/debug/cargo-horizon-mod"
```

Stop if a hash or setup command fails. Use the source trees at the two commits, not a newer `main` branch or an unrelated Horizon installation. The kit verifies the workflow and parser bytes before it executes the extracted validator; the author is responsible for the provenance of the source tree, NDK and binaries they supply. Don't use the local native build helper on unreviewed third-party code. Offline Cargo is not a sandbox: build scripts or macros can execute even during `cargo check`. Use a disposable Linux account/container without secrets when authoring.

## 3. Official archive checks + real YAML replay

```sh
# Point WORKFLOW at the exact retained Fast Workflow YAML if it is not in the default sibling folder.
WORKFLOW="$(realpath ../Starling-Plus-Fast-Workflow-1.1.0/starling-compile-10-fast-1.1.0.yml)"
python3 tools/kit.py check --project "$EX/source" --validator "$VALIDATOR" "$N" "$C"
python3 tools/replay_workflow.py --workflow "$WORKFLOW" --starling "$STARLING" "$N"
STARLING_TEST_SOURCE="$STARLING" STARLING_TEST_YAML="$WORKFLOW" \
  STARLING_TEST_VALIDATOR="$VALIDATOR" python3 -m unittest discover -s tests -v
```

Replay places the selected `.hnmod` bytes in an ephemeral `input.smb`, computes its full hash, extracts the reviewed validation Python from the exact YAML and runs it with the pinned upstream parser. It reports the framed size and normalized mod set with original hashes. No mod Rust runs here; the test never contacts GitHub. To test a full build set, replace `"$N"` with the original archives for **every enabled Mod Library entry and nothing else**. Do not include disabled archives or `.hmod`s.

To validate an existing `mods.smb` taken from an authorized input artifact, use `--input-smb /path/to/mods.smb` instead of the archive arguments. It copies the exact bytes without reframing. Add `--input-sha "$INPUT_SHA"` when you know the approved dispatch digest, to detect any difference. Do not share private input bundles in issue reports.

## 4. Weave + ARM64 type-check (trusted authored native code)

Install Linux Android **NDK r28c** (`28.2.13676358`), for example `sdkmanager --install 'ndk;28.2.13676358'` in an existing Android SDK with accepted licenses. Point `NDK` at that directory. Prepare Cargo’s cache, then run the trusted mixin-only check:

```sh
NDK="$ANDROID_HOME/ndk/28.2.13676358"
cargo +1.100.0 fetch --locked --manifest-path "$STARLING/Cargo.toml" \
  --target aarch64-linux-android --target x86_64-unknown-linux-gnu
python3 tools/check_arm64.py --trusted --workflow "$WORKFLOW" --starling "$STARLING" \
  --mixins-bin "$MIXINS_BIN" --ndk "$NDK" --scratch "$TOOLS/local-arm64" "$N"
```

The helper uses a temporary copy of the pinned checkout, replays the upload; applies the workflow’s APK-bound status overlay and the upstream Android adapter; weaves with pinned Mixins; restores the **real Android** Cargo library path from the temporary planner stub; then uses the workflow’s ARM64 environment with `cargo check --locked --offline --target aarch64-linux-android --profile quick -p horizon-android`. It verifies the unchanged lockfile. Your source tree remains untouched. One Cargo worker is the default; if the planner or compiler is killed, make more memory/swap available in a disposable build environment. Keep a scratch directory with space for Cargo and use a clean one for a suspect cache. For a **linked library only**, the optional `--link` uses the workflow’s build command and validates the ARM64 ELF header; it is much heavier and is **not** an APK or phone test. For `[[crate]]` use the actual workflow and its staged lock handling instead of this helper.

### Diagnose the first real error

| First failure | Likely fix |
|---|---|
| Manifest missing | ZIP the **contents**, not their enclosing folder; verify exact filename and case. |
| ID/version or package kind | Keep root native JSON, folder ID and `[mod]` in sync; put registries/assets in their own `.hmod`. |
| `E_MANIFEST` | Parse TOML, then check schema/keys. `horizon_revision` is under `[compatibility]`. For named hooks set `hook` + `hook_version`, not both `hook` and `target`. |
| `E_TARGET` / ambiguous target | Copy the exact module/type/lifetime shape from the pinned Starling source or use a catalog hook. Use Android’s temporary one-identity planner arrangement (the helper does this), not a raw double-indexed workspace. |
| `E_INVALID_HELPER` / Rust `E0308` | Check bindings, visibility/borrows, and the cancellable helper’s exact return type. Avoid a fully qualified alias if the pinned target spells it differently. |
| `E_MODULE` / `E_BRIDGE_TARGET` | Plain support module items, no leading `//!`/shebang/file attributes. Do not bridge unsupported owners; choose a supported boundary. |
| `E_CRATE_DEPENDENCY` / Cargo resolution offline | Do not edit Starling’s lockfile to make a release pass. For mixin-only cache misses fetch the pinned targets before the check. For a crate, verify it can use the already locked packages/features and run the full workflow. |
| `Killed`, wrong tool version, SDK missing, runner timeout | Identify environment failures separately. Check Rust, NDK, target, disk/memory and the first log before blaming the mod. |

## 5. Check a delivered artifact locally (optional)

```sh
python3 tools/kit.py inspect-delivery /path/to/original-starling-plus-apk.zip --native "$N"
```

Repeat `--native` for each expected original `.hnmod`; optionally pass `--job` and `--input-sha` for a known request. The checker inspects the ZIP in place, validates receipt fields and streams the APK bytes to compare its SHA-256/size. No unzipping/repacking required. A receipt and an APK in the same ZIP can be self-consistent without being genuine. This does **not** verify GitHub’s artifact digest, the APK’s embedded manifest/signature, or an Android installation. Let Compiler verify/authenticate and sign the original delivery ZIP.
