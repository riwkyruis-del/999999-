# 06 · Starling 0.9.0 — native Horizon `.hmod`

**Target:** Starling commit `ff303502a4f7982551a0e0d3622d9268efe9e829`, Java 26.3, Horizon API `0.2`, `arm64-v8a`, Rust `1.99.1`, Android API 26+. Use the [pinned profile](../profiles/horizon-0.9.0-arm64.json) to distinguish the official game from the separate signed companion/runtime pair. This guide fixes a target; it will not auto-upgrade to another Starling release, preview, nightly, or fork.

## Choose and build the right kind of package

| Root `horizon-mod.toml` | Archive contents | Use it with |
|---|---|---|
| No `[native]` or `[wasm]` | Content registry entries, assets, data | Import in the intended game; no native library to compile. Check the world’s selected registry packs. |
| `[native]` | `Cargo.toml`, `src/lib.rs`, optional safe data/assets in their namespaces | Horizon Compiler **Library** for supported API-only sources; finished libraries are specific to the game build. |
| `[wasm]` | WebAssembly module and resources | Only a verified Wasm-capable runtime and matching API. Not a Horizon Compiler input. |
| Legacy `horizon-native.json` or `horizon-mixin.toml` (not the modern manifest) | `.hnmod` mixins/injections or modules | Legacy Plus **only**, or port the original sources. Renaming is never enough. |

The supported native package is **flat**: no wrapper folder, `.horizon/`, embedded `.so`, `.jar`, old mixin manifests or generated build directories. In the source project, put `Cargo.toml` and `horizon-mod.toml` at the top alongside `src/lib.rs`. Keep the manifest’s own `id`, `name`, `version`, `api = "0.2"`, and `capabilities = ["registries"]`. Its `[native]` contains `game = "26.3"`, `horizon = "…"`, `mixins = "…"`, where the two revisions are full author/SDK pins. The sole Cargo dependency is the SDK API:

```toml
[dependencies]
horizon-mod-api = { path = ".horizon/sdk/api/crates/horizon-mod-api" }
```

API-only does not mean every valid Horizon source builds here. No whole-game mixins, modules, injections, game internals, dependency graph, external Cargo crates, Cargo features/build scripts, prebuilt replacement libraries, or unsupported external assets in this Compiler path. Put owned assets/data in the proper namespace; permitted shared tags such as `data/c/tags/...` can travel alongside a native crate. Compiler limits include 1–10 enabled packages, 16 MiB compressed/64 MiB expanded per source and 32 MiB compressed/128 MiB expanded combined. The exact archive bytes are the source identity. Re-zipping changes that identity even when the visible version stays the same.

## Author or port

1. Start with the [pinned native template](https://github.com/starling-client/starling/tree/ff303502a4f7982551a0e0d3622d9268efe9e829/crates/cargo-horizon-mod/template/native), [package contract](https://github.com/starling-client/starling/blob/ff303502a4f7982551a0e0d3622d9268efe9e829/docs/modding/src/how-to/native-mods/02-the-package.md), and [hook guide](https://github.com/starling-client/starling/blob/ff303502a4f7982551a0e0d3622d9268efe9e829/docs/modding/src/start/writing-hooks.md). Find the actual event, host methods, side and activation conditions for the behavior, rather than copying a legacy hook. Keep no-op conditions for unrelated items/events and test first in private single-player. If the only API is whole-game injection, report that it is out of this route rather than suppressing the failed mod.
2. In the native SDK tooling, `cargo horizon-mod new my_mod --template native --horizon <verified-sdk-build>` scaffolds and fetches a pinned SDK. From the resulting project `cargo horizon-mod check` checks source/package and `cargo horizon-mod build` packs the `.hmod`; `cargo horizon-mod check <archive> --json` checks a packaged archive. Inspect the actual CLI version and output. **Do not assume the Android APK commit also has a published desktop SDK.** The SDK tag for this exact Starling commit was not found in the checked Starling/Horizon release repos. The downloadable sample sources use an upstream Horizon SDK pin, not `ff303502…`. Preserve that distinction: the source carries author pins; the **output** must target and identify the exact Starling Android build. Read the verified SDK source and prove fit; an arbitrary newer nightly or an edited pin is not a fix.
3. Run `python3 tools/horizon.py route path/to/mod.hmod` for a local routing hint. Then import in the actual Compiler and run its preflight and build check. This kit does not bundle a modern Rust compiler, SDK, newly ported Kit Probe, or a published library for a newly authored mod. Content files under the old Kit Probe illustrate identifiers and layout, not v0.9.0 gameplay certification.

## Exact build and phone loop

1. Inspect the exact pin with `python3 tools/horizon.py doctor`. For the signed pair, import source into **Library** and turn on just the intended IDs. Review the original archive SHA-256, not merely the displayed version. Use **Only this** for a one-mod set.
2. **Build enabled set → Check builds** consults the pinned [Starling store](https://github.com/starling-client/mod-builds). It matches full source SHA-256, build commit, ABI and version to an exact verified lib. The store’s abbreviated job key is a locator, not a substitute for the full digest. Empty, mismatched, or failed rows must not turn into a partial set. A metadata/library match is not an endorsement of the mod author's native code.
3. For a genuinely missing published build, **Request missing builds** can POST the chosen originals to the hosted Compile v2 service only after approval. It can publish results/logs; do not submit private sources. Acknowledgement is not a build result. Wait and check again. For official Starling (not our pair), native catalog mods instead use its own **Options → Mods → Compile**. Do not use SMB2 or a GitHub PAT for the modern flow.
4. In the signed pair, **Send to runtime** hands one verified set to the separate game. Close a running game normally after saving; stage changes without live swapping, then launch the Runtime fresh. Check its mod list and the profile’s mod switches. Its private profiles and worlds are separate from official and Plus 0.8.0. You do not reinstall the APK for each native selection. Confirm behavior, then confirm no unwanted code with a one-mod replacement. To remove native code deliberately, stage **Prepare empty set → Send empty set** and restart.

### Phone acceptance (not yet run)

Use a disposable profile/world. The two known sources in the profile are **Accelerated Decay 0.2.1** and **Cloud Glass 0.2.1**. Confirm catalog/import, A+B and B-only loads and behaviors, then optionally clear on a throwaway save. Check that A did not carry over just because it’s in the library. **Never clear a modded world to test mod removal**; a game may lose native-dependent items or blocks when you open a world without its required mods. Compare backed-up content and report the first failing boundary: source validation, build availability, transfer, launch, mod registration, profile/world switches, or gameplay.

See [verification](../VERIFIED.md) for host vs device evidence and [upstream release notes](https://github.com/starling-client/starling/releases/tag/v0.9.0) for official Starling behavior.
