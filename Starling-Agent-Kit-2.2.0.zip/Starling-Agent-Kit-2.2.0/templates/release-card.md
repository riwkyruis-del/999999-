# [Mod name] [version]

**Target:** Starling Modded Plus 0.8.0 · Java 26.3 · Android ARM64 · Fast Workflow 1.1.0 · Compiler Library 2.3.0

| Deliverable | Version and ID | Destination | SHA-256 |
|---|---|---|---|
| `….hnmod` (if used) | … | Compiler Library → Workspace → Mod Library → Import .hnmods; select the intended set | … |
| `….hmod` (if used) | … | Installed Plus game, then enable it for a fresh test world | … |

**Requires:** matched package versions, content IDs referenced by code, dependencies/permissions, supported modes (e.g. private single-player only). List unchanged features and incompatibilities.

**First run:** install the compiled build, import content when applicable, pick the correct registry set, and do one positive and one negative test. Include the input and expected result. Back up existing saves before any APK or registry-set change.

**Evidence (pass / fail / not run):** archive checks; exact workflow input replay; mixin weave; ARM64 type-check; ARM64 link; GitHub APK artifact; signed install; device gameplay; intended multi-mod combination. Record which file hashes you tested and the run URL privately if needed.

**Files for maintainers:** editable source, build/package steps, expected hashes and known limits. Do not include any token, signing key or private user data.
