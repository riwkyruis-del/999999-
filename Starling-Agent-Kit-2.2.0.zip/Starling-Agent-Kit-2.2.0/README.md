# Starling Agent Kit 2.2.0

A reference and offline toolkit for Minecraft Java 26.3 on Android ARM64. **Start with the target you actually play.** The two native build paths are not interchangeable.

| Target | Native mods | How to play |
|---|---|---|
| **Starling 0.9.0 · Horizon** | Flat native-source `.hmod` using the Horizon API. Compile v2 supplies a library for the exact source and Starling build. | **Compiler 2.3.0 Horizon Edition + matching Horizon Runtime** for reviewed, exact sets. Official Starling is separate and has its own in-game **Compile**. |
| **Starling Modded Plus 0.8.0 · legacy** | Code-only `.hnmod` built into a whole Plus APK using **Compiler Library 2.3.0 + Fast Workflow 1.1.0**. | Keep the original app/game signer and workflow. The existing Kit Probe `.hnmod` is a **legacy** example only. |
| **Obsidian — Better Together** | Separate Horizon-based Android beta. Starling’s build identity, compiled native libraries and paired Runtime handoff are **not verified** there. | Evaluation only. See the [research and A/B test guide](guides/07-obsidian-performance.md). |

**`.hmod` is not the opposite of native.** Content-only `.hmod` goes into the game without compiling. Native-source `.hmod` has a `[native]` manifest, root `Cargo.toml` and Rust code. Wasm can also be packaged as `.hmod` but is not a native Compiler input. Old `.hnmod` sources need a real API port for 0.9.0; a rename or pin edit is not a port.

## Horizon quick start

1. Install the signed **Starling Plus Horizon Runtime 0.9.0** (ARM64) and **Starling Compiler 2.3.0 Horizon Edition** from the *same paired release*. Neither APK is bundled with this kit. Both install beside old Plus and official Starling; keep old installations and saves.
2. In **Library** use **Browse catalog** or **Import .hmod**. New or replaced sources start **off**. Turn on exactly what you want, then **Build enabled set → Check builds**. A missing, failed or unsupported enabled mod blocks the whole set. A read-only check does not upload source; **Request missing builds** requires separate consent to send exact originals to the hosted service. No legacy workflow or GitHub token.
3. Save and quit the Runtime, **Send to runtime** from **Builds**, then start the Runtime fresh and check **Options → Mods**. The Runtime is the game you play, not another compiler; it stages a replacement, not a hot swap. Changing library switches alone doesn't change your game. **Prepare empty set → Send empty set** removes installed native code at the next fresh launch without deleting saves or content packs.

The signed pair passed packaging and host exact-set tests using real catalog libraries, including **Accelerated Decay 0.2.1 + Cloud Glass 0.2.1 → Cloud Glass only → empty**. The Android install, actual mod loading and gameplay still need a phone test. Use a disposable world first.

## Tools and guides

Run these from the kit root with **Python 3.11+**:

```sh
# Workspace: default expects the Compiler release directory next to the Kit.
python3 tools/horizon.py doctor
# Standalone: point at your already downloaded matching pair.
python3 tools/horizon.py doctor --compiler path/to/compiler.apk --runtime path/to/runtime.apk
python3 tools/horizon.py route path/to/my_mod.hmod
```

`doctor` matches exact released bytes. `route` reads local ZIP metadata and manifests to suggest the intake path; “candidate” does **not** certify a package, resolve a build, or run code. No command of `horizon.py` uses networking, compiles code, installs, or uploads anything.

- **[Modern Horizon 0.9.0 guide](guides/06-horizon-090.md)** — author and port API-only mods, resolve exact builds, and verify the new handoff.
- **[Obsidian evidence and A/B worksheet](guides/07-obsidian-performance.md)** — reported optimization vs proven performance, how to test on your device.
- **[Legacy quickstart](guides/00-legacy-quickstart.md)** — Kit Probe, `tools/kit.py`, original signer recovery, and the unchanged Fast Workflow. Only use `new`, `pack-native`, and `replay_workflow.py` for the legacy path.
- **[Agent rules](AGENTS.md)** · **[Verification](VERIFIED.md)** · Machine-readable profiles: [Horizon 0.9.0](profiles/horizon-0.9.0-arm64.json) and [legacy Fast Plus](profiles/fast-plus-1.1.0.json).
